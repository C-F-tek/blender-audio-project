# Full Toolbox Run Telemetry Summary

- Passed: `True`
- Stamp: `20260505-193057`
- Recommendation count: `20`
- Patch plan count: `20`
- Deterministic synthesizer used: `True`
- Patch plan fallback used: `None`
- Provider execution performed: `True`

## Repository consistency performance

- `total_build_report_seconds`: `50.203`
- `markdown_scan_seconds`: `43.689`
- `file_discovery_seconds`: `2.323`
- `python_inventory_seconds`: `2.683`
- `path_index_seconds`: `1.481`
- `findings_build_seconds`: `0.026`

## Top recommendations

- `consistency_001` `md_python` `medium` -> `['docs/LOCAL_AI_TASKS/macro-local-validation-prototype-gate.md']`
- `consistency_002` `md_python` `medium` -> `['docs/LOCAL_AI_TASKS/macro-local-validation-prototype-gate.md']`
- `consistency_003` `md_python` `medium` -> `['docs/LOCAL_AI_TASKS/macro-local-validation-prototype-gate.md']`
- `consistency_004` `md_python` `medium` -> `['docs/LOCAL_AI_TASKS/open-pr-triage-2026-05-02.md']`
- `consistency_005` `md_python` `medium` -> `['docs/LOCAL_AI_TASKS/pr109-prelocal-github-only-audit.md']`
- `consistency_006` `md_python` `medium` -> `['docs/LOCAL_AI_TASKS/project-tool-promotion-and-insertion-guide-2026-05-05.md']`
- `consistency_007` `md_python` `medium` -> `['docs/LOCAL_RUNS_TESTING_AND_EVIDENCE.md']`
- `consistency_028` `md_powershell` `medium` -> `['AI_PATCH_BUNDLE_TECHNICAL_GOTCHAS.md']`
- `consistency_029` `md_powershell` `medium` -> `['AI_PATCH_BUNDLE_TECHNICAL_GOTCHAS.md']`
- `consistency_030` `md_powershell` `medium` -> `['CHATGPT/chatgpt-session-problems-and-robust-fixes-2026-05-04.md']`
- `consistency_031` `md_powershell` `medium` -> `['docs/AUTO_PUSH_GENERATED_ARTIFACTS.md']`
- `consistency_032` `md_powershell` `medium` -> `['docs/LOCAL_AI_TASKS/full-toolbox-0-to-10-semi-automatic-procedure.md']`
- `consistency_033` `md_powershell` `medium` -> `['docs/LOCAL_AI_TASKS/full-toolbox-0-to-10-semi-automatic-procedure.md']`
- `consistency_246` `md_python` `medium` -> `['AGENTS.md']`
- `consistency_247` `md_python` `medium` -> `['AGENTS.md']`
- `consistency_248` `md_python` `medium` -> `['AGENTS.md']`
- `consistency_249` `md_python` `medium` -> `['AI_PATCH_BUNDLE_TECHNICAL_GOTCHAS.md']`
- `consistency_250` `md_python` `medium` -> `['AI_PATCH_BUNDLE_TECHNICAL_GOTCHAS.md']`
- `consistency_251` `md_python` `medium` -> `['AI_PATCH_BUNDLE_TECHNICAL_GOTCHAS.md']`
- `consistency_252` `md_python` `medium` -> `['AI_PATCH_BUNDLE_TECHNICAL_GOTCHAS.md']`

## Top patch plans

- `consistency_001` `md_python` review=`True` -> `['docs/LOCAL_AI_TASKS/macro-local-validation-prototype-gate.md']`
- `consistency_002` `md_python` review=`True` -> `['docs/LOCAL_AI_TASKS/macro-local-validation-prototype-gate.md']`
- `consistency_003` `md_python` review=`True` -> `['docs/LOCAL_AI_TASKS/macro-local-validation-prototype-gate.md']`
- `consistency_004` `md_python` review=`True` -> `['docs/LOCAL_AI_TASKS/open-pr-triage-2026-05-02.md']`
- `consistency_005` `md_python` review=`True` -> `['docs/LOCAL_AI_TASKS/pr109-prelocal-github-only-audit.md']`
- `consistency_006` `md_python` review=`True` -> `['docs/LOCAL_AI_TASKS/project-tool-promotion-and-insertion-guide-2026-05-05.md']`
- `consistency_007` `md_python` review=`True` -> `['docs/LOCAL_RUNS_TESTING_AND_EVIDENCE.md']`
- `consistency_028` `md_powershell` review=`True` -> `['AI_PATCH_BUNDLE_TECHNICAL_GOTCHAS.md']`
- `consistency_029` `md_powershell` review=`True` -> `['AI_PATCH_BUNDLE_TECHNICAL_GOTCHAS.md']`
- `consistency_030` `md_powershell` review=`True` -> `['CHATGPT/chatgpt-session-problems-and-robust-fixes-2026-05-04.md']`
- `consistency_031` `md_powershell` review=`True` -> `['docs/AUTO_PUSH_GENERATED_ARTIFACTS.md']`
- `consistency_032` `md_powershell` review=`True` -> `['docs/LOCAL_AI_TASKS/full-toolbox-0-to-10-semi-automatic-procedure.md']`
- `consistency_033` `md_powershell` review=`True` -> `['docs/LOCAL_AI_TASKS/full-toolbox-0-to-10-semi-automatic-procedure.md']`
- `consistency_246` `md_python` review=`True` -> `['AGENTS.md']`
- `consistency_247` `md_python` review=`True` -> `['AGENTS.md']`
- `consistency_248` `md_python` review=`True` -> `['AGENTS.md']`
- `consistency_249` `md_python` review=`True` -> `['AI_PATCH_BUNDLE_TECHNICAL_GOTCHAS.md']`
- `consistency_250` `md_python` review=`True` -> `['AI_PATCH_BUNDLE_TECHNICAL_GOTCHAS.md']`
- `consistency_251` `md_python` review=`True` -> `['AI_PATCH_BUNDLE_TECHNICAL_GOTCHAS.md']`
- `consistency_252` `md_python` review=`True` -> `['AI_PATCH_BUNDLE_TECHNICAL_GOTCHAS.md']`

## GPU/NPU operational opinions

- NPU should remain an advisory sampled auditor, not a lockstep reviewer for every GPU round.
- Audit coverage is intentionally sparse; this is acceptable only if findings are high-signal and evidence-backed.
- GPU round timing is not sourced from rounds[*].elapsed_seconds; keep diagnostics degraded until real samples are present.

