# NPU Audio Segment 023

## Segment Summary


```json
{
  "index": 23,
  "start_sec": 352.0,
  "end_sec": 352.167,
  "duration_sec": 0.167,
  "frame_count": 5,
  "beat_count": 0,
  "dominant_band": "low",
  "intensity_score": 0.0,
  "intensity": "quiet",
  "stats": {
    "low": {
      "avg": 0.0,
      "min": 0.0,
      "max": 0.0,
      "std": 0.0,
      "p50": 0.0,
      "p90": 0.0,
      "p98": 0.0,
      "top10_avg": 0.0
    },
    "mid": {
      "avg": 0.0,
      "min": 0.0,
      "max": 0.0,
      "std": 0.0,
      "p50": 0.0,
      "p90": 0.0,
      "p98": 0.0,
      "top10_avg": 0.0
    },
    "high": {
      "avg": 0.0,
      "min": 0.0,
      "max": 0.0,
      "std": 0.0,
      "p50": 0.0,
      "p90": 0.0,
      "p98": 0.0,
      "top10_avg": 0.0
    },
    "onset": {
      "avg": 0.0,
      "min": 0.0,
      "max": 0.0,
      "std": 0.0,
      "p50": 0.0,
      "p90": 0.0,
      "p98": 0.0,
      "top10_avg": 0.0
    },
    "beat": {
      "avg": 0.0,
      "min": 0.0,
      "max": 0.0,
      "std": 0.0,
      "p50": 0.0,
      "p90": 0.0,
      "p98": 0.0,
      "top10_avg": 0.0
    }
  },
  "controls": {
    "primary_band": "low",
    "intensity": "quiet",
    "hero_deformation": 0.0,
    "material_shimmer": 0.0,
    "fog_motion": 0.0,
    "accent_emission": 0.0,
    "camera_pressure": 0.0
  },
  "beat_times": [],
  "top_events": [
    {
      "time": 352.0,
      "low": 0.0,
      "mid": 0.0,
      "high": 0.0,
      "onset": 0.0,
      "beat": 0.0
    },
    {
      "time": 352.033,
      "low": 0.0,
      "mid": 0.0,
      "high": 0.0,
      "onset": 0.0,
      "beat": 0.0
    },
    {
      "time": 352.067,
      "low": 0.0,
      "mid": 0.0,
      "high": 0.0,
      "onset": 0.0,
      "beat": 0.0
    },
    {
      "time": 352.1,
      "low": 0.0,
      "mid": 0.0,
      "high": 0.0,
      "onset": 0.0,
      "beat": 0.0
    },
    {
      "time": 352.133,
      "low": 0.0,
      "mid": 0.0,
      "high": 0.0,
      "onset": 0.0,
      "beat": 0.0
    }
  ]
}
```


## Sampled Frame Curve


|time|low|mid|high|onset|beat|
|---|---|---|---|---|---|
|352.0|0.0|0.0|0.0|0.0|0.0|
|352.033|0.0|0.0|0.0|0.0|0.0|
|352.067|0.0|0.0|0.0|0.0|0.0|
|352.1|0.0|0.0|0.0|0.0|0.0|
|352.133|0.0|0.0|0.0|0.0|0.0|
