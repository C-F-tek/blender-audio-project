# NPU Scene Spec scene_spec_album_driven_normalized.json

## Scene Summary
```json
{
  "file": "scene_spec_album_driven_normalized.json",
  "type": "json",
  "keys": [
    "audio_mapping",
    "camera_style",
    "environment",
    "hero_object",
    "lighting_style",
    "materials",
    "node_animation",
    "objects",
    "optimization",
    "palette",
    "render_strategy",
    "scene_name",
    "style_mode",
    "visual_concept"
  ],
  "scene_name": ". .",
  "visual_concept": "Cinematic abstract soul architecture",
  "style_mode": "stylized_cinematic_abstract",
  "environment": "reflective_void_stage",
  "lighting_style": "soft_volumetric_glow",
  "palette": [
    "#1F3A5F",
    "#B08D57",
    "#F2F0E8",
    "#0B0D12"
  ],
  "camera": {
    "mood": "intimate",
    "movement": "gentle_push",
    "lens": 65.0,
    "angle_bias": "slightly_top",
    "location": [
      0.0,
      -9.2,
      3.4
    ],
    "rotation_degrees": [
      72.0,
      0.0,
      0.0
    ]
  },
  "objects_count": 5,
  "materials_count": 5,
  "audio_mapping_count": 6,
  "node_animation_count": 7,
  "object_names": [
    "hero_core",
    "light_architecture",
    "reflective_floor",
    "floating_lights",
    "volumetric_shell"
  ],
  "audio_targets": [
    "hero_core:scale:low",
    "hero_core:rotation:mid",
    "light_architecture:rotation:mid",
    "light_architecture:emission:high",
    "floating_lights:intensity:high",
    "camera:pulse:beat"
  ]
}
```
## Source
```text
{
  "scene_name": ". .",
  "style_mode": "stylized_cinematic_abstract",
  "visual_concept": "Cinematic abstract soul architecture",
  "hero_object": "abstract_signal_monolith",
  "environment": "reflective_void_stage",
  "lighting_style": "soft_volumetric_glow",
  "palette": [
    "#1F3A5F",
    "#B08D57",
    "#F2F0E8",
    "#0B0D12"
  ],
  "camera_style": {
    "mood": "intimate",
    "movement": "gentle_push",
    "lens": 65.0,
    "angle_bias": "slightly_top",
    "location": [
      0.0,
      -9.2,
      3.4
    ],
    "rotation_degrees": [
      72.0,
      0.0,
      0.0
    ]
  },
  "objects": [
    {
      "type": "hero_core",
      "name": "hero_core",
      "role": "central emotional centerpiece",
      "geometry": {
        "primitive": "cube",
        "location": [
          0.0,
          0.0,
          1.15
        ],
        "rotation": [
          0.0,
          0.0,
          0.0
        ],
        "scale": [
          0.9,
          0.9,
          2.0
        ],
        "subdivisions": 2
      },
      "material": "hero_core_material"
    },
    {
      "type": "light_architecture",
      "name": "light_architecture",
      "role": "surrounding luminous structure",
      "geometry": {
        "primitive": "instanced_columns_ring",
        "count": 12,
        "radius": 4.4,
        "height": 2.6
      },
      "material": "light_arch_material"
    },
    {
      "type": "reflective_floor",
      "name": "reflective_floor",
      "role": "depth and reflections",
      "geometry": {
        "primitive": "plane",
        "location": [
          0.0,
          0.0,
          0.0
        ],
        "rotation": [
          0.0,
          0.0,
          0.0
        ],
        "scale": [
          14.0,
          14.0,
          1.0
        ]
      },
      "material": "floor_material"
    },
    {
      "type": "floating_lights",
      "name": "floating_lights",
      "role": "harmonic accents",
      "geometry": {
        "primitive": "floating_orbs",
        "count": 4
      },
      "material": "floating_light_material"
    },
    {
      "type": "volumetric_shell",
      "name": "volumetric_shell",
      "role": "atmosphere and cinematic depth",
      "geometry": {
        "primitive": "cube_volume",
        "location": [
          0.0,
          0.0,
          3.0
        ],
        "rotation": [
          0.0,
          0.0,
          0.0
        ],
        "scale": [
          9.0,
          9.0,
          4.5
        ]
      },
      "material": "volume_material"
    }
  ],
  "materials": [
    {
      "name": "hero_core_material",
      "target": "hero_core",
      "shader_type": "emission_glass_mix",
      "node_features": [
        "noise",
        "color_ramp",
        "fresnel",
        "mapping_rotation",
        "mix_shader"
      ],
      "purpose": "hero pulse and emotional focus",
      "defaults": {
        "emission_strength": 2.2,
        "noise_scale": 3.0,
        "fresnel": 0.65,
        "mix_factor": 0.55
      }
    },
    {
      "name": "light_arch_material",
      "target": "light_architecture",
      "shader_type": "gradient_emission",
      "node_features": [
        "gradient",
        "color_ramp",
        "mapping",
        "emission"
      ],
      "purpose": "rhythmic luminous architecture",
      "defaults": {
        "emission_strength": 1.6,
        "gradient_shift": 0.0,
        "color_mix": 0.5
      }
    },
    {
      "name": "floor_material",
      "target": "reflective_floor",
      "shader_type": "reflective_principled",
      "node_features": [
        "noise",
        "bump",
        "roughness_variation",
        "fresnel"
      ],
      "purpose": "depth, reflection and grounding",
      "defaults": {
        "roughness": 0.24,
        "bump_strength": 0.08,
        "metallic": 0.18
      }
    },
    {
      "name": "floating_light_material",
      "target": "floating_lights",
      "shader_type": "soft_emission",
      "node_features": [
        "emission",
        "noise",
        "color_variation"
      ],
      "purpose": "harmonic floating accents",
      "defaults": {
        "emission_strength": 1.5,
        "noise_scale": 4.0
      }
    },
    {
      "name": "volume_material",
      "target": "volumetric_shell",
      "shader_type": "principled_volume",
      "node_features": [
        "volume_density",
        "anisotropy"
      ],
      "purpose": "cinematic atmosphere",
      "defaults": {
        "density": 0.015,
        "anisotropy": 0.2
      }
    }
  ],
  "node_animation": [
    {
      "target": "hero_core_material",
      "parameter": "emission_strength",
      "band": "beat",
      "intent": "main musical pulse",
      "strength": 1.0
    },
    {
      "target": "hero_core_material",
      "parameter": "noise_scale",
      "band": "low",
      "intent": "body deformation illusion",
      "strength": 0.65
    },
    {
      "target": "hero_core_material",
      "parameter": "mix_factor",
      "band": "mid",
      "intent": "surface shimmer and motion",
      "strength": 0.45
    },
    {
      "target": "light_arch_material",
      "parameter": "emission_strength",
      "band": "high",
      "intent": "harmonic brightness",
      "strength": 0.8
    },
    {
      "target": "light_arch_material",
      "parameter": "gradient_shift",
      "band": "mid",
      "intent": "circulating light flow",
      "strength": 0.5
    },
    {
      "target": "floor_material",
      "parameter": "roughness",
      "band": "low",
      "intent": "subtle reflective breathing",
      "strength": 0.3
    },
    {
      "target": "volume_material",
      "parameter": "density",
      "band": "beat",
      "intent": "volumetric pulse",
      "strength": 0.18
    }
  ],
  "audio_mapping": [
    {
      "target": "hero_core",
      "property": "scale",
      "band": "low",
      "intent": "central body pulse",
      "strength": 0.55
    },
    {
      "target": "hero_core",
      "property": "rotation",
      "band": "mid",
      "intent": "gentle musical sway",
      "strength": 0.25
    },
    {
      "target": "light_architecture",
      "property": "rotation",
      "band": "mid",
      "intent": "architectural motion",
      "strength": 0.4
    },
    {
      "target": "light_architecture",
      "property": "emission",
      "band": "high",
      "intent": "harmonic brightness accents",
      "strength": 0.72
    },
    {
      "target": "floating_lights",
      "property": "intensity",
      "band": "high",
      "intent": "sparkle accents",
      "strength": 0.7
    },
    {
      "target": "camera",
      "property": "pulse",
      "band": "beat",
      "intent": "subtle rhythmic camera bump",
      "strength": 0.28
    }
  ],
  "optimization": {
    "use_instancing": true,
    "use_procedural_materials": true,
    "avoid_heavy_geometry": true,
    "animate_nodes_more_than_meshes": true,
    "geometry_budget": "low_geometry_high_shading",
    "notes": [
      "keep hero object simple",
      "use instanced ring architecture",
      "prefer procedural shading",
      "use one volumetric shell only",
      "avoid subdivision-heavy meshes"
    ]
  },
  "render_strategy": {
    "engine": "BLENDER_EEVEE",
    "priority": "fast iteration with rich shading",
    "notes": "use emission, procedural shaders and moderate volumetrics"
  }
}
```
