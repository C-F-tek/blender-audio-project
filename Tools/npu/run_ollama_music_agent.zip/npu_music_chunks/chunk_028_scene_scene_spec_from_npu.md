# NPU Scene Spec scene_spec_from_npu.json

## Scene Summary
```json
{
  "file": "scene_spec_from_npu.json",
  "type": "json",
  "keys": [
    "audio_mapping",
    "camera",
    "objects",
    "palette",
    "scene_name"
  ],
  "scene_name": ".",
  "visual_concept": null,
  "style_mode": null,
  "environment": null,
  "lighting_style": null,
  "palette": [
    "#20354D",
    "#38215A",
    "#4D2A37"
  ],
  "camera": {
    "location": [
      16,
      16,
      16
    ],
    "rotation": [
      0,
      540,
      360
    ],
    "lens": 455
  },
  "objects_count": 2,
  "materials_count": 0,
  "audio_mapping_count": 4,
  "node_animation_count": 0,
  "object_names": [
    "central_sphere",
    "."
  ],
  "audio_targets": [
    "central_sphere:material_select:beat",
    "light_cobinates_ring:strength:beat",
    "central_sphere:material_shader:beat",
    "light_cobinates_ring:strength:beat"
  ]
}
```
## Source
```text
{
  "scene_name": ".",
  "camera": {
    "location": [
      16,
      16,
      16
    ],
    "rotation": [
      0,
      540,
      360
    ],
    "lens": 455
  },
  "palette": [
    "#20354D",
    "#38215A",
    "#4D2A37"
  ],
  "objects": [
    {
      "type": "sphere",
      "name": "central_sphere",
      "location": [
        8,
        8,
        8
      ],
      "scale": [
        0.5,
        0.5,
        0.5
      ]
    },
    {
      "type": "light_columns_ring",
      "name": ".",
      "count": 12,
      "radius": 5.0
    }
  ],
  "audio_mapping": [
    {
      "target": "central_sphere",
      "property": "material_select",
      "band": "beat"
    },
    {
      "target": "light_cobinates_ring",
      "property": "strength",
      "band": "beat"
    },
    {
      "target": "central_sphere",
      "property": "material_shader",
      "band": "beat"
    },
    {
      "target": "light_cobinates_ring",
      "property": "strength",
      "band": "beat"
    }
  ]
}
```
