# NPU Music Overview

```json
{
  "analysis_summary": {
    "source": "output/Parameters-Luca Vera Premaster_Master_analysis.json",
    "track_name": "Parameters-Luca Vera Premaster_Master",
    "meta": {
      "input_wav": "C:\\Users\\carmi\\Desktop\\Living Life In Peace-Luca Vera\\Parameters-Luca Vera Premaster_Master.wav",
      "sample_rate": 44100,
      "duration_sec": 352.16662131519274,
      "fps": 30.0,
      "n_fft": 2048,
      "hop_length": 512,
      "bands_hz": {
        "low": [
          20.0,
          180.0
        ],
        "mid": [
          180.0,
          2000.0
        ],
        "high": [
          2000.0,
          8000.0
        ]
      },
      "estimated_tempo_bpm": 112.34714673913044
    },
    "frame_count": 10565,
    "beat_count": 642,
    "segment_seconds": 16.0,
    "segment_count": 23,
    "overall_stats": {
      "low": {
        "avg": 0.23,
        "min": 0.0,
        "max": 1.0,
        "std": 0.2467,
        "p50": 0.1309,
        "p90": 0.6167,
        "p98": 0.9564,
        "top10_avg": 0.8287
      },
      "mid": {
        "avg": 0.3202,
        "min": 0.0,
        "max": 1.0,
        "std": 0.2329,
        "p50": 0.28,
        "p90": 0.6496,
        "p98": 0.9429,
        "top10_avg": 0.8125
      },
      "high": {
        "avg": 0.2149,
        "min": 0.0,
        "max": 1.0,
        "std": 0.2168,
        "p50": 0.1399,
        "p90": 0.5332,
        "p98": 0.8947,
        "top10_avg": 0.7256
      },
      "onset": {
        "avg": 0.1674,
        "min": 0.0,
        "max": 1.0,
        "std": 0.211,
        "p50": 0.0749,
        "p90": 0.4889,
        "p98": 0.8433,
        "top10_avg": 0.6943
      },
      "beat": {
        "avg": 0.0608,
        "min": 0.0,
        "max": 1.0,
        "std": 0.2389,
        "p50": 0.0,
        "p90": 0.0,
        "p98": 1.0,
        "top10_avg": 0.608
      }
    },
    "top_energy_segments": [
      {
        "index": 5,
        "start_sec": 64.0,
        "end_sec": 80.0,
        "dominant_band": "mid",
        "intensity_score": 0.3744,
        "intensity": "medium"
      },
      {
        "index": 18,
        "start_sec": 272.0,
        "end_sec": 288.0,
        "dominant_band": "mid",
        "intensity_score": 0.3693,
        "intensity": "medium"
      },
      {
        "index": 12,
        "start_sec": 176.0,
        "end_sec": 192.0,
        "dominant_band": "mid",
        "intensity_score": 0.3647,
        "intensity": "medium"
      },
      {
        "index": 7,
        "start_sec": 96.0,
        "end_sec": 112.0,
        "dominant_band": "mid",
        "intensity_score": 0.3614,
        "intensity": "medium"
      },
      {
        "index": 9,
        "start_sec": 128.0,
        "end_sec": 144.0,
        "dominant_band": "mid",
        "intensity_score": 0.3593,
        "intensity": "medium"
      },
      {
        "index": 6,
        "start_sec": 80.0,
        "end_sec": 96.0,
        "dominant_band": "mid",
        "intensity_score": 0.3569,
        "intensity": "medium"
      },
      {
        "index": 19,
        "start_sec": 288.0,
        "end_sec": 304.0,
        "dominant_band": "mid",
        "intensity_score": 0.3565,
        "intensity": "medium"
      },
      {
        "index": 11,
        "start_sec": 160.0,
        "end_sec": 176.0,
        "dominant_band": "mid",
        "intensity_score": 0.345,
        "intensity": "medium"
      }
    ],
    "top_onset_segments": [
      {
        "index": 21,
        "start_sec": 320.0,
        "end_sec": 336.0,
        "onset_p98": 0.9644,
        "beat_count": 30
      },
      {
        "index": 20,
        "start_sec": 304.0,
        "end_sec": 320.0,
        "onset_p98": 0.9055,
        "beat_count": 29
      },
      {
        "index": 6,
        "start_sec": 80.0,
        "end_sec": 96.0,
        "onset_p98": 0.8954,
        "beat_count": 30
      },
      {
        "index": 3,
        "start_sec": 32.0,
        "end_sec": 48.0,
        "onset_p98": 0.8925,
        "beat_count": 30
      },
      {
        "index": 22,
        "start_sec": 336.0,
        "end_sec": 352.0,
        "onset_p98": 0.8907,
        "beat_count": 15
      },
      {
        "index": 4,
        "start_sec": 48.0,
        "end_sec": 64.0,
        "onset_p98": 0.8831,
        "beat_count": 30
      },
      {
        "index": 17,
        "start_sec": 256.0,
        "end_sec": 272.0,
        "onset_p98": 0.87,
        "beat_count": 30
      },
      {
        "index": 18,
        "start_sec": 272.0,
        "end_sec": 288.0,
        "onset_p98": 0.8547,
        "beat_count": 30
      }
    ]
  },
  "track_summary": {
    "track_name": "Parameters-Luca Vera Premaster_Master",
    "source_analysis_json": "C:\\Users\\carmi\\blender\\blender-audio-project\\output\\Parameters-Luca Vera Premaster_Master_analysis.json",
    "duration_sec": 352.16662131519274,
    "fps": 30.0,
    "estimated_tempo_bpm": 112.34714673913044,
    "energy_profile": {
      "low_avg": 0.23,
      "mid_avg": 0.3202,
      "high_avg": 0.2149,
      "low_peak_avg": 0.8287,
      "mid_peak_avg": 0.8125,
      "high_peak_avg": 0.7256,
      "onset_avg": 0.1674,
      "beat_avg": 0.0608
    }
  },
  "scene_summaries": [
    {
      "file": "scene_spec_album_driven.json",
      "type": "json",
      "keys": [
        "audio_mapping",
        "camera_style",
        "environment",
        "hero_object",
        "lighting_style",
        "objects",
        "palette",
        "scene_name",
        "style_mode",
        "visual_concept"
      ],
      "scene_name": ". .",
      "visual_concept": ".",
      "style_mode": "stylized_cinematic_abstract",
      "environment": "reflective_void_stage",
      "lighting_style": "soft_volumetric_glow",
      "palette": [
        "deep_blue",
        "muted_gold",
        "soft_white",
        "soft_white",
        "midnight_black"
      ],
      "camera": {
        "mood": "intimate",
        "movement": "gentle_push",
        "lens": 100,
        "angle_bias": "slightly_top"
      },
      "objects_count": 3,
      "materials_count": 0,
      "audio_mapping_count": 6,
      "node_animation_count": 0,
      "object_names": [
        "reflective_void_stage",
        "luminous_arches",
        "floating_centerpiece"
      ],
      "audio_targets": [
        "reflective_void_stage:intensity:low",
        "reflective_void_stage:intensity:mid",
        "reflective_void_stage:intensity:high",
        "floating_centerpiece:intensity:low",
        "floating_centerpiece:intensity:mid",
        "floating_centerpiece:intensity:high"
      ]
    },
    {
      "file": "scene_spec_album_driven_normalized.json",
      "type": "json",
      "keys": [
        "audio_mapping",
        "camera_style",
        "environment",
        "hero_object",
        "lighting_style",
        "materials",
        "node_animation",
        "objects",
        "optimization",
        "palette",
        "render_strategy",
        "scene_name",
        "style_mode",
        "visual_concept"
      ],
      "scene_name": ". .",
      "visual_concept": "Cinematic abstract soul architecture",
      "style_mode": "stylized_cinematic_abstract",
      "environment": "reflective_void_stage",
      "lighting_style": "soft_volumetric_glow",
      "palette": [
        "#1F3A5F",
        "#B08D57",
        "#F2F0E8",
        "#0B0D12"
      ],
      "camera": {
        "mood": "intimate",
        "movement": "gentle_push",
        "lens": 65.0,
        "angle_bias": "slightly_top",
        "location": [
          0.0,
          -9.2,
          3.4
        ],
        "rotation_degrees": [
          72.0,
          0.0,
          0.0
        ]
      },
      "objects_count": 5,
      "materials_count": 5,
      "audio_mapping_count": 6,
      "node_animation_count": 7,
      "object_names": [
        "hero_core",
        "light_architecture",
        "reflective_floor",
        "floating_lights",
        "volumetric_shell"
      ],
      "audio_targets": [
        "hero_core:scale:low",
        "hero_core:rotation:mid",
        "light_architecture:rotation:mid",
        "light_architecture:emission:high",
        "floating_lights:intensity:high",
        "camera:pulse:beat"
      ]
    },
    {
      "file": "scene_spec_album_driven_raw.txt",
      "type": "text",
      "chars": 1319,
      "lines": 1
    },
    {
      "file": "scene_spec_from_npu.json",
      "type": "json",
      "keys": [
        "audio_mapping",
        "camera",
        "objects",
        "palette",
        "scene_name"
      ],
      "scene_name": ".",
      "visual_concept": null,
      "style_mode": null,
      "environment": null,
      "lighting_style": null,
      "palette": [
        "#20354D",
        "#38215A",
        "#4D2A37"
      ],
      "camera": {
        "location": [
          16,
          16,
          16
        ],
        "rotation": [
          0,
          540,
          360
        ],
        "lens": 455
      },
      "objects_count": 2,
      "materials_count": 0,
      "audio_mapping_count": 4,
      "node_animation_count": 0,
      "object_names": [
        "central_sphere",
        "."
      ],
      "audio_targets": [
        "central_sphere:material_select:beat",
        "light_cobinates_ring:strength:beat",
        "central_sphere:material_shader:beat",
        "light_cobinates_ring:strength:beat"
      ]
    },
    {
      "file": "scene_spec_from_npu_raw.txt",
      "type": "text",
      "chars": 1014,
      "lines": 53
    }
  ]
}
```
