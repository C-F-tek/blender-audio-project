# AI implementation draft is a patch plan, not a runnable script.
# Review the JSON draft for target_files, patch_plan, validation and notes.
