# NPU Long Context Chunk 78/94

- File: `Tools/npu/build_music_context.py`
- Part: `2`
- Lines: `255-490`

## Symbol Map
- Imports: `from __future__ import annotations`, `from pathlib import Path`, `argparse`, `hashlib`, `json`, `math`, `statistics`, `from datetime import datetime`
- Functions: `sha256_text(text)` line 39; `rel_to_root(path)` line 43; `read_text(path)` line 50; `load_json(path)` line 54; `round_float(value, digits)` line 59; `quantile(values, ratio)` line 69; `avg_top(values, ratio)` line 83; `value_stats(values)` line 90; `frame_values(frames, key)` line 115; `energy_stats(frames)` line 119; `dominant_band(stats)` line 129; `intensity_label(score)` line 138; `segment_score(stats)` line 150; `control_suggestions(stats, beat_count)` line 160; `split_segments(frames, segment_seconds, duration)` line 174; `sampled_frames(frames, max_rows)` line 187; `top_events(frames, limit)` line 208; `beats_in_range(beats, start, end)` line 233; `build_segments(analysis, segment_seconds)` line 237; `summarize_analysis(analysis_path, segment_seconds)` line 271; `scene_summary_from_json(path, data)` line 317; `load_scene_records(scene_files)` line 351; `markdown_table_rows(rows, keys)` line 385; `write_chunk(path, title, body)` line 392; `write_music_chunks(context, scene_records)` line 402; `write_music_context_md(context, scene_records, chunks)` line 478; `build_analysis_ai_context(context)` line 525; `write_blender_keyframe_alias(analysis_path, blender_keyframes_path)` line 558; `build_music_context(analysis_path, track_summary_path, scene_files, segment_seconds, compact_json_path, analysis_ai_context_path, blender_keyframes_path, run_ollama, ollama_model)` line 565; `main()` line 657
- Assignments: `ROOT`, `OUTPUT_DIR`, `OUT_DIR`, `CHUNK_DIR`, `DEFAULT_TRACK_STEM`, `DEFAULT_ANALYSIS`, `DEFAULT_TRACK_SUMMARY`, `DEFAULT_COMPACT_JSON`, `DEFAULT_ANALYSIS_AI_CONTEXT`, `DEFAULT_BLENDER_KEYFRAMES_JSON`, `OUT_MD`, `OUT_JSON`, `DEFAULT_SCENE_FILES`, `DEFAULT_SEGMENT_SECONDS`, `SAMPLE_ROWS_PER_SEGMENT`, `TOP_EVENTS_PER_SEGMENT`

## Content
```py
00255:                 "duration_sec": round_float(max(0.0, end - start), 3),
00256:                 "frame_count": len(segment_frames),
00257:                 "beat_count": len(beat_times),
00258:                 "dominant_band": dominant_band(stats),
00259:                 "intensity_score": score,
00260:                 "intensity": intensity_label(score),
00261:                 "stats": stats,
00262:                 "controls": control_suggestions(stats, len(beat_times)),
00263:                 "beat_times": beat_times,
00264:                 "top_events": top_events(segment_frames),
00265:                 "sampled_frames": sampled_frames(segment_frames),
00266:             }
00267:         )
00268:     return segments
00269: 
00270: 
00271: def summarize_analysis(analysis_path: Path, segment_seconds: float) -> tuple[dict, list[dict]]:
00272:     analysis = load_json(analysis_path)
00273:     meta = analysis.get("meta", {})
00274:     frames = analysis.get("frames", [])
00275:     beats = analysis.get("beats", [])
00276:     stats = energy_stats(frames)
00277:     segments = build_segments(analysis, segment_seconds)
00278: 
00279:     top_by_energy = sorted(segments, key=lambda item: item["intensity_score"], reverse=True)[:8]
00280:     top_by_onset = sorted(segments, key=lambda item: item["stats"]["onset"]["p98"], reverse=True)[:8]
00281: 
00282:     summary = {
00283:         "source": rel_to_root(analysis_path),
00284:         "track_name": analysis_path.stem.replace("_analysis", ""),
00285:         "meta": meta,
00286:         "frame_count": len(frames),
00287:         "beat_count": len(beats),
00288:         "segment_seconds": segment_seconds,
00289:         "segment_count": len(segments),
00290:         "overall_stats": stats,
00291:         "top_energy_segments": [
00292:             {
00293:                 "index": item["index"],
00294:                 "start_sec": item["start_sec"],
00295:                 "end_sec": item["end_sec"],
00296:                 "dominant_band": item["dominant_band"],
00297:                 "intensity_score": item["intensity_score"],
00298:                 "intensity": item["intensity"],
00299:             }
00300:             for item in top_by_energy
00301:         ],
00302:         "top_onset_segments": [
00303:             {
00304:                 "index": item["index"],
00305:                 "start_sec": item["start_sec"],
00306:                 "end_sec": item["end_sec"],
00307:                 "onset_p98": item["stats"]["onset"]["p98"],
00308:                 "beat_count": item["beat_count"],
00309:             }
00310:             for item in top_by_onset
00311:         ],
00312:     }
00313: 
00314:     return summary, segments
00315: 
00316: 
00317: def scene_summary_from_json(path: Path, data: dict) -> dict:
00318:     objects = data.get("objects", [])
00319:     materials = data.get("materials", [])
00320:     audio_mapping = data.get("audio_mapping", [])
00321:     node_animation = data.get("node_animation", [])
00322: 
00323:     return {
00324:         "file": rel_to_root(path),
00325:         "type": "json",
00326:         "keys": sorted(data.keys()),
00327:         "scene_name": data.get("scene_name"),
00328:         "visual_concept": data.get("visual_concept"),
00329:         "style_mode": data.get("style_mode"),
00330:         "environment": data.get("environment"),
00331:         "lighting_style": data.get("lighting_style"),
00332:         "palette": data.get("palette"),
00333:         "camera": data.get("camera") or data.get("camera_style"),
00334:         "objects_count": len(objects) if isinstance(objects, list) else 0,
00335:         "materials_count": len(materials) if isinstance(materials, list) else 0,
00336:         "audio_mapping_count": len(audio_mapping) if isinstance(audio_mapping, list) else 0,
00337:         "node_animation_count": len(node_animation) if isinstance(node_animation, list) else 0,
00338:         "object_names": [
00339:             item.get("name")
00340:             for item in objects
00341:             if isinstance(item, dict) and item.get("name")
00342:         ][:30],
00343:         "audio_targets": [
00344:             f"{item.get('target')}:{item.get('property')}:{item.get('band')}"
00345:             for item in audio_mapping
00346:             if isinstance(item, dict)
00347:         ][:40],
00348:     }
00349: 
00350: 
00351: def load_scene_records(scene_files: list[Path]) -> list[dict]:
00352:     records = []
00353:     for path in scene_files:
00354:         if not path.exists():
00355:             continue
00356: 
00357:         text = read_text(path)
00358:         record = {
00359:             "file": rel_to_root(path),
00360:             "chars": len(text),
00361:             "lines": text.count("\n") + 1 if text else 0,
00362:             "sha256": sha256_text(text),
00363:             "content": text,
00364:         }
00365: 
00366:         if path.suffix.lower() == ".json":
00367:             try:
00368:                 data = json.loads(text)
00369:             except json.JSONDecodeError as exc:
00370:                 record["summary"] = {"file": rel_to_root(path), "type": "json", "error": str(exc)}
00371:             else:
00372:                 record["summary"] = scene_summary_from_json(path, data)
00373:         else:
00374:             record["summary"] = {
00375:                 "file": rel_to_root(path),
00376:                 "type": "text",
00377:                 "chars": len(text),
00378:                 "lines": text.count("\n") + 1 if text else 0,
00379:             }
00380: 
00381:         records.append(record)
00382:     return records
00383: 
00384: 
00385: def markdown_table_rows(rows: list[dict], keys: list[str]) -> str:
00386:     lines = ["|" + "|".join(keys) + "|", "|" + "|".join(["---"] * len(keys)) + "|"]
00387:     for row in rows:
00388:         lines.append("|" + "|".join(str(row.get(key, "")) for key in keys) + "|")
00389:     return "\n".join(lines)
00390: 
00391: 
00392: def write_chunk(path: Path, title: str, body: str) -> dict:
00393:     text = f"# {title}\n\n{body.strip()}\n"
00394:     path.write_text(text, encoding="utf-8")
00395:     return {
00396:         "path": rel_to_root(path),
00397:         "chars": len(text),
00398:         "sha256": sha256_text(text),
00399:     }
00400: 
00401: 
00402: def write_music_chunks(context: dict, scene_records: list[dict]) -> list[dict]:
00403:     CHUNK_DIR.mkdir(parents=True, exist_ok=True)
00404:     for old_chunk in CHUNK_DIR.glob("chunk_*.md"):
00405:         old_chunk.unlink()
00406: 
00407:     chunks = []
00408:     chunk_index = 1
00409: 
00410:     overview = {
00411:         "analysis_summary": context.get("analysis_summary"),
00412:         "track_summary": context.get("track_summary"),
00413:         "scene_summaries": [record["summary"] for record in scene_records],
00414:     }
00415:     chunk_path = CHUNK_DIR / f"chunk_{chunk_index:03d}_music_overview.md"
00416:     chunks.append(
00417:         {
00418:             "index": chunk_index,
00419:             "kind": "overview",
00420:             **write_chunk(chunk_path, "NPU Music Overview", f"```json\n{json.dumps(overview, indent=2, ensure_ascii=False)}\n```"),
00421:         }
00422:     )
00423:     chunk_index += 1
00424: 
00425:     for segment in context.get("segments", []):
00426:         table = markdown_table_rows(
00427:             segment.get("sampled_frames", []),
00428:             ["time", "low", "mid", "high", "onset", "beat"],
00429:         )
00430:         payload = {
00431:             key: value
00432:             for key, value in segment.items()
00433:             if key not in {"sampled_frames"}
00434:         }
00435:         body = [
00436:             "## Segment Summary\n",
00437:             f"```json\n{json.dumps(payload, indent=2, ensure_ascii=False)}\n```\n",
00438:             "## Sampled Frame Curve\n",
00439:             table,
00440:         ]
00441:         chunk_path = CHUNK_DIR / f"chunk_{chunk_index:03d}_audio_segment_{segment['index']:03d}.md"
00442:         chunks.append(
00443:             {
00444:                 "index": chunk_index,
00445:                 "kind": "audio_segment",
00446:                 "segment_index": segment["index"],
00447:                 "start_sec": segment["start_sec"],
00448:                 "end_sec": segment["end_sec"],
00449:                 **write_chunk(chunk_path, f"NPU Audio Segment {segment['index']:03d}", "\n\n".join(body)),
00450:             }
00451:         )
00452:         chunk_index += 1
00453: 
00454:     for record in scene_records:
00455:         body = [
00456:             "## Scene Summary\n",
00457:             f"```json\n{json.dumps(record['summary'], indent=2, ensure_ascii=False)}\n```\n",
00458:             "## Source\n",
00459:             "```text\n",
00460:             record["content"],
00461:             "\n```",
00462:         ]
00463:         safe_name = Path(record["file"]).stem.replace(" ", "_")
00464:         chunk_path = CHUNK_DIR / f"chunk_{chunk_index:03d}_scene_{safe_name}.md"
00465:         chunks.append(
00466:             {
00467:                 "index": chunk_index,
00468:                 "kind": "scene_spec",
00469:                 "source": record["file"],
00470:                 **write_chunk(chunk_path, f"NPU Scene Spec {record['file']}", "".join(body)),
00471:             }
00472:         )
00473:         chunk_index += 1
00474: 
00475:     return chunks
00476: 
00477: 
00478: def write_music_context_md(context: dict, scene_records: list[dict], chunks: list[dict]) -> None:
00479:     summary = context.get("analysis_summary", {})
00480:     meta = summary.get("meta", {})
00481: 
00482:     lines = [
00483:         "# NPU Music Context\n\n",
00484:         f"Generated: `{context['created_at']}`\n\n",
00485:         "Purpose: compact long-context map for WAV analysis and generated scene JSON.\n\n",
00486:         "## Track\n",
00487:         f"- Name: `{summary.get('track_name')}`\n",
00488:         f"- Duration: `{round_float(meta.get('duration_sec'), 3)}` sec\n",
00489:         f"- FPS: `{meta.get('fps')}`\n",
00490:         f"- BPM: `{round_float(meta.get('estimated_tempo_bpm'), 3)}`\n",
```
