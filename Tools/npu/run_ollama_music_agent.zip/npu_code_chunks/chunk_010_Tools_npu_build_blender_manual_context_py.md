# NPU Long Context Chunk 10/94

- File: `Tools/npu/build_blender_manual_context.py`
- Part: `2`
- Lines: `269-326`

## Symbol Map
- Imports: `from __future__ import annotations`, `from pathlib import Path`, `from html.parser import HTMLParser`, `argparse`, `hashlib`, `json`, `re`, `from datetime import datetime`
- Classes: `TextExtractor` line 62 methods: __init__, handle_starttag, handle_endtag, handle_data, text
- Functions: `sha256_text(text)` line 95; `rel(path)` line 99; `slug(value)` line 106; `extract_text(path)` line 110; `score_text(path, text)` line 119; `score_path(path)` line 124; `split_text(text, max_chars)` line 144; `ensure_manual_root()` line 161; `source_group(path)` line 167; `iter_manual_files(manual_root)` line 175; `build_manual_context(limit_files, manual_root)` line 195; `main()` line 296
- Assignments: `ROOT`, `MANUAL_ROOT`, `LEGACY_MANUAL_DIR`, `MANUAL_README`, `OUT_DIR`, `CHUNK_DIR`, `OUT_INDEX`, `OUT_MANIFEST`, `MAX_CHARS`, `TEXT_EXTENSIONS`, `HTML_EXTENSIONS`, `KEYWORDS`, `README_TEXT`

## Content
```py
00269:         "supported_extensions": sorted(HTML_EXTENSIONS | TEXT_EXTENSIONS),
00270:         "discovered_file_count": len(manual_files),
00271:         "source_file_count": len(records),
00272:         "chunk_count": len(chunks),
00273:         "chunk_dir": rel(CHUNK_DIR),
00274:         "chunks": chunks,
00275:     }
00276: 
00277:     md = [
00278:         "# Blender Manual Context Index\n\n",
00279:         f"Generated: `{created_at}`\n\n",
00280:         "Purpose: offline local manual chunks for NPU/Ollama implementation drafts.\n\n",
00281:         f"Manual root: `{MANUAL_ROOT}`\n\n",
00282:         f"Discovered files: `{len(manual_files)}` | Indexed sources: `{len(records)}` | Chunks: `{len(chunks)}`\n\n",
00283:         "## Sources\n",
00284:     ]
00285:     for record in records[:40]:
00286:         md.append(f"- `{record['path']}` score `{record['score']}`\n")
00287:     md.append("\n## Chunks\n")
00288:     for chunk in chunks:
00289:         md.append(f"- `{chunk['path']}` from `{chunk['source']}`\n")
00290: 
00291:     OUT_MANIFEST.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
00292:     OUT_INDEX.write_text("".join(md), encoding="utf-8")
00293:     return manifest
00294: 
00295: 
00296: def main() -> None:
00297:     global MANUAL_ROOT, MANUAL_README
00298: 
00299:     parser = argparse.ArgumentParser()
00300:     parser.add_argument("--limit-files", type=int, default=80)
00301:     parser.add_argument("--manual-root", default=str(MANUAL_ROOT))
00302:     parser.add_argument(
00303:         "--ensure-only",
00304:         action="store_true",
00305:         help="Create the local manual folder and README without scanning/indexing manuals.",
00306:     )
00307:     args = parser.parse_args()
00308: 
00309:     if args.ensure_only:
00310:         MANUAL_ROOT = Path(args.manual_root)
00311:         MANUAL_README = MANUAL_ROOT / "README_MANUALI.md"
00312:         ensure_manual_root()
00313:         print(f"[OK] Manual root ready: {MANUAL_ROOT}")
00314:         print(f"[OK] Manual README: {MANUAL_README}")
00315:         return
00316: 
00317:     manifest = build_manual_context(limit_files=args.limit_files, manual_root=args.manual_root)
00318:     print(f"[OK] Manual root: {manifest['manual_root']}")
00319:     print(f"[OK] Manual README: {manifest['manual_readme']}")
00320:     print(f"[OK] Wrote: {OUT_INDEX}")
00321:     print(f"[OK] Wrote: {OUT_MANIFEST}")
00322:     print(f"[OK] Wrote chunks: {CHUNK_DIR} ({manifest['chunk_count']} files)")
00323: 
00324: 
00325: if __name__ == "__main__":
00326:     main()
```
