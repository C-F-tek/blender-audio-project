# NPU Long Context Chunk 59/94

- File: `Scripting/v61b/hotpatch/__init__.py`
- Part: `1`
- Lines: `1-3`

## Symbol Map
- Imports: `from runner import run_all`
- Assignments: `__all__`

## Content
```py
00001: from .runner import run_all
00002: 
00003: __all__ = ["run_all"]
```
