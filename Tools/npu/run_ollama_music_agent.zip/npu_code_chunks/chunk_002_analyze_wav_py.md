# NPU Long Context Chunk 2/94

- File: `analyze_wav.py`
- Part: `2`
- Lines: `213-241`

## Symbol Map
- Imports: `argparse`, `json`, `sys`, `from pathlib import Path`, `librosa`, `numpy`, `matplotlib.pyplot`
- Functions: `moving_average(x, window)` line 11; `robust_normalize(x, floor_percentile, ceil_percentile)` line 18; `compress_curve(x, gamma)` line 27; `band_envelope_from_stft(S_mag, freqs, fmin, fmax)` line 32; `resample_to_fps(times, values, fps, duration)` line 48; `build_music_context_if_available(json_path, output_dir, run_ollama, ollama_model)` line 54; `main()` line 92

## Content
```py
00213:     plt.plot(rt_onset_t, rt_onset, label="onset", alpha=0.8)
00214:     for bt in beat_times:
00215:         plt.axvline(bt, linestyle="--", alpha=0.15)
00216:     plt.title(f"Audio analysis: {input_path.name}")
00217:     plt.xlabel("Time (s)")
00218:     plt.ylabel("Normalized value")
00219:     plt.legend()
00220:     plt.tight_layout()
00221: 
00222:     png_path = output_dir / f"{input_path.stem}_analysis.png"
00223:     plt.savefig(png_path, dpi=150)
00224:     plt.close()
00225: 
00226:     print(f"[OK] JSON completo Blender salvato in: {json_path}")
00227:     print(f"[OK] Alias completo keyframe salvato in: {blender_keyframes_path}")
00228:     print(f"[OK] Grafico salvato in: {png_path}")
00229:     print(f"[INFO] BPM stimato: {float(tempo):.2f}")
00230: 
00231:     if not args.skip_music_context:
00232:         build_music_context_if_available(
00233:             json_path,
00234:             output_dir,
00235:             run_ollama=args.run_ollama_agent,
00236:             ollama_model=args.ollama_model,
00237:         )
00238: 
00239: 
00240: if __name__ == "__main__":
00241:     main()
```
