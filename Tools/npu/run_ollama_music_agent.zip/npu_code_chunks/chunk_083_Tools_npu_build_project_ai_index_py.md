# NPU Long Context Chunk 83/94

- File: `Tools/npu/build_project_ai_index.py`
- Part: `1`
- Lines: `1-266`

## Symbol Map
- Imports: `from __future__ import annotations`, `from datetime import datetime`, `from pathlib import Path`, `argparse`, `ast`, `hashlib`, `json`, `re`
- Functions: `sha256_text(text)` line 72; `sha256_file(path)` line 76; `rel_to_root(path)` line 84; `slugify(value, max_len)` line 88; `should_exclude(path)` line 93; `collect_project_files()` line 112; `target_name(target)` line 127; `extract_symbols(source)` line 135; `file_record(path)` line 178; `format_symbol_summary(record)` line 192; `numbered_lines(lines, start_line)` line 219; `split_source(source, max_chars)` line 223; `source_fingerprint(records)` line 245; `existing_cache_valid(fingerprint)` line 254; `write_readme()` line 268; `write_chunks(records, max_chunk_chars)` line 289; `write_index(records, chunks, created_at, fingerprint)` line 343; `build_project_ai_index(force, max_chunk_chars)` line 363; `main()` line 406
- Assignments: `ROOT`, `INDEX_DIR`, `PROJECT_INDEX_MD`, `PROJECT_MANIFEST_JSON`, `PROJECT_CHUNK_DIR`, `PATCH_LIBRARY_DIR`, `README_MD`, `DEFAULT_MAX_CHUNK_CHARS`, `TEXT_SUFFIXES`, `EXCLUDE_DIRS`, `EXCLUDE_PARTS`, `EXCLUDE_FILE_PREFIXES`, `MEDIA_SUFFIXES`

## Content
```py
00001: from __future__ import annotations
00002: 
00003: from datetime import datetime
00004: from pathlib import Path
00005: import argparse
00006: import ast
00007: import hashlib
00008: import json
00009: import re
00010: 
00011: 
00012: ROOT = Path(__file__).resolve().parents[2]
00013: INDEX_DIR = ROOT / "indexAI"
00014: PROJECT_INDEX_MD = INDEX_DIR / "project_code_index.md"
00015: PROJECT_MANIFEST_JSON = INDEX_DIR / "project_code_manifest.json"
00016: PROJECT_CHUNK_DIR = INDEX_DIR / "project_code_chunks"
00017: PATCH_LIBRARY_DIR = INDEX_DIR / "patch_library"
00018: README_MD = INDEX_DIR / "README.md"
00019: 
00020: DEFAULT_MAX_CHUNK_CHARS = 12000
00021: TEXT_SUFFIXES = {".py", ".ps1", ".md", ".json", ".txt", ".cfg", ".ini", ".toml", ".yaml", ".yml"}
00022: EXCLUDE_DIRS = {
00023:     ".git",
00024:     ".mypy_cache",
00025:     ".pytest_cache",
00026:     ".ruff_cache",
00027:     ".venv",
00028:     "__pycache__",
00029:     "cache",
00030:     "indexAI",
00031:     "node_modules",
00032:     "output",
00033:     "renders",
00034:     "venv",
00035:     "venvs",
00036: }
00037: EXCLUDE_PARTS = {
00038:     ".npucache",
00039:     "npu_blender_manual_chunks",
00040:     "npu_code_chunks",
00041:     "npu_music_chunks",
00042: }
00043: EXCLUDE_FILE_PREFIXES = {
00044:     "npu_code_context",
00045:     "npu_code_index",
00046:     "npu_context_for_aider",
00047:     "npu_music_context",
00048:     "npu_music_context_for_aider",
00049:     "npu_dual_ai_chunk_notes",
00050:     "npu_dual_ai_technical_notes",
00051:     "ollama_music_insights",
00052:     "dual_ai_blender_agent_brief",
00053:     "generated_implementation_notes",
00054: }
00055: MEDIA_SUFFIXES = {
00056:     ".wav",
00057:     ".mp3",
00058:     ".flac",
00059:     ".mp4",
00060:     ".mov",
00061:     ".avi",
00062:     ".mkv",
00063:     ".png",
00064:     ".jpg",
00065:     ".jpeg",
00066:     ".exr",
00067:     ".blend",
00068:     ".blend1",
00069: }
00070: 
00071: 
00072: def sha256_text(text: str) -> str:
00073:     return hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest()
00074: 
00075: 
00076: def sha256_file(path: Path) -> str:
00077:     digest = hashlib.sha256()
00078:     with path.open("rb") as handle:
00079:         for block in iter(lambda: handle.read(1024 * 1024), b""):
00080:             digest.update(block)
00081:     return digest.hexdigest()
00082: 
00083: 
00084: def rel_to_root(path: Path) -> str:
00085:     return str(path.resolve().relative_to(ROOT.resolve())).replace("\\", "/")
00086: 
00087: 
00088: def slugify(value: str, max_len: int = 80) -> str:
00089:     slug = re.sub(r"[^A-Za-z0-9]+", "_", value).strip("_")
00090:     return slug[:max_len] or "chunk"
00091: 
00092: 
00093: def should_exclude(path: Path) -> bool:
00094:     rel_parts = path.resolve().relative_to(ROOT.resolve()).parts
00095:     if any(part in EXCLUDE_DIRS or part in EXCLUDE_PARTS for part in rel_parts[:-1]):
00096:         return True
00097: 
00098:     suffix = path.suffix.lower()
00099:     if suffix in MEDIA_SUFFIXES or suffix not in TEXT_SUFFIXES:
00100:         return True
00101: 
00102:     stem = path.stem
00103:     if any(stem.startswith(prefix) for prefix in EXCLUDE_FILE_PREFIXES):
00104:         return True
00105: 
00106:     if path.name.endswith(".pyc") or path.name.endswith(".pyo"):
00107:         return True
00108: 
00109:     return False
00110: 
00111: 
00112: def collect_project_files() -> list[Path]:
00113:     files: list[Path] = []
00114:     for path in ROOT.rglob("*"):
00115:         if not path.is_file():
00116:             continue
00117:         try:
00118:             path.resolve().relative_to(ROOT.resolve())
00119:         except ValueError:
00120:             continue
00121:         if should_exclude(path):
00122:             continue
00123:         files.append(path.resolve())
00124:     return sorted(files, key=lambda item: rel_to_root(item).lower())
00125: 
00126: 
00127: def target_name(target: ast.expr) -> str | None:
00128:     if isinstance(target, ast.Name):
00129:         return target.id
00130:     if isinstance(target, ast.Attribute):
00131:         return target.attr
00132:     return None
00133: 
00134: 
00135: def extract_symbols(source: str) -> dict:
00136:     symbols = {"imports": [], "functions": [], "classes": [], "assignments": []}
00137:     try:
00138:         tree = ast.parse(source)
00139:     except SyntaxError as exc:
00140:         symbols["syntax_error"] = str(exc)
00141:         return symbols
00142: 
00143:     for node in tree.body:
00144:         if isinstance(node, ast.Import):
00145:             symbols["imports"].extend(alias.name for alias in node.names)
00146:         elif isinstance(node, ast.ImportFrom):
00147:             module = node.module or ""
00148:             names = ", ".join(alias.name for alias in node.names)
00149:             symbols["imports"].append(f"from {module} import {names}")
00150:         elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
00151:             symbols["functions"].append(
00152:                 {
00153:                     "name": node.name,
00154:                     "line": node.lineno,
00155:                     "args": [arg.arg for arg in node.args.args],
00156:                     "async": isinstance(node, ast.AsyncFunctionDef),
00157:                 }
00158:             )
00159:         elif isinstance(node, ast.ClassDef):
00160:             methods = []
00161:             for child in node.body:
00162:                 if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
00163:                     methods.append({"name": child.name, "line": child.lineno})
00164:             symbols["classes"].append({"name": node.name, "line": node.lineno, "methods": methods})
00165:         elif isinstance(node, ast.Assign):
00166:             for target in node.targets:
00167:                 name = target_name(target)
00168:                 if name:
00169:                     symbols["assignments"].append(name)
00170:         elif isinstance(node, ast.AnnAssign):
00171:             name = target_name(node.target)
00172:             if name:
00173:                 symbols["assignments"].append(name)
00174: 
00175:     return symbols
00176: 
00177: 
00178: def file_record(path: Path) -> dict:
00179:     source = path.read_text(encoding="utf-8", errors="replace")
00180:     record = {
00181:         "file": rel_to_root(path),
00182:         "suffix": path.suffix.lower(),
00183:         "lines": source.count("\n") + 1 if source else 0,
00184:         "chars": len(source),
00185:         "sha256": sha256_text(source),
00186:     }
00187:     if path.suffix.lower() == ".py":
00188:         record["symbols"] = extract_symbols(source)
00189:     return record
00190: 
00191: 
00192: def format_symbol_summary(record: dict) -> str:
00193:     symbols = record.get("symbols")
00194:     if not symbols:
00195:         return ""
00196:     lines: list[str] = []
00197:     if symbols.get("syntax_error"):
00198:         lines.append(f"- Syntax error: `{symbols['syntax_error']}`")
00199:     if symbols.get("imports"):
00200:         lines.append("- Imports: " + ", ".join(f"`{item}`" for item in symbols["imports"][:24]))
00201:     if symbols.get("classes"):
00202:         bits = []
00203:         for item in symbols["classes"][:20]:
00204:             methods = ", ".join(method["name"] for method in item.get("methods", [])[:10])
00205:             bits.append(f"`{item['name']}` line {item['line']}" + (f" methods: {methods}" if methods else ""))
00206:         lines.append("- Classes: " + "; ".join(bits))
00207:     if symbols.get("functions"):
00208:         bits = []
00209:         for item in symbols["functions"][:44]:
00210:             args = ", ".join(item["args"])
00211:             prefix = "async " if item.get("async") else ""
00212:             bits.append(f"`{prefix}{item['name']}({args})` line {item['line']}")
00213:         lines.append("- Functions: " + "; ".join(bits))
00214:     if symbols.get("assignments"):
00215:         lines.append("- Assignments: " + ", ".join(f"`{name}`" for name in symbols["assignments"][:80]))
00216:     return "\n".join(lines)
00217: 
00218: 
00219: def numbered_lines(lines: list[str], start_line: int) -> str:
00220:     return "\n".join(f"{line_no:05d}: {line}" for line_no, line in enumerate(lines, start_line))
00221: 
00222: 
00223: def split_source(source: str, max_chars: int) -> list[tuple[int, int, list[str]]]:
00224:     lines = source.splitlines()
00225:     if not lines:
00226:         return [(1, 1, [])]
00227:     chunks: list[tuple[int, int, list[str]]] = []
00228:     current: list[str] = []
00229:     current_len = 0
00230:     start_line = 1
00231:     for line_no, line in enumerate(lines, 1):
00232:         cost = len(line) + 9
00233:         if current and current_len + cost > max_chars:
00234:             chunks.append((start_line, line_no - 1, current))
00235:             current = []
00236:             current_len = 0
00237:             start_line = line_no
00238:         current.append(line)
00239:         current_len += cost
00240:     if current:
00241:         chunks.append((start_line, start_line + len(current) - 1, current))
00242:     return chunks
00243: 
00244: 
00245: def source_fingerprint(records: list[dict]) -> str:
00246:     payload = json.dumps(
00247:         [{"file": item["file"], "sha256": item["sha256"]} for item in records],
00248:         ensure_ascii=False,
00249:         sort_keys=True,
00250:     )
00251:     return sha256_text(payload)
00252: 
00253: 
00254: def existing_cache_valid(fingerprint: str) -> bool:
00255:     if not PROJECT_MANIFEST_JSON.exists() or not PROJECT_INDEX_MD.exists() or not PROJECT_CHUNK_DIR.exists():
00256:         return False
00257:     try:
00258:         manifest = json.loads(PROJECT_MANIFEST_JSON.read_text(encoding="utf-8"))
00259:     except Exception:
00260:         return False
00261:     if manifest.get("source_fingerprint") != fingerprint:
00262:         return False
00263:     expected = manifest.get("chunk_count", 0)
00264:     actual = len(list(PROJECT_CHUNK_DIR.glob("chunk_*.md")))
00265:     return expected == actual
00266: 
```
