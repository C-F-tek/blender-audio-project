# NPU Long Context Chunk 64/94

- File: `Scripting/v61b/hotpatch/diagnostics.py`
- Part: `2`
- Lines: `245-286`

## Symbol Map
- Imports: `bpy`, `from common import ANALYSIS_JSON_PATH, cfg_value, load_analysis`, `from spaziotempo.core.registry import LAYER_ORDER, LAYER_SPECS, PROJECT_ROOT_COLLECTION`
- Functions: `text_report(name, lines)` line 17; `has_object(name)` line 24; `count_objects(prefix)` line 28; `collection_exists(name)` line 32; `layer_collection_counts()` line 36; `scene_frame_count(scene)` line 45; `material_node_exists(node_name)` line 49; `modifier_exists(mod_name)` line 56; `point_cache_state(cache)` line 64; `particle_cache_state(ps)` line 72; `analyze_rebuild_need()` line 83; `analyze_optimizer()` line 169
- Assignments: `STRUCTURAL_OBJECTS`

## Content
```py
00245:             for key, count in counts.items()
00246:             if count
00247:         ]
00248:         ok.append("Layer classification: " + ", ".join(visible_counts))
00249:     else:
00250:         suggestions.append("Run Hot Update All once to populate ST_* layer collections and object metadata.")
00251: 
00252:     render = scene.render
00253:     if getattr(render, "use_motion_blur", False):
00254:         suggestions.append("Motion blur is on: highest visual cost after volumetrics. Use YT Fast profiles for tests.")
00255: 
00256:     eevee = getattr(scene, "eevee", None)
00257:     if eevee is not None and hasattr(eevee, "volumetric_samples"):
00258:         samples = int(eevee.volumetric_samples)
00259:         if samples > 48:
00260:             suggestions.append(f"Volumetric samples are {samples}: consider 48 final / 24 fast.")
00261:         else:
00262:             ok.append(f"Volumetric samples: {samples}")
00263: 
00264:     lines = [
00265:         "SPAZIOTEMPO OPTIMIZER CHECK",
00266:         "=" * 52,
00267:         f"Result: {'CHECK CACHE / BAKE' if warnings else 'NO REQUIRED BAKE FOUND'}",
00268:         "",
00269:     ]
00270:     if warnings:
00271:         lines.append("Warnings:")
00272:         lines.extend(f"- {item}" for item in warnings)
00273:         lines.append("")
00274:     if suggestions:
00275:         lines.append("Suggestions:")
00276:         lines.extend(f"- {item}" for item in suggestions)
00277:         lines.append("")
00278:     lines.append("Checked OK:")
00279:     lines.extend(f"- {item}" for item in ok)
00280: 
00281:     text_report("SPAZIOTEMPO_OPTIMIZER_REPORT", lines)
00282:     return {
00283:         "warnings": warnings,
00284:         "suggestions": suggestions,
00285:         "report": "\n".join(lines),
00286:     }
```
