# NPU Long Context Chunk 41/94

- File: `Scripting/v61b/scene_tuning_panel.py`
- Part: `4`
- Lines: `725-906`

## Symbol Map
- Imports: `json`, `sys`, `traceback`, `from pathlib import Path`, `bpy`, `from bpy.props import BoolProperty, FloatProperty, PointerProperty, StringProperty`
- Classes: `ST_TuningSettings` line 770; `ST_OT_apply_tuning` line 822 methods: execute; `ST_OT_keyframe_tuning` line 833 methods: execute; `ST_OT_scale_animation` line 844 methods: execute; `ST_OT_apply_runtime_profile` line 855 methods: execute; `ST_OT_hot_update_scene` line 871 methods: execute; `ST_OT_rebuild_restart_check` line 895 methods: execute; `ST_OT_optimizer_check` line 920 methods: execute; `ST_OT_load_image_sequence` line 943 methods: execute; `ST_OT_encode_ffmpeg` line 965 methods: execute; `ST_OT_encode_ffmpeg_shell` line 987 methods: execute; `ST_OT_save_preset` line 1016 methods: execute; `ST_OT_load_preset` line 1027 methods: execute; `ST_OT_open_guide_text` line 1043 methods: execute; `ST_OT_select_group` line 1062 methods: execute; `ST_PT_tuning_panel` line 1098 methods: draw
- Functions: `resolve_script_dir()` line 20; `iter_action_fcurves(action)` line 56; `find_obj(name)` line 88; `objects_with_prefix(prefix)` line 92; `particle_emitters()` line 96; `particle_source_objects()` line 106; `store_base_vector(obj, key, value)` line 117; `store_base_float(idblock, key, value)` line 123; `set_scale_from_base(obj, factor, key)` line 132; `keyframe_if_possible(idblock, data_path, frame)` line 140; `find_material(name)` line 147; `find_node(material_name, node_name)` line 151; `set_value_node(material_name, node_name, value)` line 158; `set_input_node(material_name, node_name, input_name, value)` line 169; `keyframe_socket(socket, frame)` line 180; `get_scene_compositor_tree(scene)` line 186; `clamp_value(value, min_value, max_value)` line 194; `normalize_runtime_profile(profile)` line 198; `runtime_profile_label(profile)` line 244; `apply_runtime_profile(context, profile)` line 257; `all_particle_settings()` line 442; `apply_tuning(context, insert_keyframes)` line 454; `scale_fcurve_values(idblock, predicate, factor)` line 669; `scale_full_animation(context)` line 685; `preset_data(settings)` line 721; `load_preset_data(settings, data)` line 764; `register()` line 1239; `unregister()` line 1254
- Assignments: `bl_info`, `SCRIPT_DIR`, `PRESET_PATH`, `GUIDE_PATH`, `HOT_UPDATE_PATH`, `ENCODE_SEQUENCE_PATH`, `ENCODE_FFMPEG_PATH`, `classes`

## Content
```py
00725:         "hero_fine_deform": settings.hero_fine_deform,
00726:         "hero_wave": settings.hero_wave,
00727:         "hero_twist": settings.hero_twist,
00728:         "hero_mat_emission": settings.hero_mat_emission,
00729:         "hero_mat_bump": settings.hero_mat_bump,
00730:         "hero_mat_roughness": settings.hero_mat_roughness,
00731:         "hero_mat_noise": settings.hero_mat_noise,
00732:         "aura_deform": settings.aura_deform,
00733:         "aura_detail": settings.aura_detail,
00734:         "aura_pulse": settings.aura_pulse,
00735:         "fog_density": settings.fog_density,
00736:         "fog_emission": settings.fog_emission,
00737:         "fog_noise_scale": settings.fog_noise_scale,
00738:         "fog_scale_xy": settings.fog_scale_xy,
00739:         "fog_scale_z": settings.fog_scale_z,
00740:         "backdrop_emission": settings.backdrop_emission,
00741:         "backdrop_noise_scale": settings.backdrop_noise_scale,
00742:         "backdrop_scale": settings.backdrop_scale,
00743:         "floor_scale": settings.floor_scale,
00744:         "camera_fstop": settings.camera_fstop,
00745:         "youtube_final": settings.youtube_final,
00746:         "runtime_profile": settings.runtime_profile,
00747:         "motion_blur": settings.motion_blur,
00748:         "rhythm_light_power": settings.rhythm_light_power,
00749:         "compositor_glow": settings.compositor_glow,
00750:         "compositor_lens": settings.compositor_lens,
00751:         "particle_size": settings.particle_size,
00752:         "particle_force": settings.particle_force,
00753:         "letter_source_scale": settings.letter_source_scale,
00754:         "show_fog_cube": settings.show_fog_cube,
00755:         "show_backdrop": settings.show_backdrop,
00756:         "render_backdrop": settings.render_backdrop,
00757:         "show_floor": settings.show_floor,
00758:         "render_floor": settings.render_floor,
00759:         "show_emitters": settings.show_emitters,
00760:         "show_particle_sources": settings.show_particle_sources,
00761:     }
00762: 
00763: 
00764: def load_preset_data(settings, data):
00765:     for key, value in data.items():
00766:         if hasattr(settings, key):
00767:             setattr(settings, key, value)
00768: 
00769: 
00770: class ST_TuningSettings(bpy.types.PropertyGroup):
00771:     hero_scale: FloatProperty(name="Hero scale", default=1.0, min=0.20, max=3.0, precision=3)
00772:     hero_deform: FloatProperty(name="Hero deform", default=1.0, min=0.0, max=4.0, precision=3)
00773:     hero_fine_deform: FloatProperty(name="Hero fine", default=1.0, min=0.0, max=4.0, precision=3)
00774:     hero_wave: FloatProperty(name="Hero wave", default=1.0, min=0.0, max=4.0, precision=3)
00775:     hero_twist: FloatProperty(name="Hero twist", default=1.0, min=0.0, max=4.0, precision=3)
00776:     hero_mat_emission: FloatProperty(name="Hero material light", default=1.0, min=0.0, max=4.0, precision=3)
00777:     hero_mat_bump: FloatProperty(name="Hero material bump", default=1.0, min=0.0, max=4.0, precision=3)
00778:     hero_mat_roughness: FloatProperty(name="Hero material rough", default=1.0, min=0.10, max=2.0, precision=3)
00779:     hero_mat_noise: FloatProperty(name="Hero material noise", default=1.0, min=0.10, max=4.0, precision=3)
00780: 
00781:     aura_deform: FloatProperty(name="Aura deform", default=0.45, min=0.0, max=1.0, precision=3)
00782:     aura_detail: FloatProperty(name="Aura detail", default=0.35, min=0.0, max=1.0, precision=3)
00783:     aura_pulse: FloatProperty(name="Aura pulse", default=0.35, min=0.0, max=1.0, precision=3)
00784: 
00785:     fog_density: FloatProperty(name="Fog density", default=0.035, min=0.0, max=0.55, precision=4)
00786:     fog_emission: FloatProperty(name="Fog emission", default=0.004, min=0.0, max=0.12, precision=4)
00787:     fog_noise_scale: FloatProperty(name="Fog noise", default=0.9, min=0.10, max=12.0, precision=3)
00788:     fog_scale_xy: FloatProperty(name="Fog XY", default=1.0, min=0.20, max=2.20, precision=3)
00789:     fog_scale_z: FloatProperty(name="Fog Z", default=1.0, min=0.20, max=2.40, precision=3)
00790: 
00791:     backdrop_emission: FloatProperty(name="Backdrop light", default=0.175, min=0.0, max=0.80, precision=4)
00792:     backdrop_noise_scale: FloatProperty(name="Backdrop noise", default=2.4, min=0.10, max=12.0, precision=3)
00793:     backdrop_scale: FloatProperty(name="Backdrop scale", default=1.0, min=0.20, max=2.40, precision=3)
00794:     floor_scale: FloatProperty(name="Floor scale", default=1.0, min=0.20, max=3.0, precision=3)
00795: 
00796:     camera_fstop: FloatProperty(name="Camera f-stop", default=6.5, min=1.0, max=16.0, precision=2)
00797:     rhythm_light_power: FloatProperty(name="Accent emission", default=1.0, min=0.0, max=4.0, precision=3)
00798:     compositor_glow: FloatProperty(name="Compositor glow", default=1.0, min=0.10, max=4.0, precision=3)
00799:     compositor_lens: FloatProperty(name="Compositor lens", default=1.0, min=0.0, max=4.0, precision=3)
00800: 
00801:     particle_size: FloatProperty(name="Particle size", default=1.0, min=0.05, max=5.0, precision=3)
00802:     particle_force: FloatProperty(name="Particle force", default=1.0, min=0.0, max=5.0, precision=3)
00803:     letter_source_scale: FloatProperty(name="Letter source scale", default=1.0, min=0.10, max=3.0, precision=3)
00804: 
00805:     anim_hero_deform_factor: FloatProperty(name="Anim hero deform", default=1.0, min=0.0, max=4.0, precision=3)
00806:     anim_aura_factor: FloatProperty(name="Anim aura", default=1.0, min=0.0, max=4.0, precision=3)
00807:     anim_particle_size_factor: FloatProperty(name="Anim particle size", default=1.0, min=0.05, max=5.0, precision=3)
00808:     anim_particle_force_factor: FloatProperty(name="Anim particle force", default=1.0, min=0.0, max=5.0, precision=3)
00809: 
00810:     show_fog_cube: BoolProperty(name="Show fog cube", default=False)
00811:     show_backdrop: BoolProperty(name="Show backdrop", default=True)
00812:     render_backdrop: BoolProperty(name="Render backdrop", default=True)
00813:     show_floor: BoolProperty(name="Show floor", default=True)
00814:     render_floor: BoolProperty(name="Render floor", default=False)
00815:     show_emitters: BoolProperty(name="Show emitters", default=False)
00816:     show_particle_sources: BoolProperty(name="Show source objects", default=False)
00817:     motion_blur: BoolProperty(name="Motion blur", default=False)
00818:     youtube_final: BoolProperty(name="YouTube final", default=False)
00819:     runtime_profile: StringProperty(name="Runtime profile", default="Preview")
00820: 
00821: 
00822: class ST_OT_apply_tuning(bpy.types.Operator):
00823:     bl_idname = "spaziotempo.apply_tuning"
00824:     bl_label = "Apply Live Values"
00825:     bl_options = {'REGISTER', 'UNDO'}
00826: 
00827:     def execute(self, context):
00828:         apply_tuning(context, insert_keyframes=False)
00829:         self.report({'INFO'}, "Spaziotempo tuning applied to current scene.")
00830:         return {'FINISHED'}
00831: 
00832: 
00833: class ST_OT_keyframe_tuning(bpy.types.Operator):
00834:     bl_idname = "spaziotempo.keyframe_tuning"
00835:     bl_label = "Apply + Keyframe"
00836:     bl_options = {'REGISTER', 'UNDO'}
00837: 
00838:     def execute(self, context):
00839:         apply_tuning(context, insert_keyframes=True)
00840:         self.report({'INFO'}, f"Spaziotempo values keyframed at frame {context.scene.frame_current}.")
00841:         return {'FINISHED'}
00842: 
00843: 
00844: class ST_OT_scale_animation(bpy.types.Operator):
00845:     bl_idname = "spaziotempo.scale_animation"
00846:     bl_label = "Scale Existing FCurves"
00847:     bl_options = {'REGISTER', 'UNDO'}
00848: 
00849:     def execute(self, context):
00850:         changed = scale_full_animation(context)
00851:         self.report({'INFO'}, f"Scaled {changed} keyframe values.")
00852:         return {'FINISHED'}
00853: 
00854: 
00855: class ST_OT_apply_runtime_profile(bpy.types.Operator):
00856:     bl_idname = "spaziotempo.apply_runtime_profile"
00857:     bl_label = "Apply Runtime Profile"
00858:     bl_options = {'REGISTER', 'UNDO'}
00859: 
00860:     final_for_youtube: bpy.props.BoolProperty(default=False)
00861:     profile: bpy.props.StringProperty(default="")
00862: 
00863:     def execute(self, context):
00864:         profile = self.profile or ("YOUTUBE_4K" if self.final_for_youtube else "PREVIEW")
00865:         apply_runtime_profile(context, profile)
00866:         label = runtime_profile_label(profile)
00867:         self.report({'INFO'}, f"{label} profile applied to current scene.")
00868:         return {'FINISHED'}
00869: 
00870: 
00871: class ST_OT_hot_update_scene(bpy.types.Operator):
00872:     bl_idname = "spaziotempo.hot_update_scene"
00873:     bl_label = "Hot Update Scene"
00874:     bl_options = {'REGISTER', 'UNDO'}
00875: 
00876:     mode: bpy.props.StringProperty(default="ALL")
00877: 
00878:     def execute(self, context):
00879:         if not HOT_UPDATE_PATH.exists():
00880:             self.report({'WARNING'}, f"Hot update script not found: {HOT_UPDATE_PATH}")
00881:             return {'CANCELLED'}
00882: 
00883:         try:
00884:             code = compile(HOT_UPDATE_PATH.read_text(encoding="utf-8"), str(HOT_UPDATE_PATH), "exec")
00885:             exec(code, {"__file__": str(HOT_UPDATE_PATH), "__name__": "__main__", "HOTPATCH_MODE": self.mode})
00886:         except Exception as exc:
00887:             traceback.print_exc()
00888:             self.report({'ERROR'}, f"Hot update failed: {exc}")
00889:             return {'CANCELLED'}
00890: 
00891:         self.report({'INFO'}, f"Hot update {self.mode} complete.")
00892:         return {'FINISHED'}
00893: 
00894: 
00895: class ST_OT_rebuild_restart_check(bpy.types.Operator):
00896:     bl_idname = "spaziotempo.rebuild_restart_check"
00897:     bl_label = "Rebuild / Restart Check"
00898:     bl_options = {'REGISTER'}
00899: 
00900:     def execute(self, context):
00901:         try:
00902:             sys.modules.pop("hotpatch.diagnostics", None)
00903:             from hotpatch.diagnostics import analyze_rebuild_need
00904: 
00905:             result = analyze_rebuild_need()
00906:         except Exception as exc:
```
