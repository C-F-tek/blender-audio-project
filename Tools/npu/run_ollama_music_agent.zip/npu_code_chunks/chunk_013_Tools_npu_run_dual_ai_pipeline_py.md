# NPU Long Context Chunk 13/94

- File: `Tools/npu/run_dual_ai_pipeline.py`
- Part: `3`
- Lines: `476-702`

## Symbol Map
- Imports: `from __future__ import annotations`, `from pathlib import Path`, `argparse`, `json`, `subprocess`, `from datetime import datetime`, `from typing import Any`, `from build_music_context import build_music_context`, `from build_npu_code_context import main`, `from build_blender_manual_context import build_manual_context`, `from build_project_ai_index import PROJECT_INDEX_MD, PROJECT_MANIFEST_JSON, build_project_ai_index`, `from npu_runtime import DEFAULT_MODEL_DIR, DEFAULT_NPU_PYTHON, npu_preflight, write_npu_preflight_report`, `from ollama_runtime import OllamaModelManager, parse_json_response`, `from run_ollama_music_agent import build_prompt`, `from run_ollama_music_agent import markdown_from_insights`
- Functions: `read_text(path)` line 52; `read_json(path)` line 56; `write_json(path, data)` line 62; `update_track_paths(track_stem, analysis_ai_context)` line 67; `apply_default_input_paths(args)` line 79; `validate_input_files(args)` line 92; `looks_degraded_text(text)` line 112; `deterministic_technical_notes(music_context, project_manifest, reason)` line 128; `run_npu_technical_pass(args)` line 177; `build_creative_scene_prompt(music_context, npu_notes, project_index)` line 221; `build_merge_prompt(music_context, npu_notes, creative, technical)` line 297; `build_implementation_prompt(plan, npu_notes, include_manual)` line 353; `build_implementation_retry_prompt(plan, invalid_draft, validation)` line 425; `safe_parse_json(text, fallback_key)` line 504; `get_indexed_project_files()` line 512; `validate_implementation_draft(draft)` line 517; `build_fallback_implementation_draft(reason, model)` line 572; `normalize_implementation_draft(draft, model)` line 649; `generate_implementation_draft_with_retry(manager, model_name, implementation_prompt, plan, max_new_tokens)` line 664; `write_brief(plan, creative, technical, npu_notes)` line 706; `write_implementation_draft(draft)` line 729; `main()` line 759
- Assignments: `ROOT`, `TOOLS_DIR`, `OUTPUT_DIR`, `DEFAULT_TRACK_STEM`, `TRACK_STEM`, `MUSIC_AI_CONTEXT`, `DUAL_PLAN_JSON`, `DUAL_BRIEF_MD`, `OLLAMA_INSIGHTS_JSON`, `OLLAMA_INSIGHTS_MD`, `NPU_TECH_MD`, `NPU_PREFLIGHT_JSON`, `IMPLEMENTATION_DRAFT_JSON`, `IMPLEMENTATION_SCRIPT`, `IMPLEMENTATION_NOTES`, `NPU_IMPLEMENTATION_NOTES`, `ALLOWED_NEW_PREFIXES`, `PREFERRED_IMPLEMENTATION_FILES`

## Content
```py
00476:       "requires_full_reload": false
00477:     }}
00478:   ],
00479:   "patch_plan": [
00480:     {{
00481:       "file": "Scripting/v61b/materials.py",
00482:       "function_or_section": "...",
00483:       "change": "...",
00484:       "why": "...",
00485:       "risk": "low",
00486:       "test_or_check": "..."
00487:     }}
00488:   ],
00489:   "new_files_allowed": [
00490:     "Scripting/v61b/hotpatch/...",
00491:     "indexAI/patch_library/..."
00492:   ],
00493:   "hotpatch_candidate_script": "",
00494:   "notes": ["..."],
00495:   "files_to_review_before_applying": ["..."],
00496:   "expected_panel_or_operator": "..."
00497: }}
00498: 
00499: DATI:
00500: {json.dumps(payload, indent=2, ensure_ascii=False)}
00501: """.strip()
00502: 
00503: 
00504: def safe_parse_json(text: str, fallback_key: str) -> dict[str, Any]:
00505:     try:
00506:         parsed = parse_json_response(text)
00507:         return parsed if isinstance(parsed, dict) else {fallback_key: text, "parse_error": True}
00508:     except Exception:
00509:         return {fallback_key: text, "parse_error": True}
00510: 
00511: 
00512: def get_indexed_project_files() -> set[str]:
00513:     manifest = read_json(PROJECT_MANIFEST_JSON) if PROJECT_MANIFEST_JSON.exists() else {}
00514:     return {item.get("file") for item in manifest.get("files", []) if item.get("file")}
00515: 
00516: 
00517: def validate_implementation_draft(draft: dict[str, Any]) -> dict[str, Any]:
00518:     indexed_files = get_indexed_project_files()
00519: 
00520:     issues: list[str] = []
00521:     target_files = draft.get("target_files") or []
00522:     patch_plan = draft.get("patch_plan") or []
00523: 
00524:     if draft.get("implementation_kind") != "existing_project_patch_plan":
00525:         issues.append("implementation_kind should be existing_project_patch_plan.")
00526: 
00527:     if not isinstance(target_files, list) or not target_files:
00528:         issues.append("No target_files entries were provided.")
00529:     if not isinstance(patch_plan, list) or not patch_plan:
00530:         issues.append("No patch_plan entries were provided.")
00531: 
00532:     if isinstance(target_files, list):
00533:         for item in target_files:
00534:             if not isinstance(item, dict):
00535:                 issues.append("A target_files entry is not an object.")
00536:                 continue
00537:             file_name = str(item.get("file") or "").replace("\\", "/")
00538:             if not file_name:
00539:                 issues.append("A target_files entry has no file.")
00540:                 continue
00541:             is_existing = file_name in indexed_files
00542:             is_allowed_new = file_name.startswith(ALLOWED_NEW_PREFIXES)
00543:             if not is_existing and not is_allowed_new:
00544:                 issues.append(f"Target file is not in project index and not an allowed new file: {file_name}")
00545: 
00546:     if isinstance(patch_plan, list):
00547:         for item in patch_plan:
00548:             if not isinstance(item, dict):
00549:                 issues.append("A patch_plan entry is not an object.")
00550:                 continue
00551:             file_name = str(item.get("file") or "").replace("\\", "/")
00552:             if not file_name:
00553:                 issues.append("A patch_plan entry has no file.")
00554:                 continue
00555:             is_existing = file_name in indexed_files
00556:             is_allowed_new = file_name.startswith(ALLOWED_NEW_PREFIXES)
00557:             if not is_existing and not is_allowed_new:
00558:                 issues.append(f"Patch target is not in project index and not an allowed new file: {file_name}")
00559: 
00560:     script = draft.get("hotpatch_candidate_script", draft.get("script", ""))
00561:     if script and "analysis_blender_keyframes" in str(script) and "write" in str(script).lower():
00562:         issues.append("Candidate script appears to write keyframe analysis data; review required.")
00563: 
00564:     return {
00565:         "ok": not issues,
00566:         "issues": issues,
00567:         "indexed_file_count": len(indexed_files),
00568:         "allowed_new_prefixes": list(ALLOWED_NEW_PREFIXES),
00569:     }
00570: 
00571: 
00572: def build_fallback_implementation_draft(reason: str, model: str | None = None) -> dict[str, Any]:
00573:     indexed_files = get_indexed_project_files()
00574:     selected_files = [path for path in PREFERRED_IMPLEMENTATION_FILES if path in indexed_files]
00575:     allowed_new_file = "Scripting/v61b/hotpatch/generated_audio_reactive_hotpatch.py"
00576: 
00577:     target_files = [
00578:         {
00579:             "file": path,
00580:             "exists_in_project_index": True,
00581:             "reason": "Deterministic fallback target selected from existing indexed project files.",
00582:             "hot_update_possible": path.endswith(("materials.py", "fog_dynamics.py", "scene_tuning_panel.py", "hot_update_scene_v61b.py")),
00583:             "requires_full_reload": path.endswith(("config.py", "physics_setup.py", "render_setup.py")),
00584:         }
00585:         for path in selected_files
00586:     ]
00587: 
00588:     patch_plan = [
00589:         {
00590:             "file": path,
00591:             "function_or_section": "To be reviewed manually",
00592:             "change": "Review and apply audio-reactive scene tuning changes according to the generated dual AI scene plan.",
00593:             "why": "The AI implementation response was missing or invalid, so a conservative patch plan was generated.",
00594:             "risk": "medium",
00595:             "test_or_check": "Run Blender in preview mode and verify materials, fog, lights, physics and panel behaviour without modifying the full analysis JSON.",
00596:         }
00597:         for path in selected_files
00598:     ]
00599: 
00600:     if not target_files:
00601:         target_files = [
00602:             {
00603:                 "file": allowed_new_file,
00604:                 "exists_in_project_index": False,
00605:                 "reason": "No preferred indexed project file was found; using allowed hotpatch path.",
00606:                 "hot_update_possible": True,
00607:                 "requires_full_reload": False,
00608:             }
00609:         ]
00610:         patch_plan = [
00611:             {
00612:                 "file": allowed_new_file,
00613:                 "function_or_section": "new hotpatch module",
00614:                 "change": "Create a review-only Blender hotpatch candidate module.",
00615:                 "why": "Fallback path is allowed by validator and avoids modifying unknown project files.",
00616:                 "risk": "medium",
00617:                 "test_or_check": "Load only after manual review inside Blender.",
00618:             }
00619:         ]
00620: 
00621:     draft: dict[str, Any] = {
00622:         "implementation_kind": "existing_project_patch_plan",
00623:         "safety": {
00624:             "does_not_modify_full_analysis_json": True,
00625:             "requires_manual_review": True,
00626:             "needs_blender_run": True,
00627:         },
00628:         "target_files": target_files,
00629:         "patch_plan": patch_plan,
00630:         "new_files_allowed": [
00631:             "Scripting/v61b/hotpatch/...",
00632:             "indexAI/patch_library/...",
00633:         ],
00634:         "hotpatch_candidate_script": "",
00635:         "notes": [
00636:             f"Deterministic fallback generated because implementation draft was invalid: {reason}",
00637:             "Review target_files and patch_plan before applying anything in Blender.",
00638:         ],
00639:         "files_to_review_before_applying": [item["file"] for item in target_files],
00640:         "expected_panel_or_operator": "Scene tuning panel or manually reviewed hotpatch operator.",
00641:     }
00642: 
00643:     if model:
00644:         draft["model"] = model
00645: 
00646:     return draft
00647: 
00648: 
00649: def normalize_implementation_draft(draft: dict[str, Any], model: str | None = None) -> dict[str, Any]:
00650:     if not isinstance(draft, dict):
00651:         return build_fallback_implementation_draft("draft is not a dictionary", model=model)
00652: 
00653:     validation = validate_implementation_draft(draft)
00654:     if validation.get("ok"):
00655:         return draft
00656: 
00657:     reason = "; ".join(validation.get("issues", [])) or "unknown validation failure"
00658:     fallback = build_fallback_implementation_draft(reason, model=model)
00659:     fallback["raw_invalid_draft"] = draft
00660:     fallback["original_validation"] = validation
00661:     return fallback
00662: 
00663: 
00664: def generate_implementation_draft_with_retry(
00665:     manager: OllamaModelManager,
00666:     model_name: str,
00667:     implementation_prompt: str,
00668:     plan: dict[str, Any],
00669:     max_new_tokens: int,
00670: ) -> dict[str, Any]:
00671:     implementation_text, implementation_model = manager.generate(
00672:         model_name,
00673:         implementation_prompt,
00674:         max_new_tokens=max(max_new_tokens, 2400),
00675:         temperature=0.01,
00676:     )
00677: 
00678:     draft = safe_parse_json(implementation_text, "raw_implementation_response")
00679:     draft["model"] = implementation_model
00680: 
00681:     validation = validate_implementation_draft(draft)
00682:     if validation.get("ok"):
00683:         return draft
00684: 
00685:     retry_prompt = build_implementation_retry_prompt(
00686:         plan=plan,
00687:         invalid_draft=draft,
00688:         validation=validation,
00689:     )
00690: 
00691:     retry_text, retry_model = manager.generate(
00692:         model_name,
00693:         retry_prompt,
00694:         max_new_tokens=max(max_new_tokens, 4000),
00695:         temperature=0.01,
00696:     )
00697: 
00698:     retry_draft = safe_parse_json(retry_text, "raw_implementation_retry_response")
00699:     retry_draft["model"] = retry_model
00700:     retry_draft["retry_of_invalid_draft"] = draft
00701:     retry_draft["first_validation"] = validation
00702: 
```
