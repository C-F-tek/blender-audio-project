# NPU Long Context Chunk 23/94

- File: `Scripting/v61b/animation.py`
- Part: `5`
- Lines: `792-960`

## Symbol Map
- Imports: `math`, `from config import HERO_SCALE_MIN, HERO_SCALE_MAX, HERO_BOUNCE_Z, HERO_ROT_Z, HERO_ROT_X, HERO_ROT_Y, HERO_DRIFT_X, HERO_DRIFT_Y, HERO_ORBIT_X, HERO_ORBIT_Y, HERO_BEAT_TWIST_Z, HERO_ONSET_SHAKE, HERO_DEFORM_STRENGTH_MIN, HERO_DEFORM_STRENGTH_MAX, HERO_DEFORM_DETAIL_STRENGTH_MAX, HERO_DEFORM_WAVE_HEIGHT_MAX, HERO_DEFORM_TWIST_MAX, HERO_DEFORM_CONTROLLER_RADIUS, HERO_DEFORM_KEYFRAME_STEP, HERO_MATERIAL_EMISSION_MIN, HERO_MATERIAL_EMISSION_MAX, HERO_MATERIAL_SELF_LIGHT_MIN, HERO_MATERIAL_SELF_LIGHT_MAX, HERO_MATERIAL_BUMP_MIN, HERO_MATERIAL_BUMP_MAX, HERO_MATERIAL_ROUGHNESS_MIN, HERO_MATERIAL_ROUGHNESS_MAX, HERO_MATERIAL_NOISE_SCALE_MIN, HERO_MATERIAL_NOISE_SCALE_MAX, HERO_MATERIAL_MAPPING_DRIFT, AURA_DEFORM_KEYFRAME_STEP, AURA_DEFORM_FIELD_DRIFT, AURA_DEFORM_FIELD_SCALE, SECONDARY_SCALE_MIN, SECONDARY_SCALE_MAX, SECONDARY_BOUNCE_Z, SECONDARY_DRIFT_X, SECONDARY_DRIFT_Y, SECONDARY_ROT_Z, SECONDARY_ROT_X, CAMERA_BEAT_BUMP_Z, CAMERA_BEAT_BUMP_Y, CAMERA_ORBIT_AMOUNT, CAMERA_PUSH_AMOUNT, CAMERA_VERTICAL_SWAY, LIGHT_ENERGY_MIN, LIGHT_ENERGY_MAX, PHYSICS_ACCENT_EMISSION_MIN, PHYSICS_ACCENT_EMISSION_MAX, PHYSICS_ACCENT_MIX_MIN, PHYSICS_ACCENT_MIX_MAX, PHYSICS_ATOM_ORBIT_SPEED_MIN, PHYSICS_ATOM_ORBIT_AUDIO_SPEED, PHYSICS_ATOM_ORBIT_RADIUS_PULSE, PHYSICS_ATOM_ORBIT_HEIGHT_SWAY, PHYSICS_ATOM_MICRO_WOBBLE, COMPOSITOR_GLARE_THRESHOLD_MIN, COMPOSITOR_GLARE_THRESHOLD_MAX, COMPOSITOR_LENS_DISTORT_MIN, COMPOSITOR_LENS_DISTORT_MAX, COMPOSITOR_LENS_DISPERSION_MIN, COMPOSITOR_LENS_DISPERSION_MAX, FIELD_STRENGTH_MIN, FIELD_STRENGTH_MAX, HERO_GRAVITY_STRENGTH_MIN, HERO_GRAVITY_STRENGTH_MAX, TURB_STRENGTH_MIN, TURB_STRENGTH_MAX, VORTEX_STRENGTH_MIN, VORTEX_STRENGTH_MAX, RHYTHM_PARTICLE_SIZE_MIN, RHYTHM_PARTICLE_SIZE_MAX, RHYTHM_PARTICLE_NORMAL_MIN, RHYTHM_PARTICLE_NORMAL_MAX, RHYTHM_PARTICLE_TANGENT_MIN, RHYTHM_PARTICLE_TANGENT_MAX, RHYTHM_PARTICLE_BROWNIAN_MIN, RHYTHM_PARTICLE_BROWNIAN_MAX, RHYTHM_PARTICLE_EMIT_MIN, RHYTHM_PARTICLE_EMIT_MAX, RHYTHM_PARTICLE_KEYFRAME_STEP, ALBUM_LETTER_PARTICLE_SIZE_MIN, ALBUM_LETTER_PARTICLE_SIZE_MAX, ALBUM_LETTER_ROOT_SCALE_MIN, ALBUM_LETTER_ROOT_SCALE_MAX, BACKDROP_EMISSION_MIN, BACKDROP_EMISSION_MAX, BACKDROP_BREATHE_SCALE, MIST_FLOAT_AMPLITUDE, MIST_BEAT_BOOST`, `from fog_dynamics import animate_fog_frame`, `from scene_utils import set_linear_interpolation_idblock`
- Functions: `keyframe_if_possible(idblock, data_path, frame)` line 99; `get_scene_compositor_tree(scene)` line 106; `rhythm_band_drive(band, response, low, mid, high, onset, beat, pulse, local_pulse)` line 114; `animate_scene(scene, frames, camera, target, hero_asset, secondary_asset, aura_data, fog_controller, scene_base, lights, physics_data, mist_particles, variants, energy_rings, energy_ribbons)` line 132

## Content
```py
00792:                 emission_socket.default_value = PHYSICS_ACCENT_EMISSION_MIN + accent_drive * (
00793:                     PHYSICS_ACCENT_EMISSION_MAX - PHYSICS_ACCENT_EMISSION_MIN
00794:                 )
00795:                 keyframe_if_possible(emission_socket, "default_value", i)
00796: 
00797:             mix_socket = item.get("mix_socket")
00798:             if mix_socket is not None:
00799:                 mix_socket.default_value = PHYSICS_ACCENT_MIX_MIN + accent_drive * (
00800:                     PHYSICS_ACCENT_MIX_MAX - PHYSICS_ACCENT_MIX_MIN
00801:                 )
00802:                 keyframe_if_possible(mix_socket, "default_value", i)
00803: 
00804:         # FORCE FIELDS
00805:         if force_obj is not None:
00806:             gravity_drive = min(1.0, low * 0.44 + mid * 0.14 + pulse * 0.34 + beat * 0.16)
00807:             strength = HERO_GRAVITY_STRENGTH_MIN + gravity_drive * (
00808:                 HERO_GRAVITY_STRENGTH_MAX - HERO_GRAVITY_STRENGTH_MIN
00809:             )
00810:             force_obj.field.strength = -strength
00811:             force_obj.location.x = hero_root.location.x
00812:             force_obj.location.y = hero_root.location.y
00813:             force_obj.location.z = hero_root.location.z + 0.34 + math.sin(i * 0.010) * 0.05
00814:             force_obj.keyframe_insert(data_path='field.strength', frame=i)
00815:             force_obj.keyframe_insert(data_path='location', frame=i)
00816: 
00817:         if turb_obj is not None:
00818:             turb_strength = TURB_STRENGTH_MIN + high * (TURB_STRENGTH_MAX - TURB_STRENGTH_MIN) * 0.64 + pulse * 0.42
00819:             turb_obj.field.strength = turb_strength
00820:             turb_obj.location.x = hero_root.location.x
00821:             turb_obj.location.y = hero_root.location.y
00822:             turb_obj.location.z = hero_root.location.z + 0.74 + math.sin(i * 0.012) * 0.08
00823:             turb_obj.keyframe_insert(data_path='field.strength', frame=i)
00824:             turb_obj.keyframe_insert(data_path='location', frame=i)
00825: 
00826:         if vortex_obj is not None:
00827:             vortex_strength = VORTEX_STRENGTH_MIN + (mid * 0.62 + pulse * 0.18) * (
00828:                 VORTEX_STRENGTH_MAX - VORTEX_STRENGTH_MIN
00829:             )
00830:             vortex_obj.field.strength = vortex_strength
00831:             vortex_obj.location.x = hero_root.location.x
00832:             vortex_obj.location.y = hero_root.location.y
00833:             vortex_obj.location.z = hero_root.location.z + 0.18
00834:             vortex_obj.rotation_euler.z = i * (0.004 + mid * 0.003 + beat * 0.002)
00835:             vortex_obj.keyframe_insert(data_path='field.strength', frame=i)
00836:             vortex_obj.keyframe_insert(data_path='location', frame=i)
00837:             vortex_obj.keyframe_insert(data_path='rotation_euler', frame=i)
00838: 
00839:         if wind_left is not None:
00840:             wl = onset * 6.0 + beat * 2.0
00841:             wind_left.field.strength = wl
00842:             wind_left.keyframe_insert(data_path='field.strength', frame=i)
00843: 
00844:         if wind_right is not None:
00845:             wr = high * 4.0 + beat * 1.8
00846:             wind_right.field.strength = wr
00847:             wind_right.keyframe_insert(data_path='field.strength', frame=i)
00848: 
00849:         # RHYTHM PARTICLE PHYSICS
00850:         particle_keyframe = (
00851:             i == 1
00852:             or i == total_frames
00853:             or i % RHYTHM_PARTICLE_KEYFRAME_STEP == 0
00854:             or beat > 0.0
00855:             or onset > 0.72
00856:         )
00857: 
00858:         if particle_keyframe:
00859:             for item in rhythm_particles:
00860:                 emitter = item["emitter"]
00861:                 settings = item["settings"]
00862:                 settings_list = item.get("settings_list", [settings])
00863:                 mode = item["mode"]
00864:                 phase = item["phase"]
00865:                 base_loc = item["base_location"]
00866:                 base_rot = item["base_rotation"]
00867:                 base_scale = item["base_scale"]
00868: 
00869:                 if mode == "pulse":
00870:                     drive = min(1.0, beat * 0.90 + onset * 0.62 + low * 0.28)
00871:                     settings.normal_factor = RHYTHM_PARTICLE_NORMAL_MIN + drive * (
00872:                         RHYTHM_PARTICLE_NORMAL_MAX - RHYTHM_PARTICLE_NORMAL_MIN
00873:                     )
00874:                     settings.tangent_factor = RHYTHM_PARTICLE_TANGENT_MIN + (mid * 0.55 + drive * 0.45) * (
00875:                         RHYTHM_PARTICLE_TANGENT_MAX - RHYTHM_PARTICLE_TANGENT_MIN
00876:                     )
00877:                     settings.brownian_factor = RHYTHM_PARTICLE_BROWNIAN_MIN + (high * 0.45 + drive * 0.55) * (
00878:                         RHYTHM_PARTICLE_BROWNIAN_MAX - RHYTHM_PARTICLE_BROWNIAN_MIN
00879:                     )
00880:                     settings.particle_size = RHYTHM_PARTICLE_SIZE_MIN + drive * (
00881:                         RHYTHM_PARTICLE_SIZE_MAX - RHYTHM_PARTICLE_SIZE_MIN
00882:                     )
00883:                     item["emission_socket"].default_value = RHYTHM_PARTICLE_EMIT_MIN + drive * (
00884:                         RHYTHM_PARTICLE_EMIT_MAX - RHYTHM_PARTICLE_EMIT_MIN
00885:                     )
00886: 
00887:                     emitter.location.z = base_loc.z + low * 0.10 + transient * 0.06
00888:                     scale_boost = 1.0 + drive * 0.12
00889:                     emitter.rotation_euler.z = base_rot.z + i * 0.010 + math.sin(i * 0.019 + phase) * 0.08
00890: 
00891:                 elif mode == "dust":
00892:                     drive = min(1.0, mid * 0.46 + low * 0.26 + pulse * 0.18)
00893:                     settings.normal_factor = 0.025 + drive * 0.35
00894:                     settings.tangent_factor = 0.08 + drive * 0.42
00895:                     settings.brownian_factor = 0.28 + (high * 0.55 + drive * 0.45) * 0.78
00896:                     settings.particle_size = RHYTHM_PARTICLE_SIZE_MIN * (0.58 + drive * 0.55)
00897:                     item["emission_socket"].default_value = 0.10 + (high * 0.36 + drive * 0.38) * 0.90
00898: 
00899:                     emitter.location.x = base_loc.x + math.sin(i * 0.008 + phase) * 0.18
00900:                     emitter.location.y = base_loc.y + math.cos(i * 0.007 + phase) * 0.16
00901:                     emitter.location.z = base_loc.z + math.sin(i * 0.010 + phase) * 0.08 + low * 0.05
00902:                     scale_boost = 1.0 + drive * 0.04
00903:                     emitter.rotation_euler.z = base_rot.z + i * 0.003 + phase
00904: 
00905:                 elif mode == "streak":
00906:                     drive = min(1.0, high * 0.85 + onset * 0.45 + beat * 0.20)
00907:                     settings.normal_factor = 0.18 + drive * 1.72
00908:                     settings.tangent_factor = 0.35 + drive * 1.10
00909:                     settings.brownian_factor = 0.04 + drive * 0.38
00910:                     settings.particle_size = RHYTHM_PARTICLE_SIZE_MIN * (0.70 + drive * 0.95)
00911:                     item["emission_socket"].default_value = 0.12 + drive * 1.70
00912: 
00913:                     emitter.location.z = base_loc.z + high * 0.22 + transient * 0.05
00914:                     scale_boost = 1.0 + drive * 0.08
00915:                     emitter.rotation_euler.z = base_rot.z - i * 0.014 + phase
00916: 
00917:                 else:
00918:                     drive = min(1.0, mid * 0.42 + onset * 0.44 + beat * 0.36 + high * 0.20)
00919:                     settings.normal_factor = 0.08 + drive * 0.92
00920:                     settings.tangent_factor = 0.24 + drive * 0.88
00921:                     settings.brownian_factor = 0.06 + drive * 0.54
00922:                     settings.particle_size = ALBUM_LETTER_PARTICLE_SIZE_MIN + drive * (
00923:                         ALBUM_LETTER_PARTICLE_SIZE_MAX - ALBUM_LETTER_PARTICLE_SIZE_MIN
00924:                     )
00925: 
00926:                     emitter.location.x = base_loc.x + math.sin(i * 0.011 + phase) * 0.24
00927:                     emitter.location.y = base_loc.y + math.cos(i * 0.009 + phase) * 0.20
00928:                     emitter.location.z = base_loc.z + mid * 0.18 + beat * 0.10
00929:                     scale_boost = 1.0 + drive * 0.10
00930:                     emitter.rotation_euler.z = base_rot.z + i * 0.006 + phase
00931: 
00932:                     letter_root = item.get("letter_root")
00933:                     if letter_root is not None:
00934:                         letter_scale = ALBUM_LETTER_ROOT_SCALE_MIN + drive * (
00935:                             ALBUM_LETTER_ROOT_SCALE_MAX - ALBUM_LETTER_ROOT_SCALE_MIN
00936:                         )
00937:                         letter_root.scale = (letter_scale, letter_scale, letter_scale)
00938:                         letter_root.rotation_euler.z = math.sin(i * 0.018 + phase) * 0.12
00939:                         letter_root.keyframe_insert(data_path="scale", frame=i)
00940:                         letter_root.keyframe_insert(data_path="rotation_euler", frame=i)
00941: 
00942:                     for letter in item.get("letter_sources", []):
00943:                         obj = letter["object"]
00944:                         lphase = letter["phase"]
00945:                         lscale = 1.0 + drive * 0.20 + math.sin(i * 0.030 + lphase) * 0.035
00946:                         obj.scale = (
00947:                             letter["base_scale"].x * lscale,
00948:                             letter["base_scale"].y * (1.0 + high * 0.14),
00949:                             letter["base_scale"].z * (1.0 + beat * 0.18),
00950:                         )
00951:                         obj.keyframe_insert(data_path="scale", frame=i)
00952: 
00953:                 emitter.scale = (
00954:                     base_scale.x * scale_boost,
00955:                     base_scale.y * scale_boost,
00956:                     base_scale.z * scale_boost,
00957:                 )
00958: 
00959:                 for extra_settings in settings_list[1:]:
00960:                     extra_settings.normal_factor = settings.normal_factor
```
