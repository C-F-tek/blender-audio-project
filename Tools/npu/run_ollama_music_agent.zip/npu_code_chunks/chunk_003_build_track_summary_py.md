# NPU Long Context Chunk 3/94

- File: `build_track_summary.py`
- Part: `1`
- Lines: `1-100`

## Symbol Map
- Imports: `from pathlib import Path`, `argparse`, `json`, `sys`, `from statistics import mean`
- Functions: `avg_top(values, ratio)` line 15; `safe_mean(values)` line 22; `build_summary(analysis_json, out_json, update_music_context)` line 26; `main()` line 85
- Assignments: `ROOT`, `PROJECT_DIR`, `OUTPUT_DIR`, `ANALYSIS_JSON`, `OUT_JSON`

## Content
```py
00001: from pathlib import Path
00002: import argparse
00003: import json
00004: import sys
00005: from statistics import mean
00006: 
00007: ROOT = Path.home() / "blender"
00008: PROJECT_DIR = ROOT / "blender-audio-project"
00009: OUTPUT_DIR = PROJECT_DIR / "output"
00010: 
00011: ANALYSIS_JSON = OUTPUT_DIR / "Feel The Light-Luca Vera_Master_analysis.json"
00012: OUT_JSON = OUTPUT_DIR / "Feel The Light-Luca Vera_Master_track_summary.json"
00013: 
00014: 
00015: def avg_top(values, ratio=0.1):
00016:     if not values:
00017:         return 0.0
00018:     n = max(1, int(len(values) * ratio))
00019:     return mean(sorted(values, reverse=True)[:n])
00020: 
00021: 
00022: def safe_mean(values):
00023:     return mean(values) if values else 0.0
00024: 
00025: 
00026: def build_summary(analysis_json: Path, out_json: Path, update_music_context: bool = True) -> dict:
00027:     with open(analysis_json, "r", encoding="utf-8") as f:
00028:         data = json.load(f)
00029: 
00030:     meta = data["meta"]
00031:     frames = data["frames"]
00032: 
00033:     low_vals = [float(x.get("low", 0.0)) for x in frames]
00034:     mid_vals = [float(x.get("mid", 0.0)) for x in frames]
00035:     high_vals = [float(x.get("high", 0.0)) for x in frames]
00036:     onset_vals = [float(x.get("onset", 0.0)) for x in frames]
00037:     beat_vals = [float(x.get("beat", 0.0)) for x in frames]
00038: 
00039:     summary = {
00040:         "track_name": analysis_json.stem.replace("_analysis", ""),
00041:         "source_analysis_json": str(analysis_json),
00042:         "duration_sec": meta.get("duration_sec"),
00043:         "fps": meta.get("fps"),
00044:         "estimated_tempo_bpm": meta.get("estimated_tempo_bpm"),
00045:         "energy_profile": {
00046:             "low_avg": round(safe_mean(low_vals), 4),
00047:             "mid_avg": round(safe_mean(mid_vals), 4),
00048:             "high_avg": round(safe_mean(high_vals), 4),
00049:             "low_peak_avg": round(avg_top(low_vals), 4),
00050:             "mid_peak_avg": round(avg_top(mid_vals), 4),
00051:             "high_peak_avg": round(avg_top(high_vals), 4),
00052:             "onset_avg": round(safe_mean(onset_vals), 4),
00053:             "beat_avg": round(safe_mean(beat_vals), 4),
00054:         },
00055:     }
00056: 
00057:     out_json.parent.mkdir(parents=True, exist_ok=True)
00058:     with open(out_json, "w", encoding="utf-8") as f:
00059:         json.dump(summary, f, indent=2, ensure_ascii=False)
00060: 
00061:     print(f"[OK] Summary salvato in: {out_json}")
00062:     print(json.dumps(summary, indent=2, ensure_ascii=False))
00063: 
00064:     if update_music_context:
00065:         tools_dir = PROJECT_DIR / "Tools" / "npu"
00066:         if tools_dir.exists():
00067:             if str(tools_dir) not in sys.path:
00068:                 sys.path.insert(0, str(tools_dir))
00069:             try:
00070:                 from build_music_context import build_music_context
00071: 
00072:                 manifest = build_music_context(
00073:                     analysis_path=analysis_json,
00074:                     track_summary_path=out_json,
00075:                     compact_json_path=OUTPUT_DIR / f"{summary['track_name']}_music_context.json",
00076:                 )
00077:             except Exception as exc:
00078:                 print(f"[WARN] Contesto musicale NPU non aggiornato: {exc}")
00079:             else:
00080:                 print(f"[OK] Contesto musicale NPU aggiornato: {manifest['context_md']}")
00081: 
00082:     return summary
00083: 
00084: 
00085: def main() -> None:
00086:     parser = argparse.ArgumentParser(description="Crea un riassunto tecnico da un analysis JSON.")
00087:     parser.add_argument("--analysis-json", default=str(ANALYSIS_JSON))
00088:     parser.add_argument("--out-json", default=str(OUT_JSON))
00089:     parser.add_argument("--skip-music-context", action="store_true")
00090:     args = parser.parse_args()
00091: 
00092:     build_summary(
00093:         analysis_json=Path(args.analysis_json).expanduser().resolve(),
00094:         out_json=Path(args.out_json).expanduser().resolve(),
00095:         update_music_context=not args.skip_music_context,
00096:     )
00097: 
00098: 
00099: if __name__ == "__main__":
00100:     main()
```
