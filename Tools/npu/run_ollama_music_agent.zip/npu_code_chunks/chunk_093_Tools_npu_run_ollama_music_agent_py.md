# NPU Long Context Chunk 93/94

- File: `Tools/npu/run_ollama_music_agent.py`
- Part: `1`
- Lines: `1-234`

## Symbol Map
- Imports: `from __future__ import annotations`, `from pathlib import Path`, `argparse`, `json`, `from datetime import datetime`, `from ollama_runtime import OllamaSession, parse_json_response`
- Functions: `read_json(path)` line 22; `compact_context_for_prompt(context)` line 27; `build_prompt(context)` line 55; `markdown_from_insights(data, model)` line 107; `run_ollama_music_agent(context_json, fallback_context_json, out_json, out_md, model, base_url, keep_alive, max_new_tokens, temperature, keep_server, keep_model)` line 137; `main()` line 203
- Assignments: `ROOT`, `OUTPUT_DIR`, `TOOLS_DIR`, `DEFAULT_TRACK_STEM`, `DEFAULT_CONTEXT_JSON`, `DEFAULT_MUSIC_CONTEXT_JSON`, `DEFAULT_OUT_JSON`, `DEFAULT_OUT_MD`

## Content
```py
00001: from __future__ import annotations
00002: 
00003: from pathlib import Path
00004: import argparse
00005: import json
00006: from datetime import datetime
00007: 
00008: from ollama_runtime import OllamaSession, parse_json_response
00009: 
00010: 
00011: ROOT = Path(__file__).resolve().parents[2]
00012: OUTPUT_DIR = ROOT / "output"
00013: TOOLS_DIR = ROOT / "Tools" / "npu"
00014: 
00015: DEFAULT_TRACK_STEM = "Feel The Light-Luca Vera_Master"
00016: DEFAULT_CONTEXT_JSON = OUTPUT_DIR / f"{DEFAULT_TRACK_STEM}_analysis_ai_context.json"
00017: DEFAULT_MUSIC_CONTEXT_JSON = OUTPUT_DIR / f"{DEFAULT_TRACK_STEM}_music_context.json"
00018: DEFAULT_OUT_JSON = OUTPUT_DIR / f"{DEFAULT_TRACK_STEM}_ollama_music_insights.json"
00019: DEFAULT_OUT_MD = TOOLS_DIR / "ollama_music_insights.md"
00020: 
00021: 
00022: def read_json(path: Path) -> dict:
00023:     with open(path, "r", encoding="utf-8") as handle:
00024:         return json.load(handle)
00025: 
00026: 
00027: def compact_context_for_prompt(context: dict) -> dict:
00028:     analysis = context.get("analysis_summary", {})
00029:     compact = {
00030:         "analysis_summary": analysis,
00031:         "track_summary": context.get("track_summary"),
00032:         "scene_summaries": context.get("scene_summaries", []),
00033:         "segments": [],
00034:     }
00035: 
00036:     for segment in context.get("segments", []):
00037:         compact["segments"].append(
00038:             {
00039:                 "index": segment.get("index"),
00040:                 "start_sec": segment.get("start_sec"),
00041:                 "end_sec": segment.get("end_sec"),
00042:                 "dominant_band": segment.get("dominant_band"),
00043:                 "intensity_score": segment.get("intensity_score"),
00044:                 "intensity": segment.get("intensity"),
00045:                 "beat_count": segment.get("beat_count"),
00046:                 "stats": segment.get("stats"),
00047:                 "controls": segment.get("controls"),
00048:                 "top_events": segment.get("top_events", [])[:8],
00049:             }
00050:         )
00051: 
00052:     return compact
00053: 
00054: 
00055: def build_prompt(context: dict) -> str:
00056:     payload = json.dumps(compact_context_for_prompt(context), indent=2, ensure_ascii=False)
00057:     return f"""
00058: Sei un agente musicale locale per un video Blender audio-reactive.
00059: 
00060: Devi produrre un JSON operativo per aiutare gli script Blender e i prossimi hotpatch.
00061: Il JSON completo frame-by-frame per Blender NON deve essere ridotto, sostituito o riscritto.
00062: Usa questi segmenti solo per analisi, decisioni creative e suggerimenti.
00063: 
00064: Rispondi SOLO con JSON valido, senza markdown.
00065: 
00066: Schema richiesto:
00067: {{
00068:   "model_role": "music_scene_agent",
00069:   "global_read": {{
00070:     "mood": "...",
00071:     "tempo_interpretation": "...",
00072:     "energy_shape": "...",
00073:     "key_risks": ["..."]
00074:   }},
00075:   "segment_plan": [
00076:     {{
00077:       "segment": 1,
00078:       "time_range": "0.0-16.0",
00079:       "intent": "...",
00080:       "hero_mesh": "...",
00081:       "materials": "...",
00082:       "fog": "...",
00083:       "lights": "...",
00084:       "camera": "...",
00085:       "physics": "...",
00086:       "avoid": "..."
00087:     }}
00088:   ],
00089:   "scene_json_recommendations": {{
00090:     "keep": ["..."],
00091:     "change_candidates": ["..."],
00092:     "do_not_touch": ["..."]
00093:   }},
00094:   "blender_keyframe_policy": {{
00095:     "use_full_analysis_json": true,
00096:     "do_not_reduce_frames": true,
00097:     "notes": "..."
00098:   }},
00099:   "next_actions": ["..."]
00100: }}
00101: 
00102: CONTESTO:
00103: {payload}
00104: """.strip()
00105: 
00106: 
00107: def markdown_from_insights(data: dict, model: str) -> str:
00108:     lines = [
00109:         "# Ollama Music Insights\n\n",
00110:         f"Generated: `{datetime.now().isoformat(timespec='seconds')}`\n\n",
00111:         f"Model: `{model}`\n\n",
00112:         "## Global Read\n",
00113:     ]
00114:     global_read = data.get("global_read", {})
00115:     for key, value in global_read.items():
00116:         lines.append(f"- `{key}`: {value}\n")
00117: 
00118:     lines.append("\n## Segment Plan\n")
00119:     for item in data.get("segment_plan", []):
00120:         lines.append(
00121:             f"- Segment `{item.get('segment')}` `{item.get('time_range')}`: "
00122:             f"{item.get('intent')} | hero `{item.get('hero_mesh')}` | fog `{item.get('fog')}`\n"
00123:         )
00124: 
00125:     lines.append("\n## Keyframe Policy\n")
00126:     policy = data.get("blender_keyframe_policy", {})
00127:     for key, value in policy.items():
00128:         lines.append(f"- `{key}`: {value}\n")
00129: 
00130:     lines.append("\n## Next Actions\n")
00131:     for item in data.get("next_actions", []):
00132:         lines.append(f"- {item}\n")
00133: 
00134:     return "".join(lines)
00135: 
00136: 
00137: def run_ollama_music_agent(
00138:     context_json: Path | str = DEFAULT_CONTEXT_JSON,
00139:     fallback_context_json: Path | str = DEFAULT_MUSIC_CONTEXT_JSON,
00140:     out_json: Path | str = DEFAULT_OUT_JSON,
00141:     out_md: Path | str = DEFAULT_OUT_MD,
00142:     model: str = "qwen2.5-coder:14b",
00143:     base_url: str | None = None,
00144:     keep_alive: str = "5m",
00145:     max_new_tokens: int = 1800,
00146:     temperature: float = 0.12,
00147:     keep_server: bool = False,
00148:     keep_model: bool = False,
00149: ) -> dict:
00150:     context_path = Path(context_json)
00151:     if not context_path.exists():
00152:         context_path = Path(fallback_context_json)
00153:     if not context_path.exists():
00154:         raise FileNotFoundError(f"Context JSON not found: {context_path}")
00155: 
00156:     context = read_json(context_path)
00157:     prompt = build_prompt(context)
00158: 
00159:     session_kwargs = {
00160:         "model": model,
00161:         "keep_alive": keep_alive,
00162:         "shutdown_server": not keep_server,
00163:         "unload_model": not keep_model,
00164:     }
00165:     if base_url:
00166:         session_kwargs["base_url"] = base_url
00167: 
00168:     with OllamaSession(**session_kwargs) as session:
00169:         text = session.generate(prompt, max_new_tokens=max_new_tokens, temperature=temperature)
00170:         used_model = session.model or model
00171: 
00172:     try:
00173:         insights = parse_json_response(text)
00174:     except Exception:
00175:         insights = {
00176:             "model_role": "music_scene_agent",
00177:             "parse_error": True,
00178:             "raw_response": text,
00179:             "blender_keyframe_policy": {
00180:                 "use_full_analysis_json": True,
00181:                 "do_not_reduce_frames": True,
00182:                 "notes": "Raw model response could not be parsed; keep Blender frame JSON unchanged.",
00183:             },
00184:         }
00185: 
00186:     insights["generated_at"] = datetime.now().isoformat(timespec="seconds")
00187:     insights["model"] = used_model
00188:     insights["source_context"] = str(context_path)
00189: 
00190:     out_json = Path(out_json)
00191:     out_md = Path(out_md)
00192:     out_json.parent.mkdir(parents=True, exist_ok=True)
00193:     out_md.parent.mkdir(parents=True, exist_ok=True)
00194: 
00195:     out_json.write_text(json.dumps(insights, indent=2, ensure_ascii=False), encoding="utf-8")
00196:     out_md.write_text(markdown_from_insights(insights, used_model), encoding="utf-8")
00197: 
00198:     print(f"[OK] Wrote: {out_json}")
00199:     print(f"[OK] Wrote: {out_md}")
00200:     return {"out_json": out_json, "out_md": out_md, "model": used_model}
00201: 
00202: 
00203: def main() -> None:
00204:     parser = argparse.ArgumentParser(description="Run Ollama on compact WAV/scene context and write AI insights.")
00205:     parser.add_argument("--context-json", default=str(DEFAULT_CONTEXT_JSON))
00206:     parser.add_argument("--fallback-context-json", default=str(DEFAULT_MUSIC_CONTEXT_JSON))
00207:     parser.add_argument("--out-json", default=str(DEFAULT_OUT_JSON))
00208:     parser.add_argument("--out-md", default=str(DEFAULT_OUT_MD))
00209:     parser.add_argument("--model", default="qwen2.5-coder:14b")
00210:     parser.add_argument("--base-url", default=None)
00211:     parser.add_argument("--keep-alive", default="5m")
00212:     parser.add_argument("--max-new-tokens", type=int, default=1800)
00213:     parser.add_argument("--temperature", type=float, default=0.12)
00214:     parser.add_argument("--keep-server", action="store_true")
00215:     parser.add_argument("--keep-model", action="store_true")
00216:     args = parser.parse_args()
00217: 
00218:     run_ollama_music_agent(
00219:         context_json=args.context_json,
00220:         fallback_context_json=args.fallback_context_json,
00221:         out_json=args.out_json,
00222:         out_md=args.out_md,
00223:         model=args.model,
00224:         base_url=args.base_url,
00225:         keep_alive=args.keep_alive,
00226:         max_new_tokens=args.max_new_tokens,
00227:         temperature=args.temperature,
00228:         keep_server=args.keep_server,
00229:         keep_model=args.keep_model,
00230:     )
00231: 
00232: 
00233: if __name__ == "__main__":
00234:     main()
```
