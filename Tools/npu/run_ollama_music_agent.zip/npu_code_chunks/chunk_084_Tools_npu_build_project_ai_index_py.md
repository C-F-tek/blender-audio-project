# NPU Long Context Chunk 84/94

- File: `Tools/npu/build_project_ai_index.py`
- Part: `2`
- Lines: `267-415`

## Symbol Map
- Imports: `from __future__ import annotations`, `from datetime import datetime`, `from pathlib import Path`, `argparse`, `ast`, `hashlib`, `json`, `re`
- Functions: `sha256_text(text)` line 72; `sha256_file(path)` line 76; `rel_to_root(path)` line 84; `slugify(value, max_len)` line 88; `should_exclude(path)` line 93; `collect_project_files()` line 112; `target_name(target)` line 127; `extract_symbols(source)` line 135; `file_record(path)` line 178; `format_symbol_summary(record)` line 192; `numbered_lines(lines, start_line)` line 219; `split_source(source, max_chars)` line 223; `source_fingerprint(records)` line 245; `existing_cache_valid(fingerprint)` line 254; `write_readme()` line 268; `write_chunks(records, max_chunk_chars)` line 289; `write_index(records, chunks, created_at, fingerprint)` line 343; `build_project_ai_index(force, max_chunk_chars)` line 363; `main()` line 406
- Assignments: `ROOT`, `INDEX_DIR`, `PROJECT_INDEX_MD`, `PROJECT_MANIFEST_JSON`, `PROJECT_CHUNK_DIR`, `PATCH_LIBRARY_DIR`, `README_MD`, `DEFAULT_MAX_CHUNK_CHARS`, `TEXT_SUFFIXES`, `EXCLUDE_DIRS`, `EXCLUDE_PARTS`, `EXCLUDE_FILE_PREFIXES`, `MEDIA_SUFFIXES`

## Content
```py
00267: 
00268: def write_readme() -> None:
00269:     README_MD.write_text(
00270:         "\n".join(
00271:             [
00272:                 "# indexAI",
00273:                 "",
00274:                 "Generated AI indexes and patch-library notes for the Spaziotempo Blender project.",
00275:                 "",
00276:                 "- `project_code_index.md` is the primary project structure library.",
00277:                 "- `project_code_manifest.json` contains hashes, symbols and chunk metadata.",
00278:                 "- `project_code_chunks/` contains line-numbered source chunks.",
00279:                 "- `patch_library/` is reserved for AI patch plans and drafts.",
00280:                 "",
00281:                 "This folder is excluded from source indexing to avoid recursive AI context loops.",
00282:                 "",
00283:             ]
00284:         ),
00285:         encoding="utf-8",
00286:     )
00287: 
00288: 
00289: def write_chunks(records: list[dict], max_chunk_chars: int) -> list[dict]:
00290:     PROJECT_CHUNK_DIR.mkdir(parents=True, exist_ok=True)
00291:     for old_chunk in PROJECT_CHUNK_DIR.glob("chunk_*.md"):
00292:         old_chunk.unlink()
00293: 
00294:     chunks: list[dict] = []
00295:     pending: list[dict] = []
00296:     for record in records:
00297:         path = ROOT / record["file"]
00298:         source = path.read_text(encoding="utf-8", errors="replace")
00299:         for part, (start_line, end_line, lines) in enumerate(split_source(source, max_chunk_chars), 1):
00300:             pending.append(
00301:                 {
00302:                     "file": record["file"],
00303:                     "suffix": record["suffix"],
00304:                     "part": part,
00305:                     "start_line": start_line,
00306:                     "end_line": end_line,
00307:                     "symbols": format_symbol_summary(record),
00308:                     "text": numbered_lines(lines, start_line),
00309:                 }
00310:             )
00311: 
00312:     total = len(pending)
00313:     for index, item in enumerate(pending, 1):
00314:         chunk_name = f"chunk_{index:04d}_{slugify(item['file'])}.md"
00315:         chunk_path = PROJECT_CHUNK_DIR / chunk_name
00316:         fence = item["suffix"].lstrip(".") or "text"
00317:         body = [
00318:             f"# Project Code Chunk {index}/{total}\n\n",
00319:             f"- File: `{item['file']}`\n",
00320:             f"- Part: `{item['part']}`\n",
00321:             f"- Lines: `{item['start_line']}-{item['end_line']}`\n\n",
00322:         ]
00323:         if item["symbols"]:
00324:             body.extend(["## Symbol Map\n", item["symbols"], "\n\n"])
00325:         body.extend(["## Content\n", f"```{fence}\n", item["text"], "\n```\n"])
00326:         chunk_text = "".join(body)
00327:         chunk_path.write_text(chunk_text, encoding="utf-8")
00328:         chunks.append(
00329:             {
00330:                 "index": index,
00331:                 "file": item["file"],
00332:                 "path": rel_to_root(chunk_path),
00333:                 "part": item["part"],
00334:                 "start_line": item["start_line"],
00335:                 "end_line": item["end_line"],
00336:                 "chars": len(chunk_text),
00337:                 "sha256": sha256_text(chunk_text),
00338:             }
00339:         )
00340:     return chunks
00341: 
00342: 
00343: def write_index(records: list[dict], chunks: list[dict], created_at: str, fingerprint: str) -> None:
00344:     lines: list[str] = []
00345:     lines.append("# Spaziotempo Primary Project Code Index\n\n")
00346:     lines.append(f"Generated: `{created_at}`\n\n")
00347:     lines.append(f"Source fingerprint: `{fingerprint}`\n\n")
00348:     lines.append("Priority: this is the primary library for project structure. AI patches must respect these files before Blender manuals.\n\n")
00349:     lines.append("## Rules For AI Implementers\n")
00350:     lines.append("- Prefer existing files, functions and panel patterns.\n")
00351:     lines.append("- Do not generate monolithic replacement scripts when a targeted patch is possible.\n")
00352:     lines.append("- Full frame-by-frame keyframe JSON files are data inputs and must not be compacted or rewritten.\n")
00353:     lines.append("- `indexAI` is generated context and must not be re-indexed as source.\n\n")
00354:     lines.append("## Files\n")
00355:     for record in records:
00356:         lines.append(f"- `{record['file']}`: {record['lines']} lines, {record['chars']} chars, sha256 `{record['sha256']}`\n")
00357:     lines.append("\n## Chunks\n")
00358:     for chunk in chunks:
00359:         lines.append(f"- `{chunk['path']}` -> `{chunk['file']}` lines {chunk['start_line']}-{chunk['end_line']}\n")
00360:     PROJECT_INDEX_MD.write_text("".join(lines), encoding="utf-8")
00361: 
00362: 
00363: def build_project_ai_index(force: bool = False, max_chunk_chars: int = DEFAULT_MAX_CHUNK_CHARS) -> dict:
00364:     INDEX_DIR.mkdir(parents=True, exist_ok=True)
00365:     PATCH_LIBRARY_DIR.mkdir(parents=True, exist_ok=True)
00366:     write_readme()
00367: 
00368:     paths = collect_project_files()
00369:     records = [file_record(path) for path in paths]
00370:     fingerprint = source_fingerprint(records)
00371:     created_at = datetime.now().isoformat(timespec="seconds")
00372: 
00373:     if not force and existing_cache_valid(fingerprint):
00374:         manifest = json.loads(PROJECT_MANIFEST_JSON.read_text(encoding="utf-8"))
00375:         manifest["cache_hit"] = True
00376:         print(f"[OK] Reusing project AI index: {PROJECT_INDEX_MD}")
00377:         return manifest
00378: 
00379:     chunks = write_chunks(records, max_chunk_chars=max_chunk_chars)
00380:     write_index(records, chunks, created_at, fingerprint)
00381:     manifest = {
00382:         "created_at": created_at,
00383:         "root": str(ROOT),
00384:         "index_dir": str(INDEX_DIR),
00385:         "primary_library": True,
00386:         "source_fingerprint": fingerprint,
00387:         "excluded_dirs": sorted(EXCLUDE_DIRS),
00388:         "excluded_parts": sorted(EXCLUDE_PARTS),
00389:         "excluded_file_prefixes": sorted(EXCLUDE_FILE_PREFIXES),
00390:         "file_count": len(records),
00391:         "chunk_count": len(chunks),
00392:         "index_md": str(PROJECT_INDEX_MD),
00393:         "chunk_dir": str(PROJECT_CHUNK_DIR),
00394:         "patch_library_dir": str(PATCH_LIBRARY_DIR),
00395:         "files": records,
00396:         "chunks": chunks,
00397:         "cache_hit": False,
00398:     }
00399:     PROJECT_MANIFEST_JSON.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
00400:     print(f"[OK] Wrote: {PROJECT_INDEX_MD}")
00401:     print(f"[OK] Wrote: {PROJECT_MANIFEST_JSON}")
00402:     print(f"[OK] Wrote chunks: {PROJECT_CHUNK_DIR} ({len(chunks)} files)")
00403:     return manifest
00404: 
00405: 
00406: def main() -> None:
00407:     parser = argparse.ArgumentParser(description="Build primary project code index for AI patch planning.")
00408:     parser.add_argument("--force", action="store_true")
00409:     parser.add_argument("--max-chunk-chars", type=int, default=DEFAULT_MAX_CHUNK_CHARS)
00410:     args = parser.parse_args()
00411:     build_project_ai_index(force=args.force, max_chunk_chars=args.max_chunk_chars)
00412: 
00413: 
00414: if __name__ == "__main__":
00415:     main()
```
