# NPU Long Context Chunk 79/94

- File: `Tools/npu/build_music_context.py`
- Part: `3`
- Lines: `491-685`

## Symbol Map
- Imports: `from __future__ import annotations`, `from pathlib import Path`, `argparse`, `hashlib`, `json`, `math`, `statistics`, `from datetime import datetime`
- Functions: `sha256_text(text)` line 39; `rel_to_root(path)` line 43; `read_text(path)` line 50; `load_json(path)` line 54; `round_float(value, digits)` line 59; `quantile(values, ratio)` line 69; `avg_top(values, ratio)` line 83; `value_stats(values)` line 90; `frame_values(frames, key)` line 115; `energy_stats(frames)` line 119; `dominant_band(stats)` line 129; `intensity_label(score)` line 138; `segment_score(stats)` line 150; `control_suggestions(stats, beat_count)` line 160; `split_segments(frames, segment_seconds, duration)` line 174; `sampled_frames(frames, max_rows)` line 187; `top_events(frames, limit)` line 208; `beats_in_range(beats, start, end)` line 233; `build_segments(analysis, segment_seconds)` line 237; `summarize_analysis(analysis_path, segment_seconds)` line 271; `scene_summary_from_json(path, data)` line 317; `load_scene_records(scene_files)` line 351; `markdown_table_rows(rows, keys)` line 385; `write_chunk(path, title, body)` line 392; `write_music_chunks(context, scene_records)` line 402; `write_music_context_md(context, scene_records, chunks)` line 478; `build_analysis_ai_context(context)` line 525; `write_blender_keyframe_alias(analysis_path, blender_keyframes_path)` line 558; `build_music_context(analysis_path, track_summary_path, scene_files, segment_seconds, compact_json_path, analysis_ai_context_path, blender_keyframes_path, run_ollama, ollama_model)` line 565; `main()` line 657
- Assignments: `ROOT`, `OUTPUT_DIR`, `OUT_DIR`, `CHUNK_DIR`, `DEFAULT_TRACK_STEM`, `DEFAULT_ANALYSIS`, `DEFAULT_TRACK_SUMMARY`, `DEFAULT_COMPACT_JSON`, `DEFAULT_ANALYSIS_AI_CONTEXT`, `DEFAULT_BLENDER_KEYFRAMES_JSON`, `OUT_MD`, `OUT_JSON`, `DEFAULT_SCENE_FILES`, `DEFAULT_SEGMENT_SECONDS`, `SAMPLE_ROWS_PER_SEGMENT`, `TOP_EVENTS_PER_SEGMENT`

## Content
```py
00491:         f"- Frames: `{summary.get('frame_count')}`\n",
00492:         f"- Beats: `{summary.get('beat_count')}`\n",
00493:         f"- Segments: `{summary.get('segment_count')}` x `{summary.get('segment_seconds')}` sec\n\n",
00494:         "## Top Energy Segments\n",
00495:     ]
00496: 
00497:     for item in summary.get("top_energy_segments", []):
00498:         lines.append(
00499:             f"- Segment `{item['index']}` {item['start_sec']}-{item['end_sec']} sec: "
00500:             f"{item['intensity']} / {item['dominant_band']} / score `{item['intensity_score']}`\n"
00501:         )
00502: 
00503:     lines.append("\n## Scene Specs\n")
00504:     for record in scene_records:
00505:         record_summary = record["summary"]
00506:         lines.append(
00507:             f"- `{record['file']}`: {record_summary.get('type')} "
00508:             f"objects `{record_summary.get('objects_count', '')}` "
00509:             f"audio mappings `{record_summary.get('audio_mapping_count', '')}`\n"
00510:         )
00511: 
00512:     lines.append("\n## Chunks\n")
00513:     for chunk in chunks:
00514:         label = chunk.get("kind", "chunk")
00515:         detail = ""
00516:         if label == "audio_segment":
00517:             detail = f" segment {chunk.get('segment_index')} {chunk.get('start_sec')}-{chunk.get('end_sec')} sec"
00518:         elif label == "scene_spec":
00519:             detail = f" {chunk.get('source')}"
00520:         lines.append(f"- `{chunk['path']}`: {label}{detail}\n")
00521: 
00522:     OUT_MD.write_text("".join(lines), encoding="utf-8")
00523: 
00524: 
00525: def build_analysis_ai_context(context: dict) -> dict:
00526:     return {
00527:         "created_at": context.get("created_at"),
00528:         "purpose": "Compact AI context. Do not use this file for Blender frame-by-frame keyframes.",
00529:         "blender_keyframe_policy": {
00530:             "use_full_analysis_json": True,
00531:             "do_not_reduce_frames": True,
00532:             "notes": "The segment data is only for AI reasoning; Blender animation must read the full analysis JSON.",
00533:         },
00534:         "analysis_summary": context.get("analysis_summary"),
00535:         "track_summary": context.get("track_summary"),
00536:         "scene_summaries": context.get("scene_summaries", []),
00537:         "segments": [
00538:             {
00539:                 "index": segment.get("index"),
00540:                 "start_sec": segment.get("start_sec"),
00541:                 "end_sec": segment.get("end_sec"),
00542:                 "duration_sec": segment.get("duration_sec"),
00543:                 "frame_count": segment.get("frame_count"),
00544:                 "beat_count": segment.get("beat_count"),
00545:                 "dominant_band": segment.get("dominant_band"),
00546:                 "intensity_score": segment.get("intensity_score"),
00547:                 "intensity": segment.get("intensity"),
00548:                 "stats": segment.get("stats"),
00549:                 "controls": segment.get("controls"),
00550:                 "beat_times": segment.get("beat_times", [])[:40],
00551:                 "top_events": segment.get("top_events", []),
00552:             }
00553:             for segment in context.get("segments", [])
00554:         ],
00555:     }
00556: 
00557: 
00558: def write_blender_keyframe_alias(analysis_path: Path, blender_keyframes_path: Path) -> None:
00559:     blender_keyframes_path.parent.mkdir(parents=True, exist_ok=True)
00560:     if analysis_path.resolve() == blender_keyframes_path.resolve():
00561:         return
00562:     blender_keyframes_path.write_text(analysis_path.read_text(encoding="utf-8"), encoding="utf-8")
00563: 
00564: 
00565: def build_music_context(
00566:     analysis_path: Path | None = None,
00567:     track_summary_path: Path | None = None,
00568:     scene_files: list[Path] | None = None,
00569:     segment_seconds: float = DEFAULT_SEGMENT_SECONDS,
00570:     compact_json_path: Path | None = None,
00571:     analysis_ai_context_path: Path | None = None,
00572:     blender_keyframes_path: Path | None = None,
00573:     run_ollama: bool = False,
00574:     ollama_model: str = "qwen2.5-coder:14b",
00575: ) -> dict:
00576:     analysis_path = Path(analysis_path or DEFAULT_ANALYSIS).resolve()
00577:     track_summary_path = Path(track_summary_path or DEFAULT_TRACK_SUMMARY).resolve()
00578:     compact_json_path = Path(compact_json_path or DEFAULT_COMPACT_JSON).resolve()
00579:     analysis_ai_context_path = Path(analysis_ai_context_path or DEFAULT_ANALYSIS_AI_CONTEXT).resolve()
00580:     blender_keyframes_path = Path(blender_keyframes_path or DEFAULT_BLENDER_KEYFRAMES_JSON).resolve()
00581:     scene_files = scene_files or DEFAULT_SCENE_FILES
00582: 
00583:     if not analysis_path.exists():
00584:         raise FileNotFoundError(f"Analysis JSON not found: {analysis_path}")
00585: 
00586:     analysis_summary, segments = summarize_analysis(analysis_path, segment_seconds)
00587:     track_summary = load_json(track_summary_path) if track_summary_path.exists() else None
00588:     scene_records = load_scene_records([Path(item).resolve() for item in scene_files])
00589: 
00590:     context = {
00591:         "created_at": datetime.now().isoformat(timespec="seconds"),
00592:         "analysis_summary": analysis_summary,
00593:         "track_summary": track_summary,
00594:         "scene_summaries": [record["summary"] for record in scene_records],
00595:         "segments": segments,
00596:     }
00597: 
00598:     chunks = write_music_chunks(context, scene_records)
00599:     write_music_context_md(context, scene_records, chunks)
00600: 
00601:     manifest = {
00602:         "created_at": context["created_at"],
00603:         "root": str(ROOT),
00604:         "analysis_json": rel_to_root(analysis_path),
00605:         "blender_keyframes_json": rel_to_root(blender_keyframes_path),
00606:         "analysis_ai_context_json": rel_to_root(analysis_ai_context_path),
00607:         "track_summary_json": rel_to_root(track_summary_path) if track_summary_path.exists() else None,
00608:         "compact_json": rel_to_root(compact_json_path),
00609:         "context_md": rel_to_root(OUT_MD),
00610:         "chunk_dir": rel_to_root(CHUNK_DIR),
00611:         "chunk_count": len(chunks),
00612:         "segment_seconds": segment_seconds,
00613:         "segment_count": len(segments),
00614:         "scene_files": [
00615:             {
00616:                 "file": record["file"],
00617:                 "chars": record["chars"],
00618:                 "lines": record["lines"],
00619:                 "sha256": record["sha256"],
00620:                 "summary": record["summary"],
00621:             }
00622:             for record in scene_records
00623:         ],
00624:         "chunks": chunks,
00625:     }
00626: 
00627:     OUT_JSON.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
00628:     compact_json_path.parent.mkdir(parents=True, exist_ok=True)
00629:     compact_json_path.write_text(json.dumps(context, indent=2, ensure_ascii=False), encoding="utf-8")
00630:     analysis_ai_context_path.parent.mkdir(parents=True, exist_ok=True)
00631:     analysis_ai_context_path.write_text(
00632:         json.dumps(build_analysis_ai_context(context), indent=2, ensure_ascii=False),
00633:         encoding="utf-8",
00634:     )
00635:     write_blender_keyframe_alias(analysis_path, blender_keyframes_path)
00636: 
00637:     if run_ollama:
00638:         try:
00639:             from run_ollama_music_agent import run_ollama_music_agent
00640: 
00641:             ollama_result = run_ollama_music_agent(
00642:                 context_json=analysis_ai_context_path,
00643:                 model=ollama_model,
00644:             )
00645:         except Exception as exc:
00646:             manifest["ollama_error"] = str(exc)
00647:             OUT_JSON.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
00648:             print(f"[WARN] Ollama music agent non eseguito: {exc}")
00649:         else:
00650:             manifest["ollama_music_insights_json"] = rel_to_root(ollama_result["out_json"])
00651:             manifest["ollama_music_insights_md"] = rel_to_root(ollama_result["out_md"])
00652:             OUT_JSON.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
00653: 
00654:     return manifest
00655: 
00656: 
00657: def main() -> None:
00658:     parser = argparse.ArgumentParser(description="Build long-context music data files for the local NPU agent.")
00659:     parser.add_argument("--analysis", default=str(DEFAULT_ANALYSIS))
00660:     parser.add_argument("--track-summary", default=str(DEFAULT_TRACK_SUMMARY))
00661:     parser.add_argument("--compact-json", default=str(DEFAULT_COMPACT_JSON))
00662:     parser.add_argument("--analysis-ai-context", default=str(DEFAULT_ANALYSIS_AI_CONTEXT))
00663:     parser.add_argument("--blender-keyframes-json", default=str(DEFAULT_BLENDER_KEYFRAMES_JSON))
00664:     parser.add_argument("--segment-seconds", type=float, default=DEFAULT_SEGMENT_SECONDS)
00665:     parser.add_argument("--scene-file", action="append", default=[])
00666:     parser.add_argument("--run-ollama", action="store_true")
00667:     parser.add_argument("--ollama-model", default="qwen2.5-coder:14b")
00668:     args = parser.parse_args()
00669: 
00670:     scene_files = [Path(item) for item in args.scene_file] if args.scene_file else None
00671:     manifest = build_music_context(
00672:         analysis_path=Path(args.analysis),
00673:         track_summary_path=Path(args.track_summary),
00674:         scene_files=scene_files,
00675:         segment_seconds=args.segment_seconds,
00676:         compact_json_path=Path(args.compact_json),
00677:         analysis_ai_context_path=Path(args.analysis_ai_context),
00678:         blender_keyframes_path=Path(args.blender_keyframes_json),
00679:         run_ollama=args.run_ollama,
00680:         ollama_model=args.ollama_model,
00681:     )
00682: 
00683:     print(f"[OK] Wrote: {OUT_MD}")
00684:     print(f"[OK] Wrote: {OUT_JSON}")
00685:     print(f"[OK] Wrote: {manifest['compact_json']}")
```
