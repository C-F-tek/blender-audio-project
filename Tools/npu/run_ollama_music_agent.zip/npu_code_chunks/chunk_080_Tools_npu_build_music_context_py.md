# NPU Long Context Chunk 80/94

- File: `Tools/npu/build_music_context.py`
- Part: `4`
- Lines: `686-692`

## Symbol Map
- Imports: `from __future__ import annotations`, `from pathlib import Path`, `argparse`, `hashlib`, `json`, `math`, `statistics`, `from datetime import datetime`
- Functions: `sha256_text(text)` line 39; `rel_to_root(path)` line 43; `read_text(path)` line 50; `load_json(path)` line 54; `round_float(value, digits)` line 59; `quantile(values, ratio)` line 69; `avg_top(values, ratio)` line 83; `value_stats(values)` line 90; `frame_values(frames, key)` line 115; `energy_stats(frames)` line 119; `dominant_band(stats)` line 129; `intensity_label(score)` line 138; `segment_score(stats)` line 150; `control_suggestions(stats, beat_count)` line 160; `split_segments(frames, segment_seconds, duration)` line 174; `sampled_frames(frames, max_rows)` line 187; `top_events(frames, limit)` line 208; `beats_in_range(beats, start, end)` line 233; `build_segments(analysis, segment_seconds)` line 237; `summarize_analysis(analysis_path, segment_seconds)` line 271; `scene_summary_from_json(path, data)` line 317; `load_scene_records(scene_files)` line 351; `markdown_table_rows(rows, keys)` line 385; `write_chunk(path, title, body)` line 392; `write_music_chunks(context, scene_records)` line 402; `write_music_context_md(context, scene_records, chunks)` line 478; `build_analysis_ai_context(context)` line 525; `write_blender_keyframe_alias(analysis_path, blender_keyframes_path)` line 558; `build_music_context(analysis_path, track_summary_path, scene_files, segment_seconds, compact_json_path, analysis_ai_context_path, blender_keyframes_path, run_ollama, ollama_model)` line 565; `main()` line 657
- Assignments: `ROOT`, `OUTPUT_DIR`, `OUT_DIR`, `CHUNK_DIR`, `DEFAULT_TRACK_STEM`, `DEFAULT_ANALYSIS`, `DEFAULT_TRACK_SUMMARY`, `DEFAULT_COMPACT_JSON`, `DEFAULT_ANALYSIS_AI_CONTEXT`, `DEFAULT_BLENDER_KEYFRAMES_JSON`, `OUT_MD`, `OUT_JSON`, `DEFAULT_SCENE_FILES`, `DEFAULT_SEGMENT_SECONDS`, `SAMPLE_ROWS_PER_SEGMENT`, `TOP_EVENTS_PER_SEGMENT`

## Content
```py
00686:     print(f"[OK] Wrote: {manifest['analysis_ai_context_json']}")
00687:     print(f"[OK] Wrote: {manifest['blender_keyframes_json']}")
00688:     print(f"[OK] Wrote chunks: {CHUNK_DIR} ({manifest['chunk_count']} files)")
00689: 
00690: 
00691: if __name__ == "__main__":
00692:     main()
```
