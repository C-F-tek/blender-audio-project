# NPU Long Context Chunk 88/94

- File: `Tools/npu/run_dual_ai_pipeline - Copia.py`
- Part: `3`
- Lines: `462-646`

## Symbol Map
- Imports: `from __future__ import annotations`, `from pathlib import Path`, `argparse`, `json`, `subprocess`, `sys`, `from datetime import datetime`, `from build_music_context import build_music_context`, `from build_npu_code_context import main`, `from build_blender_manual_context import build_manual_context`, `from build_project_ai_index import PROJECT_INDEX_MD, PROJECT_MANIFEST_JSON, build_project_ai_index`, `from npu_runtime import DEFAULT_MODEL_DIR, DEFAULT_NPU_PYTHON, npu_preflight, write_npu_preflight_report`, `from ollama_runtime import OllamaModelManager, parse_json_response`, `from run_ollama_music_agent import build_prompt`, `from run_ollama_music_agent import markdown_from_insights`
- Functions: `read_text(path)` line 38; `read_json(path)` line 42; `write_json(path, data)` line 47; `validate_input_files(args)` line 52; `looks_degraded_text(text)` line 72; `deterministic_technical_notes(music_context, project_manifest, reason)` line 85; `run_npu_technical_pass(args)` line 134; `build_creative_scene_prompt(music_context, npu_notes, project_index)` line 178; `build_merge_prompt(music_context, npu_notes, creative, technical)` line 254; `build_implementation_prompt(plan, npu_notes, include_manual)` line 305; `safe_parse_json(text, fallback_key)` line 373; `write_brief(plan, creative, technical, npu_notes)` line 380; `validate_implementation_draft(draft)` line 403; `write_implementation_draft(draft)` line 450; `main()` line 478
- Assignments: `ROOT`, `TOOLS_DIR`, `OUTPUT_DIR`, `TRACK_STEM`, `MUSIC_AI_CONTEXT`, `DUAL_PLAN_JSON`, `DUAL_BRIEF_MD`, `OLLAMA_INSIGHTS_JSON`, `OLLAMA_INSIGHTS_MD`, `NPU_TECH_MD`, `NPU_PREFLIGHT_JSON`, `IMPLEMENTATION_DRAFT_JSON`, `IMPLEMENTATION_SCRIPT`, `IMPLEMENTATION_NOTES`, `NPU_IMPLEMENTATION_NOTES`

## Content
```py
00462:         "This file is an AI draft. Review before loading in Blender.\n\n",
00463:         "## Validation\n",
00464:         json.dumps(draft.get("validation", {}), indent=2, ensure_ascii=False),
00465:         "\n\n",
00466:         "## Safety\n",
00467:         json.dumps(draft.get("safety", {}), indent=2, ensure_ascii=False),
00468:         "\n\n## Notes\n",
00469:     ]
00470:     for note in draft.get("notes", []):
00471:         notes.append(f"- {note}\n")
00472:     notes.append("\n## Files To Review\n")
00473:     for path in draft.get("files_to_review_before_applying", []):
00474:         notes.append(f"- `{path}`\n")
00475:     IMPLEMENTATION_NOTES.write_text("".join(notes), encoding="utf-8")
00476: 
00477: 
00478: def main() -> None:
00479:     global TRACK_STEM
00480:     global MUSIC_AI_CONTEXT, DUAL_PLAN_JSON, OLLAMA_INSIGHTS_JSON
00481:     global IMPLEMENTATION_DRAFT_JSON
00482: 
00483:     parser = argparse.ArgumentParser(description="Build code/music contexts, run NPU technical pass and Ollama creative passes.")
00484:     parser.add_argument("--phase", choices=["plan", "implementation", "full"], default="plan")
00485:     parser.add_argument("--track-stem", default=TRACK_STEM)
00486:     parser.add_argument("--analysis", default=str(OUTPUT_DIR / f"{TRACK_STEM}_analysis.json"))
00487:     parser.add_argument("--track-summary", default=str(OUTPUT_DIR / f"{TRACK_STEM}_track_summary.json"))
00488:     parser.add_argument("--compact-json", default=str(OUTPUT_DIR / f"{TRACK_STEM}_music_context.json"))
00489:     parser.add_argument("--analysis-ai-context", default=str(MUSIC_AI_CONTEXT))
00490:     parser.add_argument("--blender-keyframes-json", default=str(OUTPUT_DIR / f"{TRACK_STEM}_analysis_blender_keyframes.json"))
00491:     parser.add_argument("--skip-npu", action="store_true")
00492:     parser.add_argument("--skip-ollama", action="store_true")
00493:     parser.add_argument("--include-manual", action="store_true")
00494:     parser.add_argument("--creative-model", default="gpt-oss:20b")
00495:     parser.add_argument("--technical-model", default="qwen2.5-coder:14b")
00496:     parser.add_argument("--ollama-base-url", default=None)
00497:     parser.add_argument("--npu-python", default=str(DEFAULT_NPU_PYTHON))
00498:     parser.add_argument("--npu-model-dir", default=str(DEFAULT_MODEL_DIR))
00499:     parser.add_argument("--npu-chunk-tokens", type=int, default=520)
00500:     parser.add_argument("--npu-reduce-tokens", type=int, default=650)
00501:     parser.add_argument("--npu-final-tokens", type=int, default=900)
00502:     parser.add_argument("--max-new-tokens", type=int, default=1800)
00503:     parser.add_argument("--force-npu", action="store_true", help="Re-run NPU notes even when reusable notes exist.")
00504:     args = parser.parse_args()
00505: 
00506:     TRACK_STEM = args.track_stem
00507:     MUSIC_AI_CONTEXT = Path(args.analysis_ai_context)
00508:     DUAL_PLAN_JSON = OUTPUT_DIR / f"{TRACK_STEM}_dual_ai_scene_plan.json"
00509:     OLLAMA_INSIGHTS_JSON = OUTPUT_DIR / f"{TRACK_STEM}_ollama_music_insights.json"
00510:     IMPLEMENTATION_DRAFT_JSON = OUTPUT_DIR / f"{TRACK_STEM}_ai_implementation_draft.json"
00511: 
00512:     if not Path(args.analysis).exists():
00513:         raise FileNotFoundError(f"Analysis JSON missing: {args.analysis}")
00514:     if not Path(args.track_summary).exists():
00515:         raise FileNotFoundError(
00516:             f"Track summary missing: {args.track_summary}\n"
00517:             "Crea prima il track summary o usa la workflow shell che ora lo ripara automaticamente."
00518:         )
00519:     if args.phase == "implementation" and not DUAL_PLAN_JSON.exists():
00520:         raise FileNotFoundError(f"Dual AI scene plan missing, run phase plan first: {DUAL_PLAN_JSON}")
00521: 
00522:     build_code_context()
00523:     project_manifest = build_project_ai_index()
00524:     build_music_context(
00525:         analysis_path=Path(args.analysis),
00526:         track_summary_path=Path(args.track_summary),
00527:         compact_json_path=Path(args.compact_json),
00528:         analysis_ai_context_path=Path(args.analysis_ai_context),
00529:         blender_keyframes_path=Path(args.blender_keyframes_json),
00530:     )
00531:     if args.include_manual:
00532:         build_manual_context(limit_files=80)
00533:     validate_input_files(args)
00534:     music_context = read_json(MUSIC_AI_CONTEXT)
00535: 
00536:     npu_notes = ""
00537:     if not args.skip_npu:
00538:         if args.phase == "implementation" and not args.force_npu and NPU_TECH_MD.exists():
00539:             npu_notes = read_text(NPU_TECH_MD)
00540:             print(f"[NPU] Reusing plan technical notes: {NPU_TECH_MD}")
00541:         else:
00542:             report = npu_preflight(args.npu_python, args.npu_model_dir)
00543:             write_npu_preflight_report(report, NPU_PREFLIGHT_JSON)
00544:             if report.get("ready"):
00545:                 try:
00546:                     npu_notes = run_npu_technical_pass(args)
00547:                 except Exception as exc:
00548:                     npu_notes = f"NPU technical pass unavailable after ready preflight: {exc}"
00549:                     NPU_TECH_MD.write_text(npu_notes, encoding="utf-8")
00550:             else:
00551:                 npu_notes = "NPU not ready. Preflight:\n" + json.dumps(report, indent=2, ensure_ascii=False)
00552:                 NPU_TECH_MD.write_text(npu_notes, encoding="utf-8")
00553: 
00554:         if looks_degraded_text(npu_notes):
00555:             npu_notes = deterministic_technical_notes(
00556:                 music_context=music_context,
00557:                 project_manifest=project_manifest,
00558:                 reason="degraded_or_too_short_npu_output",
00559:             )
00560:             NPU_TECH_MD.write_text(npu_notes, encoding="utf-8")
00561:             if args.phase == "implementation":
00562:                 NPU_IMPLEMENTATION_NOTES.write_text(npu_notes, encoding="utf-8")
00563:             print("[WARN] NPU notes looked degraded; deterministic technical notes were used.")
00564: 
00565:     if args.phase == "implementation":
00566:         if args.skip_ollama:
00567:             draft = {
00568:                 "implementation_kind": "existing_project_patch_plan",
00569:                 "safety": {
00570:                     "does_not_modify_full_analysis_json": True,
00571:                     "requires_manual_review": True,
00572:                     "needs_blender_run": True,
00573:                 },
00574:                 "target_files": [],
00575:                 "patch_plan": [],
00576:                 "hotpatch_candidate_script": "",
00577:                 "notes": ["Ollama skipped; implementation draft intentionally contains no generated patch."],
00578:                 "files_to_review_before_applying": [],
00579:                 "expected_panel_or_operator": "",
00580:             }
00581:             write_implementation_draft(draft)
00582:         else:
00583:             plan_output = read_json(DUAL_PLAN_JSON)
00584:             plan = plan_output.get("final_plan", plan_output)
00585:             manager_kwargs = {}
00586:             if args.ollama_base_url:
00587:                 manager_kwargs["base_url"] = args.ollama_base_url
00588:             try:
00589:                 with OllamaModelManager(**manager_kwargs) as manager:
00590:                     implementation_prompt = build_implementation_prompt(plan, npu_notes, args.include_manual)
00591:                     implementation_text, implementation_model = manager.generate(
00592:                         args.technical_model,
00593:                         implementation_prompt,
00594:                         max_new_tokens=max(args.max_new_tokens, 2400),
00595:                         temperature=0.05,
00596:                     )
00597:                     draft = safe_parse_json(implementation_text, "raw_implementation_response")
00598:                     draft["model"] = implementation_model
00599:                     write_implementation_draft(draft)
00600:             finally:
00601:                 pass
00602: 
00603:         print(f"[OK] Wrote: {IMPLEMENTATION_DRAFT_JSON}")
00604:         print(f"[OK] Wrote: {IMPLEMENTATION_SCRIPT}")
00605:         print(f"[OK] Wrote: {IMPLEMENTATION_NOTES}")
00606:         return
00607: 
00608:     if args.skip_ollama:
00609:         creative = {"skipped": True}
00610:         technical = {"skipped": True}
00611:         plan = {
00612:             "pipeline_policy": {
00613:                 "use_full_blender_keyframes_json": True,
00614:                 "ai_context_is_analysis_only": True,
00615:                 "ollama_model_switch_policy": "unload previous model before loading next",
00616:             },
00617:             "recommended_scene_plan": {
00618:                 "summary": "Ollama skipped; use NPU notes only.",
00619:                 "priority_changes": [],
00620:                 "defer_changes": [],
00621:             },
00622:         }
00623:     else:
00624:         manager_kwargs = {}
00625:         if args.ollama_base_url:
00626:             manager_kwargs["base_url"] = args.ollama_base_url
00627: 
00628:         with OllamaModelManager(**manager_kwargs) as manager:
00629:             creative_prompt = build_creative_scene_prompt(music_context, npu_notes, read_text(PROJECT_INDEX_MD))
00630:             creative_text, creative_model = manager.generate(
00631:                 args.creative_model,
00632:                 creative_prompt,
00633:                 max_new_tokens=args.max_new_tokens,
00634:                 temperature=0.20,
00635:             )
00636:             creative = safe_parse_json(creative_text, "raw_creative_response")
00637:             creative["model"] = creative_model
00638: 
00639:             technical_prompt = build_music_prompt(music_context)
00640:             technical_text, technical_model = manager.generate(
00641:                 args.technical_model,
00642:                 technical_prompt,
00643:                 max_new_tokens=args.max_new_tokens,
00644:                 temperature=0.10,
00645:             )
00646:             technical = safe_parse_json(technical_text, "raw_technical_response")
```
