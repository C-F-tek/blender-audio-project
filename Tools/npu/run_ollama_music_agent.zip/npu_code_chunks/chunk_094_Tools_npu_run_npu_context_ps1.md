# NPU Long Context Chunk 94/94

- File: `Tools/npu/run_npu_context.ps1`
- Part: `1`
- Lines: `1-232`

## Content
```ps1
00001: param(
00002:     [switch]$BuildOnly,
00003:     [switch]$SkipFinal,
00004:     [switch]$RunOllamaMusicAgent,
00005:     [switch]$RunDualAI,
00006:     [switch]$SkipDualNpu,
00007:     [switch]$SkipDualOllama,
00008:     [switch]$IncludeManual,
00009:     [ValidateSet("plan", "implementation", "full")]
00010:     [string]$DualPhase = "plan",
00011:     [ValidateSet("npu", "ollama")]
00012:     [string]$Engine = "npu",
00013:     [ValidateSet("code", "music")]
00014:     [string]$ReviewDomain = "code",
00015:     [string]$OllamaModel = "qwen2.5-coder:14b",
00016:     [string]$CreativeModel = "gpt-oss:20b",
00017:     [string]$TechnicalModel = "qwen2.5-coder:14b"
00018: )
00019: 
00020: $ErrorActionPreference = "Stop"
00021: 
00022: $ROOT = "$HOME\blender"
00023: $PROJECT = "$ROOT\blender-audio-project"
00024: $NPU_PY = "$ROOT\venvs\blender-npu-ai\Scripts\python.exe"
00025: $BLENDER_PY = "$env:ProgramFiles\Blender Foundation\Blender 5.1\5.1\python\bin\python.exe"
00026: 
00027: function Test-Python {
00028:     param(
00029:         [string]$Exe,
00030:         [string[]]$ArgsList
00031:     )
00032: 
00033:     try {
00034:         & $Exe @ArgsList *> $null
00035:         return $LASTEXITCODE -eq 0
00036:     } catch {
00037:         return $false
00038:     }
00039: }
00040: 
00041: function Invoke-Step {
00042:     param(
00043:         [string]$Title,
00044:         [string]$Exe,
00045:         [string[]]$ArgsList
00046:     )
00047: 
00048:     Write-Host ""
00049:     Write-Host "=== $Title ==="
00050: 
00051:     & $Exe @ArgsList
00052: 
00053:     if ($LASTEXITCODE -ne 0) {
00054:         throw "Step failed: $Title"
00055:     }
00056: }
00057: 
00058: if (-not (Test-Path $PROJECT)) {
00059:     throw "Project not found: $PROJECT"
00060: }
00061: 
00062: if (-not (Test-Path $NPU_PY)) {
00063:     throw "NPU Python not found: $NPU_PY"
00064: }
00065: 
00066: $BUILD_PY = $NPU_PY
00067: if (-not (Test-Python -Exe $NPU_PY -ArgsList @("-c", "print('ok')"))) {
00068:     if (Test-Path $BLENDER_PY) {
00069:         $BUILD_PY = $BLENDER_PY
00070:         Write-Host "NPU Python launcher is not starting; using Blender Python for context build only."
00071:     } else {
00072:         throw "NPU Python launcher is not starting and Blender Python fallback was not found."
00073:     }
00074: }
00075: 
00076: Set-Location $PROJECT
00077: 
00078: Invoke-Step `
00079:     -Title "Build long code context" `
00080:     -Exe $BUILD_PY `
00081:     -ArgsList @(".\Tools\npu\build_npu_code_context.py")
00082: 
00083: Invoke-Step `
00084:     -Title "Build long music context" `
00085:     -Exe $BUILD_PY `
00086:     -ArgsList @(".\Tools\npu\build_music_context.py")
00087: 
00088: Invoke-Step `
00089:     -Title "Ensure local manual library" `
00090:     -Exe $BUILD_PY `
00091:     -ArgsList @(".\Tools\npu\build_blender_manual_context.py", "--ensure-only")
00092: 
00093: if ($BuildOnly) {
00094:     Write-Host ""
00095:     Write-Host "=== Done: build only ==="
00096:     Write-Host "Generated:"
00097:     Write-Host "  Tools\npu\npu_code_context.md"
00098:     Write-Host "  Tools\npu\npu_code_index.md"
00099:     Write-Host "  Tools\npu\npu_code_manifest.json"
00100:     Write-Host "  Tools\npu\npu_code_chunks\chunk_*.md"
00101:     Write-Host "  Tools\npu\npu_music_context.md"
00102:     Write-Host "  Tools\npu\npu_music_manifest.json"
00103:     Write-Host "  Tools\npu\npu_music_chunks\chunk_*.md"
00104:     Write-Host "  output\Feel The Light-Luca Vera_Master_music_context.json"
00105:     Write-Host "  output\Feel The Light-Luca Vera_Master_analysis_ai_context.json"
00106:     Write-Host "  output\Feel The Light-Luca Vera_Master_analysis_blender_keyframes.json"
00107:     return
00108: }
00109: 
00110: if ($RunDualAI) {
00111:     $DualArgs = @(
00112:         ".\Tools\npu\run_dual_ai_pipeline.py",
00113:         "--phase", $DualPhase,
00114:         "--creative-model", $CreativeModel,
00115:         "--technical-model", $TechnicalModel,
00116:         "--npu-python", $NPU_PY
00117:     )
00118: 
00119:     if ($SkipDualNpu) {
00120:         $DualArgs += "--skip-npu"
00121:     }
00122: 
00123:     if ($SkipDualOllama) {
00124:         $DualArgs += "--skip-ollama"
00125:     }
00126: 
00127:     if ($IncludeManual) {
00128:         $DualArgs += "--include-manual"
00129:     }
00130: 
00131:     Invoke-Step `
00132:         -Title "Run dual AI pipeline" `
00133:         -Exe $BUILD_PY `
00134:         -ArgsList $DualArgs
00135: 
00136:     Write-Host ""
00137:     Write-Host "=== Done: dual AI ==="
00138:     Write-Host "Generated:"
00139:     Write-Host "  output\Feel The Light-Luca Vera_Master_dual_ai_scene_plan.json"
00140:     Write-Host "  Tools\npu\dual_ai_blender_agent_brief.md"
00141:     Write-Host "  Tools\npu\npu_dual_ai_technical_notes.md"
00142:     if (-not $SkipDualNpu) {
00143:         Write-Host "  Tools\npu\npu_preflight_report.json"
00144:     }
00145:     if ($DualPhase -ne "plan" -and -not $SkipDualOllama) {
00146:         Write-Host "  output\Feel The Light-Luca Vera_Master_ai_implementation_draft.json"
00147:         Write-Host "  Tools\npu\generated_blender_script_candidate.py"
00148:         Write-Host "  Tools\npu\generated_implementation_notes.md"
00149:     }
00150:     return
00151: }
00152: 
00153: if ($RunOllamaMusicAgent) {
00154:     Invoke-Step `
00155:         -Title "Run Ollama music agent" `
00156:         -Exe $BUILD_PY `
00157:         -ArgsList @(
00158:             ".\Tools\npu\run_ollama_music_agent.py",
00159:             "--model", $OllamaModel
00160:         )
00161: }
00162: 
00163: if ($Engine -eq "npu" -and -not (Test-Python -Exe $NPU_PY -ArgsList @("-c", "import openvino_genai; print('ok')"))) {
00164:     throw "NPU Python cannot start or cannot import openvino_genai. Rebuild the venv before running the NPU review, or use -BuildOnly."
00165: }
00166: 
00167: if ($ReviewDomain -eq "music") {
00168:     $ContextPath = ".\Tools\npu\npu_music_context.md"
00169:     $ChunkDir = ".\Tools\npu\npu_music_chunks"
00170:     $OutPath = ".\Tools\npu\npu_music_context_for_aider.md"
00171:     $NotesOut = ".\Tools\npu\npu_music_chunk_notes.md"
00172: } else {
00173:     $ContextPath = ".\Tools\npu\npu_code_context.md"
00174:     $ChunkDir = ".\Tools\npu\npu_code_chunks"
00175:     $OutPath = ".\Tools\npu\npu_context_for_aider.md"
00176:     $NotesOut = ".\Tools\npu\npu_chunk_notes.md"
00177: }
00178: 
00179: $ReviewArgs = @(
00180:     ".\Tools\npu\run_npu_review.py",
00181:     "--engine", $Engine,
00182:     "--device", "NPU",
00183:     "--ollama-model", $OllamaModel,
00184:     "--domain", $ReviewDomain,
00185:     "--mode", "chunked",
00186:     "--context", $ContextPath,
00187:     "--chunk-dir", $ChunkDir,
00188:     "--out", $OutPath,
00189:     "--notes-out", $NotesOut,
00190:     "--max-context-chars", "0",
00191:     "--chunk-chars", "10500",
00192:     "--chunk-overlap-chars", "700",
00193:     "--max-prompt-chars", "15000",
00194:     "--max-chunk-tokens", "650",
00195:     "--max-reduce-tokens", "750",
00196:     "--max-new-tokens", "1100",
00197:     "--max-prompt-len", "16384",
00198:     "--min-response-len", "512"
00199: )
00200: 
00201: if ($SkipFinal) {
00202:     $ReviewArgs += "--skip-final"
00203: }
00204: 
00205: $ReviewPython = $BUILD_PY
00206: if ($Engine -eq "npu") {
00207:     $ReviewPython = $NPU_PY
00208: }
00209: 
00210: Invoke-Step `
00211:     -Title "Run long-context review ($Engine / $ReviewDomain)" `
00212:     -Exe $ReviewPython `
00213:     -ArgsList $ReviewArgs
00214: 
00215: Write-Host ""
00216: Write-Host "=== Done ==="
00217: Write-Host "Generated:"
00218: Write-Host "  Tools\npu\npu_code_context.md"
00219: Write-Host "  Tools\npu\npu_code_index.md"
00220: Write-Host "  Tools\npu\npu_code_manifest.json"
00221: Write-Host "  Tools\npu\npu_code_chunks\chunk_*.md"
00222: Write-Host "  Tools\npu\npu_chunk_notes.md"
00223: Write-Host "  Tools\npu\npu_context_for_aider.md"
00224: Write-Host "  Tools\npu\npu_music_context.md"
00225: Write-Host "  Tools\npu\npu_music_manifest.json"
00226: Write-Host "  Tools\npu\npu_music_chunks\chunk_*.md"
00227: Write-Host "  Tools\npu\npu_music_chunk_notes.md"
00228: Write-Host "  Tools\npu\npu_music_context_for_aider.md"
00229: Write-Host "  output\Feel The Light-Luca Vera_Master_analysis_ai_context.json"
00230: Write-Host "  output\Feel The Light-Luca Vera_Master_analysis_blender_keyframes.json"
00231: Write-Host "  output\Feel The Light-Luca Vera_Master_ollama_music_insights.json"
00232: Write-Host "  Tools\npu\ollama_music_insights.md"
```
