# NPU Long Context Chunk 12/94

- File: `Tools/npu/run_dual_ai_pipeline.py`
- Part: `2`
- Lines: `217-475`

## Symbol Map
- Imports: `from __future__ import annotations`, `from pathlib import Path`, `argparse`, `json`, `subprocess`, `from datetime import datetime`, `from typing import Any`, `from build_music_context import build_music_context`, `from build_npu_code_context import main`, `from build_blender_manual_context import build_manual_context`, `from build_project_ai_index import PROJECT_INDEX_MD, PROJECT_MANIFEST_JSON, build_project_ai_index`, `from npu_runtime import DEFAULT_MODEL_DIR, DEFAULT_NPU_PYTHON, npu_preflight, write_npu_preflight_report`, `from ollama_runtime import OllamaModelManager, parse_json_response`, `from run_ollama_music_agent import build_prompt`, `from run_ollama_music_agent import markdown_from_insights`
- Functions: `read_text(path)` line 52; `read_json(path)` line 56; `write_json(path, data)` line 62; `update_track_paths(track_stem, analysis_ai_context)` line 67; `apply_default_input_paths(args)` line 79; `validate_input_files(args)` line 92; `looks_degraded_text(text)` line 112; `deterministic_technical_notes(music_context, project_manifest, reason)` line 128; `run_npu_technical_pass(args)` line 177; `build_creative_scene_prompt(music_context, npu_notes, project_index)` line 221; `build_merge_prompt(music_context, npu_notes, creative, technical)` line 297; `build_implementation_prompt(plan, npu_notes, include_manual)` line 353; `build_implementation_retry_prompt(plan, invalid_draft, validation)` line 425; `safe_parse_json(text, fallback_key)` line 504; `get_indexed_project_files()` line 512; `validate_implementation_draft(draft)` line 517; `build_fallback_implementation_draft(reason, model)` line 572; `normalize_implementation_draft(draft, model)` line 649; `generate_implementation_draft_with_retry(manager, model_name, implementation_prompt, plan, max_new_tokens)` line 664; `write_brief(plan, creative, technical, npu_notes)` line 706; `write_implementation_draft(draft)` line 729; `main()` line 759
- Assignments: `ROOT`, `TOOLS_DIR`, `OUTPUT_DIR`, `DEFAULT_TRACK_STEM`, `TRACK_STEM`, `MUSIC_AI_CONTEXT`, `DUAL_PLAN_JSON`, `DUAL_BRIEF_MD`, `OLLAMA_INSIGHTS_JSON`, `OLLAMA_INSIGHTS_MD`, `NPU_TECH_MD`, `NPU_PREFLIGHT_JSON`, `IMPLEMENTATION_DRAFT_JSON`, `IMPLEMENTATION_SCRIPT`, `IMPLEMENTATION_NOTES`, `NPU_IMPLEMENTATION_NOTES`, `ALLOWED_NEW_PREFIXES`, `PREFERRED_IMPLEMENTATION_FILES`

## Content
```py
00217:     subprocess.run(cmd, check=True)
00218:     return read_text(NPU_TECH_MD)
00219: 
00220: 
00221: def build_creative_scene_prompt(music_context: dict[str, Any], npu_notes: str, project_index: str) -> str:
00222:     compact = {
00223:         "analysis_summary": music_context.get("analysis_summary"),
00224:         "track_summary": music_context.get("track_summary"),
00225:         "scene_summaries": music_context.get("scene_summaries"),
00226:         "segments": [
00227:             {
00228:                 "index": segment.get("index"),
00229:                 "start_sec": segment.get("start_sec"),
00230:                 "end_sec": segment.get("end_sec"),
00231:                 "dominant_band": segment.get("dominant_band"),
00232:                 "intensity": segment.get("intensity"),
00233:                 "intensity_score": segment.get("intensity_score"),
00234:                 "controls": segment.get("controls"),
00235:                 "top_events": segment.get("top_events", [])[:6],
00236:             }
00237:             for segment in music_context.get("segments", [])
00238:         ],
00239:         "npu_technical_notes": npu_notes[:18000],
00240:         "primary_project_index": project_index[:14000],
00241:     }
00242:     payload = json.dumps(compact, indent=2, ensure_ascii=False)
00243:     return f"""
00244: Sei il generatore creativo locale per una scena Blender audio-reactive.
00245: 
00246: Hai un contesto musicale compatto, scene JSON esistenti e note tecniche NPU.
00247: Devi proporre una scena piu ricca SENZA cambiare direttamente codice Blender.
00248: Il codice reale del progetto e' la fonte primaria: rispetta file, moduli e funzioni esistenti.
00249: Il JSON full frame per Blender deve restare completo e invariato.
00250: 
00251: Rispondi SOLO con JSON valido.
00252: 
00253: Schema richiesto:
00254: {{
00255:   "creative_intent": "...",
00256:   "visual_language": {{
00257:     "background": "...",
00258:     "hero": "...",
00259:     "fog": "...",
00260:     "materials": "...",
00261:     "lights": "...",
00262:     "physics": "..."
00263:   }},
00264:   "scene_layers": [
00265:     {{
00266:       "layer": "Hero",
00267:       "objects": ["..."],
00268:       "audio_drivers": ["low", "mid", "high", "onset", "beat"],
00269:       "implementation_hint": "..."
00270:     }}
00271:   ],
00272:   "segment_variations": [
00273:     {{
00274:       "segment": 1,
00275:       "time_range": "0.0-16.0",
00276:       "variation": "...",
00277:       "material_modulation": "...",
00278:       "fog_modulation": "...",
00279:       "light_modulation": "...",
00280:       "camera_modulation": "..."
00281:     }}
00282:   ],
00283:   "render_safety": {{
00284:     "heavy_features_to_avoid": ["..."],
00285:     "fast_preview_strategy": "...",
00286:     "final_strategy": "..."
00287:   }},
00288:   "json_outputs_to_create": ["..."],
00289:   "do_not_touch": ["full analysis frame JSON", "..."]
00290: }}
00291: 
00292: CONTESTO:
00293: {payload}
00294: """.strip()
00295: 
00296: 
00297: def build_merge_prompt(
00298:     music_context: dict[str, Any],
00299:     npu_notes: str,
00300:     creative: dict[str, Any],
00301:     technical: dict[str, Any],
00302: ) -> str:
00303:     payload = {
00304:         "music_summary": music_context.get("analysis_summary"),
00305:         "npu_technical_notes": npu_notes[:14000],
00306:         "primary_project_index": read_text(PROJECT_INDEX_MD)[:12000],
00307:         "ollama_creative": creative,
00308:         "ollama_technical": technical,
00309:     }
00310:     return f"""
00311: Sei l'orchestratore finale NPU+Ollama per Blender.
00312: 
00313: Devi fondere note tecniche e proposte creative in un piano applicabile, ma NON applicare niente.
00314: Il piano deve essere prudente, modulare e compatibile con hotpatch successivi.
00315: 
00316: Rispondi SOLO con JSON valido.
00317: 
00318: Schema:
00319: {{
00320:   "pipeline_policy": {{
00321:     "use_full_blender_keyframes_json": true,
00322:     "ai_context_is_analysis_only": true,
00323:     "ollama_model_switch_policy": "unload previous model before loading next"
00324:   }},
00325:   "recommended_scene_plan": {{
00326:     "summary": "...",
00327:     "priority_changes": ["..."],
00328:     "defer_changes": ["..."]
00329:   }},
00330:   "file_plan": {{
00331:     "read_only": ["..."],
00332:     "hotpatch_candidates": ["..."],
00333:     "json_outputs": ["..."],
00334:     "must_use_existing_files": true
00335:   }},
00336:   "audio_mapping_plan": {{
00337:     "hero_mesh": "...",
00338:     "materials": "...",
00339:     "fog": "...",
00340:     "lights": "...",
00341:     "physics": "...",
00342:     "camera": "..."
00343:   }},
00344:   "safety_checks": ["..."],
00345:   "next_commands": ["..."]
00346: }}
00347: 
00348: DATI:
00349: {json.dumps(payload, indent=2, ensure_ascii=False)}
00350: """.strip()
00351: 
00352: 
00353: def build_implementation_prompt(plan: dict[str, Any], npu_notes: str, include_manual: bool) -> str:
00354:     manual_index = read_text(TOOLS_DIR / "npu_blender_manual_index.md")[:12000] if include_manual else ""
00355:     project_index = read_text(PROJECT_INDEX_MD)[:22000]
00356:     project_manifest = read_text(PROJECT_MANIFEST_JSON)[:18000]
00357:     legacy_code_index = read_text(TOOLS_DIR / "npu_code_index.md")[:8000]
00358:     guide = read_text(ROOT / "Scripting" / "v61b" / "SCENE_TUNING_GUIDE.md")[:10000]
00359:     project_structure = read_text(ROOT / "Scripting" / "v61b" / "PROJECT_STRUCTURE.md")[:8000]
00360: 
00361:     payload = {
00362:         "dual_ai_plan": plan,
00363:         "npu_notes": npu_notes[:14000],
00364:         "primary_project_index": project_index,
00365:         "primary_project_manifest": project_manifest,
00366:         "legacy_code_index": legacy_code_index,
00367:         "project_structure": project_structure,
00368:         "scene_tuning_guide": guide,
00369:         "manual_index": manual_index,
00370:     }
00371: 
00372:     return f"""
00373: Sei un agente implementatore Blender Python.
00374: 
00375: Devi generare una BOZZA di patch plan per il progetto esistente.
00376: Non devi riscrivere tutto in uno script monolitico.
00377: Ogni modifica deve riferirsi a un file gia presente nel primary_project_index, salvo nuovi file hotpatch o indexAI/patch_library.
00378: La bozza script candidata e' opzionale: usala solo se e' davvero un hotpatch separato e coerente.
00379: Non ridurre il JSON frame-by-frame del brano.
00380: Non inventare API se nel manuale/indice non sono presenti; se non sei sicuro, scrivi note.
00381: 
00382: Rispondi SOLO con JSON valido.
00383: Il primo carattere della risposta deve essere {{ e l'ultimo deve essere }}.
00384: Non usare Markdown, non usare blocchi ```json, non scrivere documentazione.
00385: 
00386: Schema obbligatorio:
00387: {{
00388:   "implementation_kind": "existing_project_patch_plan",
00389:   "safety": {{
00390:     "does_not_modify_full_analysis_json": true,
00391:     "requires_manual_review": true,
00392:     "needs_blender_run": true
00393:   }},
00394:   "target_files": [
00395:     {{
00396:       "file": "Scripting/v61b/materials.py",
00397:       "exists_in_project_index": true,
00398:       "reason": "...",
00399:       "hot_update_possible": true,
00400:       "requires_full_reload": false
00401:     }}
00402:   ],
00403:   "patch_plan": [
00404:     {{
00405:       "file": "Scripting/v61b/materials.py",
00406:       "function_or_section": "...",
00407:       "change": "...",
00408:       "why": "...",
00409:       "risk": "low|medium|high",
00410:       "test_or_check": "..."
00411:     }}
00412:   ],
00413:   "new_files_allowed": ["Scripting/v61b/hotpatch/...", "indexAI/patch_library/..."],
00414:   "hotpatch_candidate_script": "codice python opzionale, oppure stringa vuota",
00415:   "notes": ["..."],
00416:   "files_to_review_before_applying": ["..."],
00417:   "expected_panel_or_operator": "..."
00418: }}
00419: 
00420: CONTESTO:
00421: {json.dumps(payload, indent=2, ensure_ascii=False)}
00422: """.strip()
00423: 
00424: 
00425: def build_implementation_retry_prompt(
00426:     plan: dict[str, Any],
00427:     invalid_draft: dict[str, Any],
00428:     validation: dict[str, Any],
00429: ) -> str:
00430:     del invalid_draft  # The retry only needs the validation errors, not the full invalid text.
00431: 
00432:     manifest = read_json(PROJECT_MANIFEST_JSON) if PROJECT_MANIFEST_JSON.exists() else {}
00433:     indexed_files = sorted(
00434:         item.get("file")
00435:         for item in manifest.get("files", [])
00436:         if item.get("file")
00437:     )
00438:     preferred_files = [file_name for file_name in indexed_files if file_name in PREFERRED_IMPLEMENTATION_FILES]
00439: 
00440:     payload = {
00441:         "dual_ai_plan": plan,
00442:         "preferred_existing_files": preferred_files,
00443:         "allowed_new_prefixes": list(ALLOWED_NEW_PREFIXES),
00444:         "previous_validation_errors": validation.get("issues", []),
00445:         "previous_response_was_invalid": True,
00446:     }
00447: 
00448:     return f"""
00449: Rispondi esclusivamente con un singolo oggetto JSON valido.
00450: 
00451: REGOLE OBBLIGATORIE:
00452: - Il primo carattere della risposta deve essere {{.
00453: - L'ultimo carattere della risposta deve essere }}.
00454: - Non usare Markdown.
00455: - Non usare blocchi ```json.
00456: - Non scrivere documentazione.
00457: - Non spiegare il progetto.
00458: - Non includere testo prima o dopo il JSON.
00459: - Usa solo file presenti in preferred_existing_files, salvo nuovi file sotto i prefissi consentiti.
00460: - Non modificare il full analysis JSON frame-by-frame.
00461: 
00462: Schema obbligatorio:
00463: {{
00464:   "implementation_kind": "existing_project_patch_plan",
00465:   "safety": {{
00466:     "does_not_modify_full_analysis_json": true,
00467:     "requires_manual_review": true,
00468:     "needs_blender_run": true
00469:   }},
00470:   "target_files": [
00471:     {{
00472:       "file": "Scripting/v61b/materials.py",
00473:       "exists_in_project_index": true,
00474:       "reason": "...",
00475:       "hot_update_possible": true,
```
