# NPU Long Context Chunk 77/94

- File: `Tools/npu/build_music_context.py`
- Part: `1`
- Lines: `1-254`

## Symbol Map
- Imports: `from __future__ import annotations`, `from pathlib import Path`, `argparse`, `hashlib`, `json`, `math`, `statistics`, `from datetime import datetime`
- Functions: `sha256_text(text)` line 39; `rel_to_root(path)` line 43; `read_text(path)` line 50; `load_json(path)` line 54; `round_float(value, digits)` line 59; `quantile(values, ratio)` line 69; `avg_top(values, ratio)` line 83; `value_stats(values)` line 90; `frame_values(frames, key)` line 115; `energy_stats(frames)` line 119; `dominant_band(stats)` line 129; `intensity_label(score)` line 138; `segment_score(stats)` line 150; `control_suggestions(stats, beat_count)` line 160; `split_segments(frames, segment_seconds, duration)` line 174; `sampled_frames(frames, max_rows)` line 187; `top_events(frames, limit)` line 208; `beats_in_range(beats, start, end)` line 233; `build_segments(analysis, segment_seconds)` line 237; `summarize_analysis(analysis_path, segment_seconds)` line 271; `scene_summary_from_json(path, data)` line 317; `load_scene_records(scene_files)` line 351; `markdown_table_rows(rows, keys)` line 385; `write_chunk(path, title, body)` line 392; `write_music_chunks(context, scene_records)` line 402; `write_music_context_md(context, scene_records, chunks)` line 478; `build_analysis_ai_context(context)` line 525; `write_blender_keyframe_alias(analysis_path, blender_keyframes_path)` line 558; `build_music_context(analysis_path, track_summary_path, scene_files, segment_seconds, compact_json_path, analysis_ai_context_path, blender_keyframes_path, run_ollama, ollama_model)` line 565; `main()` line 657
- Assignments: `ROOT`, `OUTPUT_DIR`, `OUT_DIR`, `CHUNK_DIR`, `DEFAULT_TRACK_STEM`, `DEFAULT_ANALYSIS`, `DEFAULT_TRACK_SUMMARY`, `DEFAULT_COMPACT_JSON`, `DEFAULT_ANALYSIS_AI_CONTEXT`, `DEFAULT_BLENDER_KEYFRAMES_JSON`, `OUT_MD`, `OUT_JSON`, `DEFAULT_SCENE_FILES`, `DEFAULT_SEGMENT_SECONDS`, `SAMPLE_ROWS_PER_SEGMENT`, `TOP_EVENTS_PER_SEGMENT`

## Content
```py
00001: from __future__ import annotations
00002: 
00003: from pathlib import Path
00004: import argparse
00005: import hashlib
00006: import json
00007: import math
00008: import statistics
00009: from datetime import datetime
00010: 
00011: 
00012: ROOT = Path(__file__).resolve().parents[2]
00013: OUTPUT_DIR = ROOT / "output"
00014: OUT_DIR = ROOT / "Tools" / "npu"
00015: CHUNK_DIR = OUT_DIR / "npu_music_chunks"
00016: 
00017: DEFAULT_TRACK_STEM = "Feel The Light-Luca Vera_Master"
00018: DEFAULT_ANALYSIS = OUTPUT_DIR / f"{DEFAULT_TRACK_STEM}_analysis.json"
00019: DEFAULT_TRACK_SUMMARY = OUTPUT_DIR / f"{DEFAULT_TRACK_STEM}_track_summary.json"
00020: DEFAULT_COMPACT_JSON = OUTPUT_DIR / f"{DEFAULT_TRACK_STEM}_music_context.json"
00021: DEFAULT_ANALYSIS_AI_CONTEXT = OUTPUT_DIR / f"{DEFAULT_TRACK_STEM}_analysis_ai_context.json"
00022: DEFAULT_BLENDER_KEYFRAMES_JSON = OUTPUT_DIR / f"{DEFAULT_TRACK_STEM}_analysis_blender_keyframes.json"
00023: OUT_MD = OUT_DIR / "npu_music_context.md"
00024: OUT_JSON = OUT_DIR / "npu_music_manifest.json"
00025: 
00026: DEFAULT_SCENE_FILES = [
00027:     ROOT / "scene_spec_album_driven.json",
00028:     ROOT / "scene_spec_album_driven_normalized.json",
00029:     ROOT / "scene_spec_album_driven_raw.txt",
00030:     ROOT / "scene_spec_from_npu.json",
00031:     ROOT / "scene_spec_from_npu_raw.txt",
00032: ]
00033: 
00034: DEFAULT_SEGMENT_SECONDS = 16.0
00035: SAMPLE_ROWS_PER_SEGMENT = 64
00036: TOP_EVENTS_PER_SEGMENT = 12
00037: 
00038: 
00039: def sha256_text(text: str) -> str:
00040:     return hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest()
00041: 
00042: 
00043: def rel_to_root(path: Path) -> str:
00044:     try:
00045:         return str(path.relative_to(ROOT)).replace("\\", "/")
00046:     except ValueError:
00047:         return str(path)
00048: 
00049: 
00050: def read_text(path: Path) -> str:
00051:     return path.read_text(encoding="utf-8", errors="replace")
00052: 
00053: 
00054: def load_json(path: Path) -> dict:
00055:     with open(path, "r", encoding="utf-8") as handle:
00056:         return json.load(handle)
00057: 
00058: 
00059: def round_float(value: object, digits: int = 4) -> float:
00060:     try:
00061:         number = float(value)
00062:     except Exception:
00063:         number = 0.0
00064:     if math.isnan(number) or math.isinf(number):
00065:         number = 0.0
00066:     return round(number, digits)
00067: 
00068: 
00069: def quantile(values: list[float], ratio: float) -> float:
00070:     if not values:
00071:         return 0.0
00072:     ordered = sorted(values)
00073:     if len(ordered) == 1:
00074:         return ordered[0]
00075:     pos = max(0.0, min(1.0, ratio)) * (len(ordered) - 1)
00076:     lo = int(math.floor(pos))
00077:     hi = int(math.ceil(pos))
00078:     if lo == hi:
00079:         return ordered[lo]
00080:     return ordered[lo] + (ordered[hi] - ordered[lo]) * (pos - lo)
00081: 
00082: 
00083: def avg_top(values: list[float], ratio: float = 0.1) -> float:
00084:     if not values:
00085:         return 0.0
00086:     count = max(1, int(len(values) * ratio))
00087:     return statistics.mean(sorted(values, reverse=True)[:count])
00088: 
00089: 
00090: def value_stats(values: list[float]) -> dict:
00091:     if not values:
00092:         return {
00093:             "avg": 0.0,
00094:             "min": 0.0,
00095:             "max": 0.0,
00096:             "std": 0.0,
00097:             "p50": 0.0,
00098:             "p90": 0.0,
00099:             "p98": 0.0,
00100:             "top10_avg": 0.0,
00101:         }
00102: 
00103:     return {
00104:         "avg": round_float(statistics.mean(values)),
00105:         "min": round_float(min(values)),
00106:         "max": round_float(max(values)),
00107:         "std": round_float(statistics.pstdev(values) if len(values) > 1 else 0.0),
00108:         "p50": round_float(quantile(values, 0.50)),
00109:         "p90": round_float(quantile(values, 0.90)),
00110:         "p98": round_float(quantile(values, 0.98)),
00111:         "top10_avg": round_float(avg_top(values)),
00112:     }
00113: 
00114: 
00115: def frame_values(frames: list[dict], key: str) -> list[float]:
00116:     return [round_float(frame.get(key, 0.0), 8) for frame in frames]
00117: 
00118: 
00119: def energy_stats(frames: list[dict]) -> dict:
00120:     return {
00121:         "low": value_stats(frame_values(frames, "low")),
00122:         "mid": value_stats(frame_values(frames, "mid")),
00123:         "high": value_stats(frame_values(frames, "high")),
00124:         "onset": value_stats(frame_values(frames, "onset")),
00125:         "beat": value_stats(frame_values(frames, "beat")),
00126:     }
00127: 
00128: 
00129: def dominant_band(stats: dict) -> str:
00130:     candidates = {
00131:         "low": stats["low"]["avg"],
00132:         "mid": stats["mid"]["avg"],
00133:         "high": stats["high"]["avg"],
00134:     }
00135:     return max(candidates, key=candidates.get)
00136: 
00137: 
00138: def intensity_label(score: float) -> str:
00139:     if score >= 0.72:
00140:         return "peak"
00141:     if score >= 0.52:
00142:         return "high"
00143:     if score >= 0.34:
00144:         return "medium"
00145:     if score >= 0.18:
00146:         return "low"
00147:     return "quiet"
00148: 
00149: 
00150: def segment_score(stats: dict) -> float:
00151:     return round_float(
00152:         stats["low"]["avg"] * 0.30
00153:         + stats["mid"]["avg"] * 0.25
00154:         + stats["high"]["avg"] * 0.20
00155:         + stats["onset"]["p90"] * 0.20
00156:         + stats["beat"]["avg"] * 0.05
00157:     )
00158: 
00159: 
00160: def control_suggestions(stats: dict, beat_count: int) -> dict:
00161:     band = dominant_band(stats)
00162:     score = segment_score(stats)
00163:     return {
00164:         "primary_band": band,
00165:         "intensity": intensity_label(score),
00166:         "hero_deformation": round_float(stats["low"]["p90"] * 0.55 + stats["onset"]["p90"] * 0.20),
00167:         "material_shimmer": round_float(stats["mid"]["p90"] * 0.45 + stats["high"]["p90"] * 0.35),
00168:         "fog_motion": round_float(stats["low"]["avg"] * 0.35 + stats["mid"]["avg"] * 0.25),
00169:         "accent_emission": round_float(stats["high"]["p90"] * 0.65 + min(1.0, beat_count / 32.0) * 0.20),
00170:         "camera_pressure": round_float(stats["onset"]["p98"] * 0.28 + stats["beat"]["avg"] * 0.12),
00171:     }
00172: 
00173: 
00174: def split_segments(frames: list[dict], segment_seconds: float, duration: float) -> list[list[dict]]:
00175:     segment_count = max(1, int(math.ceil(duration / segment_seconds)))
00176:     buckets: list[list[dict]] = [[] for _ in range(segment_count)]
00177: 
00178:     for frame in frames:
00179:         time = round_float(frame.get("time", 0.0), 8)
00180:         index = int(time // segment_seconds)
00181:         index = max(0, min(segment_count - 1, index))
00182:         buckets[index].append(frame)
00183: 
00184:     return buckets
00185: 
00186: 
00187: def sampled_frames(frames: list[dict], max_rows: int = SAMPLE_ROWS_PER_SEGMENT) -> list[dict]:
00188:     if not frames:
00189:         return []
00190:     if len(frames) <= max_rows:
00191:         indices = list(range(len(frames)))
00192:     else:
00193:         indices = sorted({round(i * (len(frames) - 1) / (max_rows - 1)) for i in range(max_rows)})
00194: 
00195:     return [
00196:         {
00197:             "time": round_float(frames[index].get("time", 0.0), 3),
00198:             "low": round_float(frames[index].get("low", 0.0), 3),
00199:             "mid": round_float(frames[index].get("mid", 0.0), 3),
00200:             "high": round_float(frames[index].get("high", 0.0), 3),
00201:             "onset": round_float(frames[index].get("onset", 0.0), 3),
00202:             "beat": round_float(frames[index].get("beat", 0.0), 3),
00203:         }
00204:         for index in indices
00205:     ]
00206: 
00207: 
00208: def top_events(frames: list[dict], limit: int = TOP_EVENTS_PER_SEGMENT) -> list[dict]:
00209:     ranked = sorted(
00210:         frames,
00211:         key=lambda frame: (
00212:             round_float(frame.get("onset", 0.0)) * 1.00
00213:             + round_float(frame.get("beat", 0.0)) * 0.35
00214:             + round_float(frame.get("high", 0.0)) * 0.15
00215:         ),
00216:         reverse=True,
00217:     )
00218:     events = []
00219:     for frame in ranked[:limit]:
00220:         events.append(
00221:             {
00222:                 "time": round_float(frame.get("time", 0.0), 3),
00223:                 "low": round_float(frame.get("low", 0.0), 3),
00224:                 "mid": round_float(frame.get("mid", 0.0), 3),
00225:                 "high": round_float(frame.get("high", 0.0), 3),
00226:                 "onset": round_float(frame.get("onset", 0.0), 3),
00227:                 "beat": round_float(frame.get("beat", 0.0), 3),
00228:             }
00229:         )
00230:     return events
00231: 
00232: 
00233: def beats_in_range(beats: list[float], start: float, end: float) -> list[float]:
00234:     return [round_float(beat, 3) for beat in beats if start <= beat < end]
00235: 
00236: 
00237: def build_segments(analysis: dict, segment_seconds: float) -> list[dict]:
00238:     meta = analysis.get("meta", {})
00239:     frames = analysis.get("frames", [])
00240:     beats = [round_float(beat, 8) for beat in analysis.get("beats", [])]
00241:     duration = round_float(meta.get("duration_sec") or (frames[-1].get("time", 0.0) if frames else 0.0), 8)
00242: 
00243:     segments = []
00244:     for index, segment_frames in enumerate(split_segments(frames, segment_seconds, duration), 1):
00245:         start = (index - 1) * segment_seconds
00246:         end = min(index * segment_seconds, duration)
00247:         stats = energy_stats(segment_frames)
00248:         beat_times = beats_in_range(beats, start, end)
00249:         score = segment_score(stats)
00250:         segments.append(
00251:             {
00252:                 "index": index,
00253:                 "start_sec": round_float(start, 3),
00254:                 "end_sec": round_float(end, 3),
```
