# NPU Long Context Chunk 89/94

- File: `Tools/npu/run_dual_ai_pipeline - Copia.py`
- Part: `4`
- Lines: `647-705`

## Symbol Map
- Imports: `from __future__ import annotations`, `from pathlib import Path`, `argparse`, `json`, `subprocess`, `sys`, `from datetime import datetime`, `from build_music_context import build_music_context`, `from build_npu_code_context import main`, `from build_blender_manual_context import build_manual_context`, `from build_project_ai_index import PROJECT_INDEX_MD, PROJECT_MANIFEST_JSON, build_project_ai_index`, `from npu_runtime import DEFAULT_MODEL_DIR, DEFAULT_NPU_PYTHON, npu_preflight, write_npu_preflight_report`, `from ollama_runtime import OllamaModelManager, parse_json_response`, `from run_ollama_music_agent import build_prompt`, `from run_ollama_music_agent import markdown_from_insights`
- Functions: `read_text(path)` line 38; `read_json(path)` line 42; `write_json(path, data)` line 47; `validate_input_files(args)` line 52; `looks_degraded_text(text)` line 72; `deterministic_technical_notes(music_context, project_manifest, reason)` line 85; `run_npu_technical_pass(args)` line 134; `build_creative_scene_prompt(music_context, npu_notes, project_index)` line 178; `build_merge_prompt(music_context, npu_notes, creative, technical)` line 254; `build_implementation_prompt(plan, npu_notes, include_manual)` line 305; `safe_parse_json(text, fallback_key)` line 373; `write_brief(plan, creative, technical, npu_notes)` line 380; `validate_implementation_draft(draft)` line 403; `write_implementation_draft(draft)` line 450; `main()` line 478
- Assignments: `ROOT`, `TOOLS_DIR`, `OUTPUT_DIR`, `TRACK_STEM`, `MUSIC_AI_CONTEXT`, `DUAL_PLAN_JSON`, `DUAL_BRIEF_MD`, `OLLAMA_INSIGHTS_JSON`, `OLLAMA_INSIGHTS_MD`, `NPU_TECH_MD`, `NPU_PREFLIGHT_JSON`, `IMPLEMENTATION_DRAFT_JSON`, `IMPLEMENTATION_SCRIPT`, `IMPLEMENTATION_NOTES`, `NPU_IMPLEMENTATION_NOTES`

## Content
```py
00647:             technical["model"] = technical_model
00648: 
00649:             merge_prompt = build_merge_prompt(music_context, npu_notes, creative, technical)
00650:             merge_text, merge_model = manager.generate(
00651:                 args.technical_model,
00652:                 merge_prompt,
00653:                 max_new_tokens=args.max_new_tokens,
00654:                 temperature=0.08,
00655:             )
00656:             plan = safe_parse_json(merge_text, "raw_plan_response")
00657:             plan["merge_model"] = merge_model
00658: 
00659:             if args.phase in {"implementation", "full"}:
00660:                 implementation_prompt = build_implementation_prompt(plan, npu_notes, args.include_manual)
00661:                 implementation_text, implementation_model = manager.generate(
00662:                     args.technical_model,
00663:                     implementation_prompt,
00664:                     max_new_tokens=max(args.max_new_tokens, 2400),
00665:                     temperature=0.06,
00666:                 )
00667:                 draft = safe_parse_json(implementation_text, "raw_implementation_response")
00668:                 draft["model"] = implementation_model
00669:                 write_implementation_draft(draft)
00670: 
00671:     output = {
00672:         "generated_at": datetime.now().isoformat(timespec="seconds"),
00673:         "track_stem": TRACK_STEM,
00674:         "policy": {
00675:             "full_blender_keyframes_json": str(Path(args.blender_keyframes_json)),
00676:             "ai_context_json": str(MUSIC_AI_CONTEXT),
00677:             "model_switch_rule": "Unload/stop previous Ollama model before loading the next model.",
00678:             "phase": args.phase,
00679:             "manual_context_used": args.include_manual,
00680:             "implementation_draft_json": str(IMPLEMENTATION_DRAFT_JSON) if args.phase in {"implementation", "full"} else None,
00681:             "implementation_script": str(IMPLEMENTATION_SCRIPT) if args.phase in {"implementation", "full"} else None,
00682:         },
00683:         "npu_preflight_json": str(NPU_PREFLIGHT_JSON),
00684:         "npu_technical_notes_md": str(NPU_TECH_MD),
00685:         "creative_ollama": creative,
00686:         "technical_ollama": technical,
00687:         "final_plan": plan,
00688:     }
00689: 
00690:     write_json(DUAL_PLAN_JSON, output)
00691:     write_json(OLLAMA_INSIGHTS_JSON, technical)
00692:     OLLAMA_INSIGHTS_MD.write_text(markdown_from_insights(technical, technical.get("model", args.technical_model)), encoding="utf-8")
00693:     write_brief(plan, creative, technical, npu_notes)
00694: 
00695:     print(f"[OK] Wrote: {DUAL_PLAN_JSON}")
00696:     print(f"[OK] Wrote: {DUAL_BRIEF_MD}")
00697:     print(f"[OK] Wrote: {NPU_TECH_MD}")
00698:     if args.phase in {"implementation", "full"} and not args.skip_ollama:
00699:         print(f"[OK] Wrote: {IMPLEMENTATION_DRAFT_JSON}")
00700:         print(f"[OK] Wrote: {IMPLEMENTATION_SCRIPT}")
00701:         print(f"[OK] Wrote: {IMPLEMENTATION_NOTES}")
00702: 
00703: 
00704: if __name__ == "__main__":
00705:     main()
```
