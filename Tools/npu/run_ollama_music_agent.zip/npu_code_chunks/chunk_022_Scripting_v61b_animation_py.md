# NPU Long Context Chunk 22/94

- File: `Scripting/v61b/animation.py`
- Part: `4`
- Lines: `603-791`

## Symbol Map
- Imports: `math`, `from config import HERO_SCALE_MIN, HERO_SCALE_MAX, HERO_BOUNCE_Z, HERO_ROT_Z, HERO_ROT_X, HERO_ROT_Y, HERO_DRIFT_X, HERO_DRIFT_Y, HERO_ORBIT_X, HERO_ORBIT_Y, HERO_BEAT_TWIST_Z, HERO_ONSET_SHAKE, HERO_DEFORM_STRENGTH_MIN, HERO_DEFORM_STRENGTH_MAX, HERO_DEFORM_DETAIL_STRENGTH_MAX, HERO_DEFORM_WAVE_HEIGHT_MAX, HERO_DEFORM_TWIST_MAX, HERO_DEFORM_CONTROLLER_RADIUS, HERO_DEFORM_KEYFRAME_STEP, HERO_MATERIAL_EMISSION_MIN, HERO_MATERIAL_EMISSION_MAX, HERO_MATERIAL_SELF_LIGHT_MIN, HERO_MATERIAL_SELF_LIGHT_MAX, HERO_MATERIAL_BUMP_MIN, HERO_MATERIAL_BUMP_MAX, HERO_MATERIAL_ROUGHNESS_MIN, HERO_MATERIAL_ROUGHNESS_MAX, HERO_MATERIAL_NOISE_SCALE_MIN, HERO_MATERIAL_NOISE_SCALE_MAX, HERO_MATERIAL_MAPPING_DRIFT, AURA_DEFORM_KEYFRAME_STEP, AURA_DEFORM_FIELD_DRIFT, AURA_DEFORM_FIELD_SCALE, SECONDARY_SCALE_MIN, SECONDARY_SCALE_MAX, SECONDARY_BOUNCE_Z, SECONDARY_DRIFT_X, SECONDARY_DRIFT_Y, SECONDARY_ROT_Z, SECONDARY_ROT_X, CAMERA_BEAT_BUMP_Z, CAMERA_BEAT_BUMP_Y, CAMERA_ORBIT_AMOUNT, CAMERA_PUSH_AMOUNT, CAMERA_VERTICAL_SWAY, LIGHT_ENERGY_MIN, LIGHT_ENERGY_MAX, PHYSICS_ACCENT_EMISSION_MIN, PHYSICS_ACCENT_EMISSION_MAX, PHYSICS_ACCENT_MIX_MIN, PHYSICS_ACCENT_MIX_MAX, PHYSICS_ATOM_ORBIT_SPEED_MIN, PHYSICS_ATOM_ORBIT_AUDIO_SPEED, PHYSICS_ATOM_ORBIT_RADIUS_PULSE, PHYSICS_ATOM_ORBIT_HEIGHT_SWAY, PHYSICS_ATOM_MICRO_WOBBLE, COMPOSITOR_GLARE_THRESHOLD_MIN, COMPOSITOR_GLARE_THRESHOLD_MAX, COMPOSITOR_LENS_DISTORT_MIN, COMPOSITOR_LENS_DISTORT_MAX, COMPOSITOR_LENS_DISPERSION_MIN, COMPOSITOR_LENS_DISPERSION_MAX, FIELD_STRENGTH_MIN, FIELD_STRENGTH_MAX, HERO_GRAVITY_STRENGTH_MIN, HERO_GRAVITY_STRENGTH_MAX, TURB_STRENGTH_MIN, TURB_STRENGTH_MAX, VORTEX_STRENGTH_MIN, VORTEX_STRENGTH_MAX, RHYTHM_PARTICLE_SIZE_MIN, RHYTHM_PARTICLE_SIZE_MAX, RHYTHM_PARTICLE_NORMAL_MIN, RHYTHM_PARTICLE_NORMAL_MAX, RHYTHM_PARTICLE_TANGENT_MIN, RHYTHM_PARTICLE_TANGENT_MAX, RHYTHM_PARTICLE_BROWNIAN_MIN, RHYTHM_PARTICLE_BROWNIAN_MAX, RHYTHM_PARTICLE_EMIT_MIN, RHYTHM_PARTICLE_EMIT_MAX, RHYTHM_PARTICLE_KEYFRAME_STEP, ALBUM_LETTER_PARTICLE_SIZE_MIN, ALBUM_LETTER_PARTICLE_SIZE_MAX, ALBUM_LETTER_ROOT_SCALE_MIN, ALBUM_LETTER_ROOT_SCALE_MAX, BACKDROP_EMISSION_MIN, BACKDROP_EMISSION_MAX, BACKDROP_BREATHE_SCALE, MIST_FLOAT_AMPLITUDE, MIST_BEAT_BOOST`, `from fog_dynamics import animate_fog_frame`, `from scene_utils import set_linear_interpolation_idblock`
- Functions: `keyframe_if_possible(idblock, data_path, frame)` line 99; `get_scene_compositor_tree(scene)` line 106; `rhythm_band_drive(band, response, low, mid, high, onset, beat, pulse, local_pulse)` line 114; `animate_scene(scene, frames, camera, target, hero_asset, secondary_asset, aura_data, fog_controller, scene_base, lights, physics_data, mist_particles, variants, energy_rings, energy_ribbons)` line 132

## Content
```py
00603:                 backdrop_controls["mapping_location_socket"].keyframe_insert(data_path="default_value", frame=i)
00604: 
00605:             if "noise_scale_socket" in backdrop_controls:
00606:                 backdrop_controls["noise_scale_socket"].default_value = 2.18 + backdrop_drive * 0.12
00607:                 backdrop_controls["noise_scale_socket"].keyframe_insert(data_path="default_value", frame=i)
00608: 
00609:             if backdrop_base_scale is not None and backdrop_base_loc is not None:
00610:                 bscale = 1.0 + backdrop_drive * BACKDROP_BREATHE_SCALE
00611:                 backdrop.scale = (
00612:                     backdrop_base_scale.x * bscale,
00613:                     backdrop_base_scale.y * (1.0 + backdrop_drive * BACKDROP_BREATHE_SCALE * 0.55),
00614:                     backdrop_base_scale.z,
00615:                 )
00616:                 backdrop.location.z = backdrop_base_loc.z + math.sin(i * 0.009) * 0.012
00617:                 backdrop.keyframe_insert(data_path="scale", frame=i)
00618:                 backdrop.keyframe_insert(data_path="location", frame=i)
00619: 
00620:             if backdrop_control is not None and backdrop_base_loc is not None:
00621:                 backdrop_control.location.x = backdrop_base_loc.x
00622:                 backdrop_control.location.y = backdrop_base_loc.y
00623:                 backdrop_control.location.z = backdrop_base_loc.z + backdrop_drive * 0.012
00624:                 backdrop_control.scale = (1.0 + backdrop_drive * 0.012, 1.0 + backdrop_drive * 0.012, 1.0)
00625:                 backdrop_control.keyframe_insert(data_path="location", frame=i)
00626:                 backdrop_control.keyframe_insert(data_path="scale", frame=i)
00627: 
00628:         # MIST
00629:         for item in mist_particles:
00630:             obj = item["object"]
00631:             phase = item["phase"]
00632:             base_loc = item["base_location"]
00633:             base_scale = item["base_scale"]
00634: 
00635:             obj.location.x = base_loc.x + math.sin(i * 0.012 + phase) * 0.16
00636:             obj.location.y = base_loc.y + math.cos(i * 0.010 + phase) * 0.14
00637:             obj.location.z = base_loc.z + math.sin(i * 0.015 + phase) * MIST_FLOAT_AMPLITUDE + beat * MIST_BEAT_BOOST
00638:             obj.keyframe_insert(data_path="location", frame=i)
00639: 
00640:             pscale = base_scale + high * 0.02 + pulse * 0.02
00641:             obj.scale = (pscale, pscale, pscale)
00642:             obj.keyframe_insert(data_path="scale", frame=i)
00643: 
00644:             em_val = 0.10 + high * 0.45 + pulse * 0.35
00645:             mix_val = 0.12 + pulse * 0.08
00646: 
00647:             item["emission_socket"].default_value = em_val
00648:             item["emission_socket"].keyframe_insert(data_path="default_value", frame=i)
00649: 
00650:             item["mix_socket"].default_value = mix_val
00651:             item["mix_socket"].keyframe_insert(data_path="default_value", frame=i)
00652: 
00653:         # VARIANTS
00654:         for idx, item in enumerate(variants):
00655:             obj = item["root"]
00656:             ang = item["angle"]
00657:             base_loc = item["base_location"]
00658:             base_scale = item["base_scale"]
00659:             phase = idx * 0.55
00660: 
00661:             obj.location.x = base_loc.x + math.sin(i * 0.016 + phase) * 0.20
00662:             obj.location.y = base_loc.y + math.cos(i * 0.014 + phase) * 0.18
00663:             obj.location.z = base_loc.z + high * 0.18 + math.sin(i * 0.018 + phase) * 0.04
00664: 
00665:             sc = base_scale + low * 0.07
00666:             obj.scale = (sc, sc, sc)
00667:             obj.rotation_euler.z = ang + math.sin(i * 0.012 + phase) * math.radians(14.0)
00668: 
00669:             obj.keyframe_insert(data_path="location", frame=i)
00670:             obj.keyframe_insert(data_path="scale", frame=i)
00671:             obj.keyframe_insert(data_path="rotation_euler", frame=i)
00672: 
00673:         # RINGS / RIBBONS
00674:         for item in energy_rings:
00675:             ring = item["object"]
00676:             phase = item["phase"]
00677:             base_scale = item["base_scale"]
00678:             base_rot = item["base_rot"]
00679:             base_loc = item["base_loc"]
00680: 
00681:             pulse_scale = 1.0 + low * 0.03 + pulse * 0.02
00682:             ring.scale = (
00683:                 base_scale.x * pulse_scale,
00684:                 base_scale.y * pulse_scale,
00685:                 base_scale.z * pulse_scale,
00686:             )
00687:             ring.location.z = base_loc.z + math.sin(i * 0.009 + phase) * 0.05
00688:             ring.rotation_euler.z = base_rot.z + i * 0.006 + phase
00689: 
00690:             ring.keyframe_insert(data_path="scale", frame=i)
00691:             ring.keyframe_insert(data_path="location", frame=i)
00692:             ring.keyframe_insert(data_path="rotation_euler", frame=i)
00693: 
00694:             emit = 0.06 + (pulse * 0.40 + high * 0.60) * 0.70
00695:             item["emit_socket"].default_value = emit
00696:             item["emit_socket"].keyframe_insert(data_path="default_value", frame=i)
00697: 
00698:         for item in energy_ribbons:
00699:             ribbon = item["object"]
00700:             phase = item["phase"]
00701:             base_rot = item["base_rot"]
00702:             base_loc = item["base_loc"]
00703:             base_scale = item["base_scale"]
00704: 
00705:             ribbon.location.z = base_loc.z + math.sin(i * 0.008 + phase) * 0.12 + low * 0.03
00706:             ribbon.scale = (
00707:                 base_scale.x * (1.0 + mid * 0.05),
00708:                 base_scale.y * (1.0 + high * 0.04),
00709:                 base_scale.z,
00710:             )
00711:             ribbon.rotation_euler.z = base_rot.z + i * 0.007 + phase * 0.25
00712: 
00713:             ribbon.keyframe_insert(data_path="location", frame=i)
00714:             ribbon.keyframe_insert(data_path="scale", frame=i)
00715:             ribbon.keyframe_insert(data_path="rotation_euler", frame=i)
00716: 
00717:             emit = 0.08 + (mid * 0.55 + pulse * 0.45) * 0.82
00718:             item["emit_socket"].default_value = emit
00719:             item["emit_socket"].keyframe_insert(data_path="default_value", frame=i)
00720: 
00721:         # PHYSICS ACCENTS
00722:         for idx, item in enumerate(accents):
00723:             obj = item["object"]
00724:             anchor = item["anchor"]
00725:             base_loc = item["base_location"]
00726:             base_rot = item.get("base_rotation", obj.rotation_euler)
00727:             phase = item["phase"] + idx * 0.23
00728:             response = item.get("response", 0.65)
00729:             local_pulse = max(0.0, math.sin(i * (0.024 + response * 0.016) + phase)) * 0.20
00730:             accent_drive = rhythm_band_drive(
00731:                 item.get("band", "mid"),
00732:                 response,
00733:                 low,
00734:                 mid,
00735:                 high,
00736:                 onset,
00737:                 beat,
00738:                 pulse,
00739:                 local_pulse,
00740:             )
00741: 
00742:             orbit_radius = item.get("orbit_radius")
00743:             if orbit_radius is None:
00744:                 orbit_radius = max(0.20, math.sqrt(base_loc.x * base_loc.x + base_loc.y * base_loc.y))
00745:             orbit_angle = item.get("orbit_angle", math.atan2(base_loc.y, base_loc.x))
00746:             orbit_speed = item.get("orbit_speed", PHYSICS_ATOM_ORBIT_SPEED_MIN + response * 0.004)
00747:             orbit_tilt = item.get("orbit_tilt", 0.0)
00748:             orbit_z_offset = item.get("orbit_z_offset", base_loc.z - hero_base_loc.z)
00749:             micro_radius = item.get("micro_radius", PHYSICS_ATOM_MICRO_WOBBLE)
00750: 
00751:             speed = orbit_speed + accent_drive * PHYSICS_ATOM_ORBIT_AUDIO_SPEED + beat * 0.004
00752:             angle = orbit_angle + i * speed + math.sin(i * 0.012 + phase) * 0.055
00753:             radius = orbit_radius * (
00754:                 1.0
00755:                 + accent_drive * PHYSICS_ATOM_ORBIT_RADIUS_PULSE
00756:                 + low * 0.035
00757:                 - high * 0.012
00758:             )
00759:             y_radius = radius * (0.82 + math.cos(orbit_tilt) * 0.10)
00760:             atom_center = hero_root.location
00761: 
00762:             anchor.location.x = atom_center.x + math.cos(angle) * radius
00763:             anchor.location.y = atom_center.y + math.sin(angle) * y_radius
00764:             anchor.location.z = (
00765:                 atom_center.z
00766:                 + orbit_z_offset
00767:                 + math.sin(angle * 1.31 + orbit_tilt) * PHYSICS_ATOM_ORBIT_HEIGHT_SWAY * (0.35 + accent_drive)
00768:                 + low * 0.10
00769:                 + beat * 0.045
00770:             )
00771:             anchor.keyframe_insert(data_path="location", frame=i)
00772: 
00773:             micro_angle = angle * 2.70 + i * (0.010 + accent_drive * 0.010) + phase
00774:             micro_drive = micro_radius * (0.55 + accent_drive * 0.85)
00775:             obj.location.x = anchor.location.x + math.cos(micro_angle) * micro_drive
00776:             obj.location.y = anchor.location.y + math.sin(micro_angle) * micro_drive * 0.72
00777:             obj.location.z = anchor.location.z + math.sin(micro_angle * 1.17) * micro_drive * 0.54
00778:             obj.keyframe_insert(data_path="location", frame=i)
00779: 
00780:             obj.rotation_euler.x = base_rot.x + math.sin(i * 0.017 + phase) * 0.10 * (0.35 + accent_drive)
00781:             obj.rotation_euler.y = base_rot.y + math.cos(i * 0.015 + phase) * 0.08 * (0.35 + accent_drive)
00782:             obj.rotation_euler.z = (
00783:                 base_rot.z
00784:                 + angle
00785:                 + i * (0.006 + accent_drive * 0.006)
00786:                 + math.sin(i * 0.011 + phase) * 0.04
00787:             )
00788:             obj.keyframe_insert(data_path="rotation_euler", frame=i)
00789: 
00790:             emission_socket = item.get("emission_socket")
00791:             if emission_socket is not None:
```
