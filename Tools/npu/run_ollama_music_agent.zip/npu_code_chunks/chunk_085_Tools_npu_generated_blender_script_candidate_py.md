# NPU Long Context Chunk 85/94

- File: `Tools/npu/generated_blender_script_candidate.py`
- Part: `1`
- Lines: `1-2`

## Content
```py
00001: # AI implementation draft is a patch plan, not a runnable script.
00002: # Review the JSON draft for target_files, patch_plan, validation and notes.
```
