# NPU Long Context Chunk 14/94

- File: `Tools/npu/run_dual_ai_pipeline.py`
- Part: `4`
- Lines: `703-892`

## Symbol Map
- Imports: `from __future__ import annotations`, `from pathlib import Path`, `argparse`, `json`, `subprocess`, `from datetime import datetime`, `from typing import Any`, `from build_music_context import build_music_context`, `from build_npu_code_context import main`, `from build_blender_manual_context import build_manual_context`, `from build_project_ai_index import PROJECT_INDEX_MD, PROJECT_MANIFEST_JSON, build_project_ai_index`, `from npu_runtime import DEFAULT_MODEL_DIR, DEFAULT_NPU_PYTHON, npu_preflight, write_npu_preflight_report`, `from ollama_runtime import OllamaModelManager, parse_json_response`, `from run_ollama_music_agent import build_prompt`, `from run_ollama_music_agent import markdown_from_insights`
- Functions: `read_text(path)` line 52; `read_json(path)` line 56; `write_json(path, data)` line 62; `update_track_paths(track_stem, analysis_ai_context)` line 67; `apply_default_input_paths(args)` line 79; `validate_input_files(args)` line 92; `looks_degraded_text(text)` line 112; `deterministic_technical_notes(music_context, project_manifest, reason)` line 128; `run_npu_technical_pass(args)` line 177; `build_creative_scene_prompt(music_context, npu_notes, project_index)` line 221; `build_merge_prompt(music_context, npu_notes, creative, technical)` line 297; `build_implementation_prompt(plan, npu_notes, include_manual)` line 353; `build_implementation_retry_prompt(plan, invalid_draft, validation)` line 425; `safe_parse_json(text, fallback_key)` line 504; `get_indexed_project_files()` line 512; `validate_implementation_draft(draft)` line 517; `build_fallback_implementation_draft(reason, model)` line 572; `normalize_implementation_draft(draft, model)` line 649; `generate_implementation_draft_with_retry(manager, model_name, implementation_prompt, plan, max_new_tokens)` line 664; `write_brief(plan, creative, technical, npu_notes)` line 706; `write_implementation_draft(draft)` line 729; `main()` line 759
- Assignments: `ROOT`, `TOOLS_DIR`, `OUTPUT_DIR`, `DEFAULT_TRACK_STEM`, `TRACK_STEM`, `MUSIC_AI_CONTEXT`, `DUAL_PLAN_JSON`, `DUAL_BRIEF_MD`, `OLLAMA_INSIGHTS_JSON`, `OLLAMA_INSIGHTS_MD`, `NPU_TECH_MD`, `NPU_PREFLIGHT_JSON`, `IMPLEMENTATION_DRAFT_JSON`, `IMPLEMENTATION_SCRIPT`, `IMPLEMENTATION_NOTES`, `NPU_IMPLEMENTATION_NOTES`, `ALLOWED_NEW_PREFIXES`, `PREFERRED_IMPLEMENTATION_FILES`

## Content
```py
00703:     return normalize_implementation_draft(retry_draft, model=retry_model)
00704: 
00705: 
00706: def write_brief(plan: dict[str, Any], creative: dict[str, Any], technical: dict[str, Any], npu_notes: str) -> None:
00707:     lines = [
00708:         "# Dual AI Blender Agent Brief\n\n",
00709:         f"Generated: `{datetime.now().isoformat(timespec='seconds')}`\n\n",
00710:         "## Policy\n",
00711:         "- Full Blender keyframe JSON remains untouched.\n",
00712:         "- AI compact context is analysis only.\n",
00713:         "- Ollama model switch unloads the previous model before loading the next.\n\n",
00714:         "## Recommended Plan\n",
00715:         json.dumps(plan.get("recommended_scene_plan", plan), indent=2, ensure_ascii=False),
00716:         "\n\n## Audio Mapping\n",
00717:         json.dumps(plan.get("audio_mapping_plan", {}), indent=2, ensure_ascii=False),
00718:         "\n\n## Creative Source\n",
00719:         json.dumps(creative, indent=2, ensure_ascii=False)[:12000],
00720:         "\n\n## Technical Source\n",
00721:         json.dumps(technical, indent=2, ensure_ascii=False)[:12000],
00722:         "\n\n## NPU Notes\n",
00723:         npu_notes[:12000],
00724:         "\n",
00725:     ]
00726:     DUAL_BRIEF_MD.write_text("".join(lines), encoding="utf-8")
00727: 
00728: 
00729: def write_implementation_draft(draft: dict[str, Any]) -> None:
00730:     draft["validation"] = validate_implementation_draft(draft)
00731:     write_json(IMPLEMENTATION_DRAFT_JSON, draft)
00732: 
00733:     script = draft.get("hotpatch_candidate_script", draft.get("script", ""))
00734:     if not script:
00735:         script = (
00736:             "# AI implementation draft is a patch plan, not a runnable script.\n"
00737:             "# Review the JSON draft for target_files, patch_plan, validation and notes.\n"
00738:         )
00739:     IMPLEMENTATION_SCRIPT.write_text(str(script).rstrip() + "\n", encoding="utf-8")
00740: 
00741:     notes = [
00742:         "# Generated Implementation Notes\n\n",
00743:         "This file is an AI draft. Review before loading in Blender.\n\n",
00744:         "## Validation\n",
00745:         json.dumps(draft.get("validation", {}), indent=2, ensure_ascii=False),
00746:         "\n\n",
00747:         "## Safety\n",
00748:         json.dumps(draft.get("safety", {}), indent=2, ensure_ascii=False),
00749:         "\n\n## Notes\n",
00750:     ]
00751:     for note in draft.get("notes", []):
00752:         notes.append(f"- {note}\n")
00753:     notes.append("\n## Files To Review\n")
00754:     for path in draft.get("files_to_review_before_applying", []):
00755:         notes.append(f"- `{path}`\n")
00756:     IMPLEMENTATION_NOTES.write_text("".join(notes), encoding="utf-8")
00757: 
00758: 
00759: def main() -> None:
00760:     parser = argparse.ArgumentParser(description="Build code/music contexts, run NPU technical pass and Ollama creative passes.")
00761:     parser.add_argument("--phase", choices=["plan", "implementation", "full"], default="plan")
00762:     parser.add_argument("--track-stem", default=DEFAULT_TRACK_STEM)
00763:     parser.add_argument("--analysis", default=None)
00764:     parser.add_argument("--track-summary", default=None)
00765:     parser.add_argument("--compact-json", default=None)
00766:     parser.add_argument("--analysis-ai-context", default=None)
00767:     parser.add_argument("--blender-keyframes-json", default=None)
00768:     parser.add_argument("--skip-npu", action="store_true")
00769:     parser.add_argument("--skip-ollama", action="store_true")
00770:     parser.add_argument("--include-manual", action="store_true")
00771:     parser.add_argument("--creative-model", default="gpt-oss:20b")
00772:     parser.add_argument("--technical-model", default="qwen2.5-coder:14b")
00773:     parser.add_argument("--ollama-base-url", default=None)
00774:     parser.add_argument("--npu-python", default=str(DEFAULT_NPU_PYTHON))
00775:     parser.add_argument("--npu-model-dir", default=str(DEFAULT_MODEL_DIR))
00776:     parser.add_argument("--npu-chunk-tokens", type=int, default=520)
00777:     parser.add_argument("--npu-reduce-tokens", type=int, default=650)
00778:     parser.add_argument("--npu-final-tokens", type=int, default=900)
00779:     parser.add_argument("--max-new-tokens", type=int, default=1800)
00780:     parser.add_argument("--force-npu", action="store_true", help="Re-run NPU notes even when reusable notes exist.")
00781:     args = parser.parse_args()
00782: 
00783:     apply_default_input_paths(args)
00784:     update_track_paths(args.track_stem, args.analysis_ai_context)
00785: 
00786:     if not Path(args.analysis).exists():
00787:         raise FileNotFoundError(f"Analysis JSON missing: {args.analysis}")
00788:     if not Path(args.track_summary).exists():
00789:         raise FileNotFoundError(
00790:             f"Track summary missing: {args.track_summary}\n"
00791:             "Crea prima il track summary o usa la workflow shell che ora lo ripara automaticamente."
00792:         )
00793:     if args.phase == "implementation" and not DUAL_PLAN_JSON.exists():
00794:         raise FileNotFoundError(f"Dual AI scene plan missing, run phase plan first: {DUAL_PLAN_JSON}")
00795: 
00796:     build_code_context()
00797:     project_manifest = build_project_ai_index()
00798:     build_music_context(
00799:         analysis_path=Path(args.analysis),
00800:         track_summary_path=Path(args.track_summary),
00801:         compact_json_path=Path(args.compact_json),
00802:         analysis_ai_context_path=Path(args.analysis_ai_context),
00803:         blender_keyframes_path=Path(args.blender_keyframes_json),
00804:     )
00805:     if args.include_manual:
00806:         build_manual_context(limit_files=80)
00807:     validate_input_files(args)
00808:     music_context = read_json(MUSIC_AI_CONTEXT)
00809: 
00810:     npu_notes = ""
00811:     if not args.skip_npu:
00812:         if args.phase == "implementation" and not args.force_npu and NPU_TECH_MD.exists():
00813:             npu_notes = read_text(NPU_TECH_MD)
00814:             print(f"[NPU] Reusing plan technical notes: {NPU_TECH_MD}")
00815:         else:
00816:             report = npu_preflight(args.npu_python, args.npu_model_dir)
00817:             write_npu_preflight_report(report, NPU_PREFLIGHT_JSON)
00818:             if report.get("ready"):
00819:                 try:
00820:                     npu_notes = run_npu_technical_pass(args)
00821:                 except Exception as exc:
00822:                     npu_notes = f"NPU technical pass unavailable after ready preflight: {exc}"
00823:                     NPU_TECH_MD.write_text(npu_notes, encoding="utf-8")
00824:             else:
00825:                 npu_notes = "NPU not ready. Preflight:\n" + json.dumps(report, indent=2, ensure_ascii=False)
00826:                 NPU_TECH_MD.write_text(npu_notes, encoding="utf-8")
00827: 
00828:         if looks_degraded_text(npu_notes):
00829:             npu_notes = deterministic_technical_notes(
00830:                 music_context=music_context,
00831:                 project_manifest=project_manifest,
00832:                 reason="degraded_or_too_short_npu_output",
00833:             )
00834:             NPU_TECH_MD.write_text(npu_notes, encoding="utf-8")
00835:             if args.phase == "implementation":
00836:                 NPU_IMPLEMENTATION_NOTES.write_text(npu_notes, encoding="utf-8")
00837:             print("[WARN] NPU notes looked degraded; deterministic technical notes were used.")
00838: 
00839:     if args.phase == "implementation":
00840:         if args.skip_ollama:
00841:             draft = build_fallback_implementation_draft(
00842:                 reason="Ollama skipped; implementation draft intentionally contains deterministic patch targets.",
00843:                 model=None,
00844:             )
00845:             write_implementation_draft(draft)
00846:         else:
00847:             plan_output = read_json(DUAL_PLAN_JSON)
00848:             plan = plan_output.get("final_plan", plan_output)
00849:             manager_kwargs = {}
00850:             if args.ollama_base_url:
00851:                 manager_kwargs["base_url"] = args.ollama_base_url
00852:             with OllamaModelManager(**manager_kwargs) as manager:
00853:                 implementation_prompt = build_implementation_prompt(plan, npu_notes, args.include_manual)
00854:                 draft = generate_implementation_draft_with_retry(
00855:                     manager=manager,
00856:                     model_name=args.technical_model,
00857:                     implementation_prompt=implementation_prompt,
00858:                     plan=plan,
00859:                     max_new_tokens=args.max_new_tokens,
00860:                 )
00861:                 write_implementation_draft(draft)
00862: 
00863:         print(f"[OK] Wrote: {IMPLEMENTATION_DRAFT_JSON}")
00864:         print(f"[OK] Wrote: {IMPLEMENTATION_SCRIPT}")
00865:         print(f"[OK] Wrote: {IMPLEMENTATION_NOTES}")
00866:         return
00867: 
00868:     if args.skip_ollama:
00869:         creative = {"skipped": True}
00870:         technical = {"skipped": True}
00871:         plan = {
00872:             "pipeline_policy": {
00873:                 "use_full_blender_keyframes_json": True,
00874:                 "ai_context_is_analysis_only": True,
00875:                 "ollama_model_switch_policy": "unload previous model before loading next",
00876:             },
00877:             "recommended_scene_plan": {
00878:                 "summary": "Ollama skipped; use NPU notes only.",
00879:                 "priority_changes": [],
00880:                 "defer_changes": [],
00881:             },
00882:         }
00883:     else:
00884:         manager_kwargs = {}
00885:         if args.ollama_base_url:
00886:             manager_kwargs["base_url"] = args.ollama_base_url
00887: 
00888:         with OllamaModelManager(**manager_kwargs) as manager:
00889:             creative_prompt = build_creative_scene_prompt(music_context, npu_notes, read_text(PROJECT_INDEX_MD))
00890:             creative_text, creative_model = manager.generate(
00891:                 args.creative_model,
00892:                 creative_prompt,
```
