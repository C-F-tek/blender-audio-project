# NPU Long Context Chunk 42/94

- File: `Scripting/v61b/scene_tuning_panel.py`
- Part: `5`
- Lines: `907-1136`

## Symbol Map
- Imports: `json`, `sys`, `traceback`, `from pathlib import Path`, `bpy`, `from bpy.props import BoolProperty, FloatProperty, PointerProperty, StringProperty`
- Classes: `ST_TuningSettings` line 770; `ST_OT_apply_tuning` line 822 methods: execute; `ST_OT_keyframe_tuning` line 833 methods: execute; `ST_OT_scale_animation` line 844 methods: execute; `ST_OT_apply_runtime_profile` line 855 methods: execute; `ST_OT_hot_update_scene` line 871 methods: execute; `ST_OT_rebuild_restart_check` line 895 methods: execute; `ST_OT_optimizer_check` line 920 methods: execute; `ST_OT_load_image_sequence` line 943 methods: execute; `ST_OT_encode_ffmpeg` line 965 methods: execute; `ST_OT_encode_ffmpeg_shell` line 987 methods: execute; `ST_OT_save_preset` line 1016 methods: execute; `ST_OT_load_preset` line 1027 methods: execute; `ST_OT_open_guide_text` line 1043 methods: execute; `ST_OT_select_group` line 1062 methods: execute; `ST_PT_tuning_panel` line 1098 methods: draw
- Functions: `resolve_script_dir()` line 20; `iter_action_fcurves(action)` line 56; `find_obj(name)` line 88; `objects_with_prefix(prefix)` line 92; `particle_emitters()` line 96; `particle_source_objects()` line 106; `store_base_vector(obj, key, value)` line 117; `store_base_float(idblock, key, value)` line 123; `set_scale_from_base(obj, factor, key)` line 132; `keyframe_if_possible(idblock, data_path, frame)` line 140; `find_material(name)` line 147; `find_node(material_name, node_name)` line 151; `set_value_node(material_name, node_name, value)` line 158; `set_input_node(material_name, node_name, input_name, value)` line 169; `keyframe_socket(socket, frame)` line 180; `get_scene_compositor_tree(scene)` line 186; `clamp_value(value, min_value, max_value)` line 194; `normalize_runtime_profile(profile)` line 198; `runtime_profile_label(profile)` line 244; `apply_runtime_profile(context, profile)` line 257; `all_particle_settings()` line 442; `apply_tuning(context, insert_keyframes)` line 454; `scale_fcurve_values(idblock, predicate, factor)` line 669; `scale_full_animation(context)` line 685; `preset_data(settings)` line 721; `load_preset_data(settings, data)` line 764; `register()` line 1239; `unregister()` line 1254
- Assignments: `bl_info`, `SCRIPT_DIR`, `PRESET_PATH`, `GUIDE_PATH`, `HOT_UPDATE_PATH`, `ENCODE_SEQUENCE_PATH`, `ENCODE_FFMPEG_PATH`, `classes`

## Content
```py
00907:             traceback.print_exc()
00908:             self.report({'ERROR'}, f"Check failed: {exc}")
00909:             return {'CANCELLED'}
00910: 
00911:         if result["blocking"]:
00912:             self.report({'WARNING'}, "Full rebuild needed. See SPAZIOTEMPO_REBUILD_CHECK.")
00913:         elif result["restart"]:
00914:             self.report({'WARNING'}, "Registration issue found. See SPAZIOTEMPO_REBUILD_CHECK.")
00915:         else:
00916:             self.report({'INFO'}, "Hotpatch should be enough. See SPAZIOTEMPO_REBUILD_CHECK.")
00917:         return {'FINISHED'}
00918: 
00919: 
00920: class ST_OT_optimizer_check(bpy.types.Operator):
00921:     bl_idname = "spaziotempo.optimizer_check"
00922:     bl_label = "Optimizer Check"
00923:     bl_options = {'REGISTER'}
00924: 
00925:     def execute(self, context):
00926:         try:
00927:             sys.modules.pop("hotpatch.diagnostics", None)
00928:             from hotpatch.diagnostics import analyze_optimizer
00929: 
00930:             result = analyze_optimizer()
00931:         except Exception as exc:
00932:             traceback.print_exc()
00933:             self.report({'ERROR'}, f"Optimizer check failed: {exc}")
00934:             return {'CANCELLED'}
00935: 
00936:         if result["warnings"]:
00937:             self.report({'WARNING'}, "Cache/bake suggestions found. See SPAZIOTEMPO_OPTIMIZER_REPORT.")
00938:         else:
00939:             self.report({'INFO'}, "No required bake found. See SPAZIOTEMPO_OPTIMIZER_REPORT.")
00940:         return {'FINISHED'}
00941: 
00942: 
00943: class ST_OT_load_image_sequence(bpy.types.Operator):
00944:     bl_idname = "spaziotempo.load_image_sequence"
00945:     bl_label = "Load Image Sequence"
00946:     bl_options = {'REGISTER', 'UNDO'}
00947: 
00948:     def execute(self, context):
00949:         if not ENCODE_SEQUENCE_PATH.exists():
00950:             self.report({'WARNING'}, f"Image sequence script not found: {ENCODE_SEQUENCE_PATH}")
00951:             return {'CANCELLED'}
00952: 
00953:         try:
00954:             code = compile(ENCODE_SEQUENCE_PATH.read_text(encoding="utf-8"), str(ENCODE_SEQUENCE_PATH), "exec")
00955:             exec(code, {"__file__": str(ENCODE_SEQUENCE_PATH), "__name__": "__main__"})
00956:         except Exception as exc:
00957:             traceback.print_exc()
00958:             self.report({'ERROR'}, f"Image sequence load failed: {exc}")
00959:             return {'CANCELLED'}
00960: 
00961:         self.report({'INFO'}, "Image sequence + audio loaded in Video Sequencer.")
00962:         return {'FINISHED'}
00963: 
00964: 
00965: class ST_OT_encode_ffmpeg(bpy.types.Operator):
00966:     bl_idname = "spaziotempo.encode_ffmpeg"
00967:     bl_label = "Encode MP4 FFmpeg"
00968:     bl_options = {'REGISTER', 'UNDO'}
00969: 
00970:     def execute(self, context):
00971:         if not ENCODE_FFMPEG_PATH.exists():
00972:             self.report({'WARNING'}, f"FFmpeg encode script not found: {ENCODE_FFMPEG_PATH}")
00973:             return {'CANCELLED'}
00974: 
00975:         try:
00976:             code = compile(ENCODE_FFMPEG_PATH.read_text(encoding="utf-8"), str(ENCODE_FFMPEG_PATH), "exec")
00977:             exec(code, {"__file__": str(ENCODE_FFMPEG_PATH), "__name__": "__main__"})
00978:         except Exception as exc:
00979:             traceback.print_exc()
00980:             self.report({'ERROR'}, f"FFmpeg encode failed: {exc}")
00981:             return {'CANCELLED'}
00982: 
00983:         self.report({'INFO'}, "FFmpeg MP4 encoded from image sequence.")
00984:         return {'FINISHED'}
00985: 
00986: 
00987: class ST_OT_encode_ffmpeg_shell(bpy.types.Operator):
00988:     bl_idname = "spaziotempo.encode_ffmpeg_shell"
00989:     bl_label = "Encode MP4 FFmpeg Shell"
00990:     bl_options = {'REGISTER'}
00991: 
00992:     def execute(self, context):
00993:         if not ENCODE_FFMPEG_PATH.exists():
00994:             self.report({'WARNING'}, f"FFmpeg encode script not found: {ENCODE_FFMPEG_PATH}")
00995:             return {'CANCELLED'}
00996: 
00997:         try:
00998:             code = compile(ENCODE_FFMPEG_PATH.read_text(encoding="utf-8"), str(ENCODE_FFMPEG_PATH), "exec")
00999:             exec(
01000:                 code,
01001:                 {
01002:                     "__file__": str(ENCODE_FFMPEG_PATH),
01003:                     "__name__": "__main__",
01004:                     "FFMPEG_LAUNCH_VISIBLE_SHELL": True,
01005:                 },
01006:             )
01007:         except Exception as exc:
01008:             traceback.print_exc()
01009:             self.report({'ERROR'}, f"FFmpeg shell encode failed: {exc}")
01010:             return {'CANCELLED'}
01011: 
01012:         self.report({'INFO'}, "FFmpeg encode launched in external shell.")
01013:         return {'FINISHED'}
01014: 
01015: 
01016: class ST_OT_save_preset(bpy.types.Operator):
01017:     bl_idname = "spaziotempo.save_tuning_preset"
01018:     bl_label = "Save Preset"
01019: 
01020:     def execute(self, context):
01021:         data = preset_data(context.scene.spaziotempo_tuning)
01022:         PRESET_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")
01023:         self.report({'INFO'}, f"Preset saved: {PRESET_PATH}")
01024:         return {'FINISHED'}
01025: 
01026: 
01027: class ST_OT_load_preset(bpy.types.Operator):
01028:     bl_idname = "spaziotempo.load_tuning_preset"
01029:     bl_label = "Load Preset"
01030: 
01031:     def execute(self, context):
01032:         if not PRESET_PATH.exists():
01033:             self.report({'WARNING'}, f"Preset not found: {PRESET_PATH}")
01034:             return {'CANCELLED'}
01035: 
01036:         data = json.loads(PRESET_PATH.read_text(encoding="utf-8"))
01037:         load_preset_data(context.scene.spaziotempo_tuning, data)
01038:         apply_tuning(context, insert_keyframes=False)
01039:         self.report({'INFO'}, "Preset loaded and applied.")
01040:         return {'FINISHED'}
01041: 
01042: 
01043: class ST_OT_open_guide_text(bpy.types.Operator):
01044:     bl_idname = "spaziotempo.open_tuning_guide"
01045:     bl_label = "Open Editable Guide"
01046: 
01047:     def execute(self, context):
01048:         text_name = "SPAZIOTEMPO_TUNING_GUIDE"
01049:         guide = bpy.data.texts.get(text_name) or bpy.data.texts.new(text_name)
01050: 
01051:         if GUIDE_PATH.exists():
01052:             body = GUIDE_PATH.read_text(encoding="utf-8")
01053:         else:
01054:             body = "Spaziotempo tuning guide not found."
01055: 
01056:         guide.clear()
01057:         guide.write(body)
01058:         self.report({'INFO'}, f"Guide opened as Blender text block: {text_name}")
01059:         return {'FINISHED'}
01060: 
01061: 
01062: class ST_OT_select_group(bpy.types.Operator):
01063:     bl_idname = "spaziotempo.select_group"
01064:     bl_label = "Select Scene Group"
01065: 
01066:     group: bpy.props.StringProperty(default="hero")
01067: 
01068:     def execute(self, context):
01069:         bpy.ops.object.select_all(action='DESELECT')
01070: 
01071:         names = []
01072:         if self.group == "hero":
01073:             names = ["HeroRoot", "HeroDeformController", "AuraAudioSampler"]
01074:         elif self.group == "particles":
01075:             names = [obj.name for obj in particle_emitters()]
01076:         elif self.group == "fog":
01077:             names = ["AtmosphereCube", "FogPulseController", "FogFilamentsRoot", "SoftRhythmBackdrop", "BackdropPulseController"]
01078:             names.extend(obj.name for obj in objects_with_prefix("FogFilament_"))
01079:         elif self.group == "letters":
01080:             names = ["AlbumLetterParticleSources"]
01081:             names.extend(obj.name for obj in objects_with_prefix("AlbumLetterParticle_"))
01082: 
01083:         selected = []
01084:         for name in names:
01085:             obj = find_obj(name)
01086:             if obj is None:
01087:                 continue
01088:             obj.hide_viewport = False
01089:             obj.select_set(True)
01090:             selected.append(obj)
01091: 
01092:         if selected:
01093:             context.view_layer.objects.active = selected[0]
01094:         self.report({'INFO'}, f"Selected {len(selected)} objects.")
01095:         return {'FINISHED'}
01096: 
01097: 
01098: class ST_PT_tuning_panel(bpy.types.Panel):
01099:     bl_label = "Scene Tuner"
01100:     bl_idname = "ST_PT_tuning_panel"
01101:     bl_space_type = 'VIEW_3D'
01102:     bl_region_type = 'UI'
01103:     bl_category = "Spaziotempo"
01104: 
01105:     def draw(self, context):
01106:         layout = self.layout
01107:         tune = context.scene.spaziotempo_tuning
01108: 
01109:         row = layout.row(align=True)
01110:         row.operator("spaziotempo.apply_tuning", icon='CHECKMARK')
01111:         row.operator("spaziotempo.keyframe_tuning", icon='KEY_HLT')
01112: 
01113:         box = layout.box()
01114:         box.label(text="Hot Update")
01115:         row = box.row(align=True)
01116:         op = row.operator("spaziotempo.hot_update_scene", text="Render Only", icon='OUTPUT')
01117:         op.mode = "RENDER"
01118:         op = row.operator("spaziotempo.hot_update_scene", text="Materials", icon='MATERIAL')
01119:         op.mode = "MATERIALS"
01120:         row = box.row(align=True)
01121:         op = row.operator("spaziotempo.hot_update_scene", text="Fog", icon='MOD_FLUIDSIM')
01122:         op.mode = "FOG"
01123:         op = row.operator("spaziotempo.hot_update_scene", text="Physics", icon='PHYSICS')
01124:         op.mode = "PHYSICS"
01125:         op = box.operator("spaziotempo.hot_update_scene", text="Hot Update All", icon='FILE_REFRESH')
01126:         op.mode = "ALL"
01127: 
01128:         row = box.row(align=True)
01129:         row.operator("spaziotempo.rebuild_restart_check", icon='VIEWZOOM')
01130:         row.operator("spaziotempo.optimizer_check", icon='SETTINGS')
01131: 
01132:         row = layout.row(align=True)
01133:         row.operator("spaziotempo.save_tuning_preset", icon='FILE_TICK')
01134:         row.operator("spaziotempo.load_tuning_preset", icon='FILE_REFRESH')
01135: 
01136:         layout.operator("spaziotempo.open_tuning_guide", icon='TEXT')
```
