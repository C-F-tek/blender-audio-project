# NPU Long Context Chunk 15/94

- File: `Tools/npu/run_dual_ai_pipeline.py`
- Part: `5`
- Lines: `893-967`

## Symbol Map
- Imports: `from __future__ import annotations`, `from pathlib import Path`, `argparse`, `json`, `subprocess`, `from datetime import datetime`, `from typing import Any`, `from build_music_context import build_music_context`, `from build_npu_code_context import main`, `from build_blender_manual_context import build_manual_context`, `from build_project_ai_index import PROJECT_INDEX_MD, PROJECT_MANIFEST_JSON, build_project_ai_index`, `from npu_runtime import DEFAULT_MODEL_DIR, DEFAULT_NPU_PYTHON, npu_preflight, write_npu_preflight_report`, `from ollama_runtime import OllamaModelManager, parse_json_response`, `from run_ollama_music_agent import build_prompt`, `from run_ollama_music_agent import markdown_from_insights`
- Functions: `read_text(path)` line 52; `read_json(path)` line 56; `write_json(path, data)` line 62; `update_track_paths(track_stem, analysis_ai_context)` line 67; `apply_default_input_paths(args)` line 79; `validate_input_files(args)` line 92; `looks_degraded_text(text)` line 112; `deterministic_technical_notes(music_context, project_manifest, reason)` line 128; `run_npu_technical_pass(args)` line 177; `build_creative_scene_prompt(music_context, npu_notes, project_index)` line 221; `build_merge_prompt(music_context, npu_notes, creative, technical)` line 297; `build_implementation_prompt(plan, npu_notes, include_manual)` line 353; `build_implementation_retry_prompt(plan, invalid_draft, validation)` line 425; `safe_parse_json(text, fallback_key)` line 504; `get_indexed_project_files()` line 512; `validate_implementation_draft(draft)` line 517; `build_fallback_implementation_draft(reason, model)` line 572; `normalize_implementation_draft(draft, model)` line 649; `generate_implementation_draft_with_retry(manager, model_name, implementation_prompt, plan, max_new_tokens)` line 664; `write_brief(plan, creative, technical, npu_notes)` line 706; `write_implementation_draft(draft)` line 729; `main()` line 759
- Assignments: `ROOT`, `TOOLS_DIR`, `OUTPUT_DIR`, `DEFAULT_TRACK_STEM`, `TRACK_STEM`, `MUSIC_AI_CONTEXT`, `DUAL_PLAN_JSON`, `DUAL_BRIEF_MD`, `OLLAMA_INSIGHTS_JSON`, `OLLAMA_INSIGHTS_MD`, `NPU_TECH_MD`, `NPU_PREFLIGHT_JSON`, `IMPLEMENTATION_DRAFT_JSON`, `IMPLEMENTATION_SCRIPT`, `IMPLEMENTATION_NOTES`, `NPU_IMPLEMENTATION_NOTES`, `ALLOWED_NEW_PREFIXES`, `PREFERRED_IMPLEMENTATION_FILES`

## Content
```py
00893:                 max_new_tokens=args.max_new_tokens,
00894:                 temperature=0.20,
00895:             )
00896:             creative = safe_parse_json(creative_text, "raw_creative_response")
00897:             creative["model"] = creative_model
00898: 
00899:             technical_prompt = build_music_prompt(music_context)
00900:             technical_text, technical_model = manager.generate(
00901:                 args.technical_model,
00902:                 technical_prompt,
00903:                 max_new_tokens=args.max_new_tokens,
00904:                 temperature=0.10,
00905:             )
00906:             technical = safe_parse_json(technical_text, "raw_technical_response")
00907:             technical["model"] = technical_model
00908: 
00909:             merge_prompt = build_merge_prompt(music_context, npu_notes, creative, technical)
00910:             merge_text, merge_model = manager.generate(
00911:                 args.technical_model,
00912:                 merge_prompt,
00913:                 max_new_tokens=args.max_new_tokens,
00914:                 temperature=0.08,
00915:             )
00916:             plan = safe_parse_json(merge_text, "raw_plan_response")
00917:             plan["merge_model"] = merge_model
00918: 
00919:             if args.phase == "full":
00920:                 implementation_prompt = build_implementation_prompt(plan, npu_notes, args.include_manual)
00921:                 draft = generate_implementation_draft_with_retry(
00922:                     manager=manager,
00923:                     model_name=args.technical_model,
00924:                     implementation_prompt=implementation_prompt,
00925:                     plan=plan,
00926:                     max_new_tokens=args.max_new_tokens,
00927:                 )
00928:                 write_implementation_draft(draft)
00929: 
00930:     output = {
00931:         "generated_at": datetime.now().isoformat(timespec="seconds"),
00932:         "track_stem": TRACK_STEM,
00933:         "policy": {
00934:             "full_blender_keyframes_json": str(Path(args.blender_keyframes_json)),
00935:             "ai_context_json": str(MUSIC_AI_CONTEXT),
00936:             "model_switch_rule": "Unload/stop previous Ollama model before loading the next model.",
00937:             "phase": args.phase,
00938:             "manual_context_used": args.include_manual,
00939:             "implementation_draft_json": str(IMPLEMENTATION_DRAFT_JSON) if args.phase in {"implementation", "full"} else None,
00940:             "implementation_script": str(IMPLEMENTATION_SCRIPT) if args.phase in {"implementation", "full"} else None,
00941:         },
00942:         "npu_preflight_json": str(NPU_PREFLIGHT_JSON),
00943:         "npu_technical_notes_md": str(NPU_TECH_MD),
00944:         "creative_ollama": creative,
00945:         "technical_ollama": technical,
00946:         "final_plan": plan,
00947:     }
00948: 
00949:     write_json(DUAL_PLAN_JSON, output)
00950:     write_json(OLLAMA_INSIGHTS_JSON, technical)
00951:     OLLAMA_INSIGHTS_MD.write_text(
00952:         markdown_from_insights(technical, technical.get("model", args.technical_model)),
00953:         encoding="utf-8",
00954:     )
00955:     write_brief(plan, creative, technical, npu_notes)
00956: 
00957:     print(f"[OK] Wrote: {DUAL_PLAN_JSON}")
00958:     print(f"[OK] Wrote: {DUAL_BRIEF_MD}")
00959:     print(f"[OK] Wrote: {NPU_TECH_MD}")
00960:     if args.phase in {"implementation", "full"} and not args.skip_ollama:
00961:         print(f"[OK] Wrote: {IMPLEMENTATION_DRAFT_JSON}")
00962:         print(f"[OK] Wrote: {IMPLEMENTATION_SCRIPT}")
00963:         print(f"[OK] Wrote: {IMPLEMENTATION_NOTES}")
00964: 
00965: 
00966: if __name__ == "__main__":
00967:     main()
```
