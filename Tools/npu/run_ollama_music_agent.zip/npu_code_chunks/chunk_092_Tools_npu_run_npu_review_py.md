# NPU Long Context Chunk 92/94

- File: `Tools/npu/run_npu_review.py`
- Part: `3`
- Lines: `521-565`

## Symbol Map
- Imports: `from __future__ import annotations`, `from pathlib import Path`, `argparse`, `from datetime import datetime`
- Functions: `read_text(path)` line 21; `read_text_limited(path, max_chars)` line 25; `split_text(text, max_chars, overlap_chars)` line 34; `load_context_chunks(context_path, chunk_dir, chunk_chars, overlap_chars, max_chunks)` line 52; `fit_prompt(prefix, context, suffix, max_prompt_chars)` line 78; `build_onepass_prompt(context, max_prompt_chars, domain)` line 92; `build_chunk_prompt(title, index, total, context, max_prompt_chars, domain)` line 163; `build_batch_reduce_prompt(batch_title, notes, max_prompt_chars, domain)` line 235; `build_final_prompt(notes, max_prompt_chars, domain)` line 274; `create_pipeline(model_dir, device, max_prompt_len, min_response_len)` line 346; `create_ollama_pipeline(args)` line 358; `generate_text(pipe, prompt, max_new_tokens)` line 373; `write_notes(notes_out, notes)` line 378; `pack_batches(items, max_chars)` line 393; `reduce_notes(pipe, notes, args)` line 413; `run_onepass(pipe, context_path, args)` line 435; `run_chunked(pipe, context_path, chunk_dir, notes_out, args)` line 441; `main()` line 477
- Assignments: `ROOT`, `DEFAULT_MODEL_DIR`, `DEFAULT_CONTEXT`, `DEFAULT_CHUNK_DIR`, `DEFAULT_OUT`, `DEFAULT_NOTES_OUT`, `DEFAULT_MUSIC_CONTEXT`, `DEFAULT_MUSIC_CHUNK_DIR`, `DEFAULT_MUSIC_OUT`, `DEFAULT_MUSIC_NOTES_OUT`

## Content
```py
00521:     context_path = Path(args.context)
00522:     chunk_dir = Path(args.chunk_dir)
00523:     out_path = Path(args.out)
00524:     notes_out = Path(args.notes_out)
00525: 
00526:     if args.engine == "npu" and not model_dir.exists():
00527:         raise FileNotFoundError(f"Model dir not found: {model_dir}")
00528: 
00529:     if not context_path.exists():
00530:         raise FileNotFoundError(f"Context file not found: {context_path}")
00531: 
00532:     print(f"[AI] Engine: {args.engine}")
00533:     print(f"[AI] Mode: {args.mode}")
00534:     print(f"[AI] Domain: {args.domain}")
00535: 
00536:     if args.engine == "ollama":
00537:         print(f"[Ollama] Model preference: {args.ollama_model}")
00538:         pipe = create_ollama_pipeline(args)
00539:     else:
00540:         print(f"[NPU] Loading model: {model_dir}")
00541:         print(f"[NPU] Device: {args.device}")
00542:         pipe = create_pipeline(
00543:             model_dir=model_dir,
00544:             device=args.device,
00545:             max_prompt_len=args.max_prompt_len,
00546:             min_response_len=args.min_response_len,
00547:         )
00548: 
00549:     try:
00550:         if args.mode == "onepass":
00551:             text = run_onepass(pipe, context_path, args)
00552:         else:
00553:             text = run_chunked(pipe, context_path, chunk_dir, notes_out, args)
00554:     finally:
00555:         if hasattr(pipe, "close"):
00556:             pipe.close()
00557: 
00558:     out_path.parent.mkdir(parents=True, exist_ok=True)
00559:     out_path.write_text(text.strip() + "\n", encoding="utf-8")
00560: 
00561:     print(f"[OK] Wrote: {out_path}")
00562: 
00563: 
00564: if __name__ == "__main__":
00565:     main()
```
