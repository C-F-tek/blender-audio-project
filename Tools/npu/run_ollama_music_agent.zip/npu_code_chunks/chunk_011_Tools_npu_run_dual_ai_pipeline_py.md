# NPU Long Context Chunk 11/94

- File: `Tools/npu/run_dual_ai_pipeline.py`
- Part: `1`
- Lines: `1-216`

## Symbol Map
- Imports: `from __future__ import annotations`, `from pathlib import Path`, `argparse`, `json`, `subprocess`, `from datetime import datetime`, `from typing import Any`, `from build_music_context import build_music_context`, `from build_npu_code_context import main`, `from build_blender_manual_context import build_manual_context`, `from build_project_ai_index import PROJECT_INDEX_MD, PROJECT_MANIFEST_JSON, build_project_ai_index`, `from npu_runtime import DEFAULT_MODEL_DIR, DEFAULT_NPU_PYTHON, npu_preflight, write_npu_preflight_report`, `from ollama_runtime import OllamaModelManager, parse_json_response`, `from run_ollama_music_agent import build_prompt`, `from run_ollama_music_agent import markdown_from_insights`
- Functions: `read_text(path)` line 52; `read_json(path)` line 56; `write_json(path, data)` line 62; `update_track_paths(track_stem, analysis_ai_context)` line 67; `apply_default_input_paths(args)` line 79; `validate_input_files(args)` line 92; `looks_degraded_text(text)` line 112; `deterministic_technical_notes(music_context, project_manifest, reason)` line 128; `run_npu_technical_pass(args)` line 177; `build_creative_scene_prompt(music_context, npu_notes, project_index)` line 221; `build_merge_prompt(music_context, npu_notes, creative, technical)` line 297; `build_implementation_prompt(plan, npu_notes, include_manual)` line 353; `build_implementation_retry_prompt(plan, invalid_draft, validation)` line 425; `safe_parse_json(text, fallback_key)` line 504; `get_indexed_project_files()` line 512; `validate_implementation_draft(draft)` line 517; `build_fallback_implementation_draft(reason, model)` line 572; `normalize_implementation_draft(draft, model)` line 649; `generate_implementation_draft_with_retry(manager, model_name, implementation_prompt, plan, max_new_tokens)` line 664; `write_brief(plan, creative, technical, npu_notes)` line 706; `write_implementation_draft(draft)` line 729; `main()` line 759
- Assignments: `ROOT`, `TOOLS_DIR`, `OUTPUT_DIR`, `DEFAULT_TRACK_STEM`, `TRACK_STEM`, `MUSIC_AI_CONTEXT`, `DUAL_PLAN_JSON`, `DUAL_BRIEF_MD`, `OLLAMA_INSIGHTS_JSON`, `OLLAMA_INSIGHTS_MD`, `NPU_TECH_MD`, `NPU_PREFLIGHT_JSON`, `IMPLEMENTATION_DRAFT_JSON`, `IMPLEMENTATION_SCRIPT`, `IMPLEMENTATION_NOTES`, `NPU_IMPLEMENTATION_NOTES`, `ALLOWED_NEW_PREFIXES`, `PREFERRED_IMPLEMENTATION_FILES`

## Content
```py
00001: from __future__ import annotations
00002: 
00003: from pathlib import Path
00004: import argparse
00005: import json
00006: import subprocess
00007: from datetime import datetime
00008: from typing import Any
00009: 
00010: from build_music_context import build_music_context
00011: from build_npu_code_context import main as build_code_context
00012: from build_blender_manual_context import build_manual_context
00013: from build_project_ai_index import PROJECT_INDEX_MD, PROJECT_MANIFEST_JSON, build_project_ai_index
00014: from npu_runtime import DEFAULT_MODEL_DIR, DEFAULT_NPU_PYTHON, npu_preflight, write_npu_preflight_report
00015: from ollama_runtime import OllamaModelManager, parse_json_response
00016: from run_ollama_music_agent import build_prompt as build_music_prompt
00017: from run_ollama_music_agent import markdown_from_insights
00018: 
00019: 
00020: ROOT = Path(__file__).resolve().parents[2]
00021: TOOLS_DIR = ROOT / "Tools" / "npu"
00022: OUTPUT_DIR = ROOT / "output"
00023: 
00024: DEFAULT_TRACK_STEM = "Feel The Light-Luca Vera_Master"
00025: TRACK_STEM = DEFAULT_TRACK_STEM
00026: 
00027: MUSIC_AI_CONTEXT = OUTPUT_DIR / f"{TRACK_STEM}_analysis_ai_context.json"
00028: DUAL_PLAN_JSON = OUTPUT_DIR / f"{TRACK_STEM}_dual_ai_scene_plan.json"
00029: DUAL_BRIEF_MD = TOOLS_DIR / "dual_ai_blender_agent_brief.md"
00030: OLLAMA_INSIGHTS_JSON = OUTPUT_DIR / f"{TRACK_STEM}_ollama_music_insights.json"
00031: OLLAMA_INSIGHTS_MD = TOOLS_DIR / "ollama_music_insights.md"
00032: NPU_TECH_MD = TOOLS_DIR / "npu_dual_ai_technical_notes.md"
00033: NPU_PREFLIGHT_JSON = TOOLS_DIR / "npu_preflight_report.json"
00034: IMPLEMENTATION_DRAFT_JSON = OUTPUT_DIR / f"{TRACK_STEM}_ai_implementation_draft.json"
00035: IMPLEMENTATION_SCRIPT = TOOLS_DIR / "generated_blender_script_candidate.py"
00036: IMPLEMENTATION_NOTES = TOOLS_DIR / "generated_implementation_notes.md"
00037: NPU_IMPLEMENTATION_NOTES = TOOLS_DIR / "npu_dual_ai_implementation_notes.md"
00038: 
00039: 
00040: ALLOWED_NEW_PREFIXES = ("Scripting/v61b/hotpatch/", "indexAI/patch_library/")
00041: PREFERRED_IMPLEMENTATION_FILES = (
00042:     "Scripting/v61b/materials.py",
00043:     "Scripting/v61b/fog_dynamics.py",
00044:     "Scripting/v61b/physics_setup.py",
00045:     "Scripting/v61b/scene_tuning_panel.py",
00046:     "Scripting/v61b/config.py",
00047:     "Scripting/v61b/render_setup.py",
00048:     "Scripting/v61b/hot_update_scene_v61b.py",
00049: )
00050: 
00051: 
00052: def read_text(path: Path) -> str:
00053:     return path.read_text(encoding="utf-8", errors="replace") if path.exists() else ""
00054: 
00055: 
00056: def read_json(path: Path) -> dict[str, Any]:
00057:     with open(path, "r", encoding="utf-8") as handle:
00058:         data = json.load(handle)
00059:     return data if isinstance(data, dict) else {}
00060: 
00061: 
00062: def write_json(path: Path, data: dict[str, Any]) -> None:
00063:     path.parent.mkdir(parents=True, exist_ok=True)
00064:     path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
00065: 
00066: 
00067: def update_track_paths(track_stem: str, analysis_ai_context: str | None = None) -> None:
00068:     global TRACK_STEM
00069:     global MUSIC_AI_CONTEXT, DUAL_PLAN_JSON, OLLAMA_INSIGHTS_JSON
00070:     global IMPLEMENTATION_DRAFT_JSON
00071: 
00072:     TRACK_STEM = track_stem
00073:     MUSIC_AI_CONTEXT = Path(analysis_ai_context) if analysis_ai_context else OUTPUT_DIR / f"{TRACK_STEM}_analysis_ai_context.json"
00074:     DUAL_PLAN_JSON = OUTPUT_DIR / f"{TRACK_STEM}_dual_ai_scene_plan.json"
00075:     OLLAMA_INSIGHTS_JSON = OUTPUT_DIR / f"{TRACK_STEM}_ollama_music_insights.json"
00076:     IMPLEMENTATION_DRAFT_JSON = OUTPUT_DIR / f"{TRACK_STEM}_ai_implementation_draft.json"
00077: 
00078: 
00079: def apply_default_input_paths(args: argparse.Namespace) -> None:
00080:     if args.analysis is None:
00081:         args.analysis = str(OUTPUT_DIR / f"{args.track_stem}_analysis.json")
00082:     if args.track_summary is None:
00083:         args.track_summary = str(OUTPUT_DIR / f"{args.track_stem}_track_summary.json")
00084:     if args.compact_json is None:
00085:         args.compact_json = str(OUTPUT_DIR / f"{args.track_stem}_music_context.json")
00086:     if args.analysis_ai_context is None:
00087:         args.analysis_ai_context = str(OUTPUT_DIR / f"{args.track_stem}_analysis_ai_context.json")
00088:     if args.blender_keyframes_json is None:
00089:         args.blender_keyframes_json = str(OUTPUT_DIR / f"{args.track_stem}_analysis_blender_keyframes.json")
00090: 
00091: 
00092: def validate_input_files(args: argparse.Namespace) -> None:
00093:     required = [
00094:         ("analysis JSON", Path(args.analysis)),
00095:         ("track summary JSON", Path(args.track_summary)),
00096:         ("compact music context JSON", Path(args.compact_json)),
00097:         ("analysis AI context JSON", Path(args.analysis_ai_context)),
00098:         ("full Blender keyframes JSON", Path(args.blender_keyframes_json)),
00099:     ]
00100:     if args.phase == "implementation":
00101:         required.append(("dual AI scene plan JSON", DUAL_PLAN_JSON))
00102: 
00103:     missing = [f"{label}: {path}" for label, path in required if not path.exists()]
00104:     if missing:
00105:         raise FileNotFoundError(
00106:             "Prerequisiti mancanti per la pipeline AI:\n"
00107:             + "\n".join(f"- {item}" for item in missing)
00108:             + "\nEsegui/rigenera analysis, track summary, music context e piano prima del draft."
00109:         )
00110: 
00111: 
00112: def looks_degraded_text(text: str) -> bool:
00113:     stripped = text.strip()
00114:     if len(stripped) < 260:
00115:         return True
00116:     alnum = sum(ch.isalnum() for ch in stripped)
00117:     visible = sum(not ch.isspace() for ch in stripped)
00118:     if visible and alnum / visible < 0.45:
00119:         return True
00120:     markdown_heads = stripped.count("##")
00121:     useful_words = sum(
00122:         stripped.lower().count(word)
00123:         for word in ["audio", "blender", "segment", "material", "fog", "light", "mesh"]
00124:     )
00125:     return markdown_heads < 2 and useful_words < 5
00126: 
00127: 
00128: def deterministic_technical_notes(music_context: dict[str, Any], project_manifest: dict[str, Any], reason: str) -> str:
00129:     summary = music_context.get("analysis_summary") or {}
00130:     track_summary = music_context.get("track_summary") or {}
00131:     segments = music_context.get("segments") or []
00132:     files = project_manifest.get("files") or []
00133:     priority_files = [
00134:         item.get("file")
00135:         for item in files
00136:         if item.get("file", "").endswith((
00137:             "Scripting/v61b/config.py",
00138:             "Scripting/v61b/materials.py",
00139:             "Scripting/v61b/fog_dynamics.py",
00140:             "Scripting/v61b/physics_setup.py",
00141:             "Scripting/v61b/scene_tuning_panel.py",
00142:             "Tools/workflow/workflow_state.py",
00143:             "Tools/npu/run_dual_ai_pipeline.py",
00144:         ))
00145:     ]
00146: 
00147:     lines = [
00148:         "# Deterministic Technical Notes\n\n",
00149:         f"Reason: NPU output was not trusted (`{reason}`).\n\n",
00150:         "## Track Map\n",
00151:         f"- Duration: `{summary.get('duration_sec', track_summary.get('duration_sec', '?'))}` seconds.\n",
00152:         f"- FPS: `{summary.get('fps', track_summary.get('fps', '?'))}`.\n",
00153:         f"- BPM: `{summary.get('estimated_tempo_bpm', track_summary.get('estimated_tempo_bpm', '?'))}`.\n",
00154:         f"- Segment count: `{len(segments)}`.\n\n",
00155:         "## Project Primary Files\n",
00156:     ]
00157:     for file_name in priority_files[:20]:
00158:         lines.append(f"- `{file_name}`\n")
00159: 
00160:     lines.extend(
00161:         [
00162:             "\n## Safe Implementation Policy\n",
00163:             "- Use full frame-by-frame Blender keyframe JSON as data input only.\n",
00164:             "- Generate patch plans against existing project files, not monolithic replacement scripts.\n",
00165:             "- Prefer hotpatch/panel/update modules for materials, fog, lights and render changes.\n",
00166:             "- Require a reload only when primary object creation or scene topology changes.\n\n",
00167:             "## Audio Control Map\n",
00168:             "- Low band: hero mesh deformation scale, gravity/attractor strength, fog density body.\n",
00169:             "- Mid band: material roughness/emission mix, secondary object motion, fog filament drift.\n",
00170:             "- High band: small emission accents, glints, particle sparkle, sharp camera micro motion.\n",
00171:             "- Onset/beat: short impulses, never a constant global light flash.\n\n",
00172:         ]
00173:     )
00174:     return "".join(lines)
00175: 
00176: 
00177: def run_npu_technical_pass(args: argparse.Namespace) -> str:
00178:     script = TOOLS_DIR / "run_npu_review.py"
00179:     python_exe = Path(args.npu_python)
00180:     cmd = [
00181:         str(python_exe),
00182:         str(script),
00183:         "--engine",
00184:         "npu",
00185:         "--domain",
00186:         "music",
00187:         "--mode",
00188:         "chunked",
00189:         "--context",
00190:         str(TOOLS_DIR / "npu_music_context.md"),
00191:         "--chunk-dir",
00192:         str(TOOLS_DIR / "npu_music_chunks"),
00193:         "--out",
00194:         str(NPU_TECH_MD),
00195:         "--notes-out",
00196:         str(TOOLS_DIR / "npu_dual_ai_chunk_notes.md"),
00197:         "--max-context-chars",
00198:         "0",
00199:         "--chunk-chars",
00200:         "10500",
00201:         "--chunk-overlap-chars",
00202:         "700",
00203:         "--max-prompt-chars",
00204:         "15000",
00205:         "--max-chunk-tokens",
00206:         str(args.npu_chunk_tokens),
00207:         "--max-reduce-tokens",
00208:         str(args.npu_reduce_tokens),
00209:         "--max-new-tokens",
00210:         str(args.npu_final_tokens),
00211:         "--max-prompt-len",
00212:         "16384",
00213:         "--min-response-len",
00214:         "64",
00215:     ]
00216: 
```
