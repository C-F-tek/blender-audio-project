# Blender Manual Chunk 50

- Source: `C:\Users\carmi\blender\manual\blender_manual_html\blender_manual_vexp_it.html\modeling\modifiers\geometry_nodes.html`
- Manual group: `blender_manual_html`
- Score: `107`
- Part: `4`

## Content

Convert to Display Node 

Invert Color Node 

RGB to BW Node 

Creative Nodes 
Kuwahara Node 

Pixelate Node 

Posterize 

Sepia Node 

Split Toning Node 

Tune Image Node 

Unsharp Mask Node 

Filter Nodes 
Blur Filter Nodes 
Bilateral Blur Node 

Blur Node 

Bokeh Blur Node 

Defocus Node 

Directional Blur Node 

Vector Blur Node 

Anti-Aliasing Node 

Convolve Node 

Denoise Node 

Despeckle Node 

Dilate/Erode Node 

Mask To SDF Node 

Inpaint Node 

Filter Node 

Glare Node 

Keying Nodes 
Channel Key Node 

Chroma Key Node 

Color Key Node 

Color Spill Node 

Difference Key Node 

Distance Key Node 

Keying Node 

Keying Screen Node 

Luminance Key Node 

Mask Nodes 
Cryptomatte Node 

Cryptomatte Node (Legacy) 

Box Mask Node 

Ellipse Mask Node 

Double Edge Mask Node 

ID Mask Node 

Tracking Nodes 
Plane Track Deform Node 

Stabilize 2D Node 

Nodo Posizione Traccia 

Nodi Texture 
Brick Texture Node 

Checker Texture Node 

Gabor Texture Node 

Gradient Texture Node 

Magic Texture Node 

Noise Texture Node 

Voronoi Texture Node 

Wave Texture Node 

White Noise Texture Node 

Transform Nodes 
Rotate Node 

Scale Node 

Transform Node 

Translate Node 

Corner Pin Node 

Crop Node 

Displace Node 

Flip Node 

Map UV Node 

Lens Distortion Node 

Movie Distortion Node 

Utilities Nodes 
Math Nodes 
Clamp Node 

Float Curve 

Map Range Node 

Math Node 

Mix Node 

Vector Nodes 
Combine XYZ Node 

Separate XYZ Node 

Mix Vector Node 

Radial Tiling Node 

Vector Curves Node 

Vector Math Node 

Vector Rotate Node 

Combine Cylindrical Node 

Combine Spherical Node 

Separate Cylindrical Node 

Separate Spherical Node 

Matrix Utility Nodes 
Combine Matrix Node 

Invert Matrix Node 

Matrix Determinant Node 

Multiply Matrices Node 

Project Point Node 

Separate Matrix Node 

Transform Direction Node 

Transform Point Node 

Transpose Matrix Node 

Nodo Livelli 

Normalize Node 

Implicit Conversion 

Split Node 

Switch Node 

Index Switch Node 

Menu Switch Node 

Switch View Node 

Relative To Pixel Node 

Retime Node 

Camera & Lens Effects Nodes 
Chromatic Aberration Node 

Sensor Noise Node 

Vignette Node 

Gruppo 

Layout Nodes 

Motion Tracking & Masking 
Movie Clip Data-Blocks 

Tracciamento del Movimento 
Introduzione 

Clip View 
Introduzione 

Tracking Marker 

Barra degli strumenti 
Track 

Solve 

Selezione 

Modifica 
Ritaglia 

Track 

Reconstruction 

Sidebar 
Track 
Track 

Objects Panel 

Plane Track 

Telecamera 

Marker 

2D Stabilization 
Introduzione 

2D Stabilization Panel 

Flusso di Lavoro 

Vista 

Graph View 

Dope Sheet View 

Mascheramento 
Introduzione 

S-Curves 

Selezione 

Modifica 

Sidebar 

Video Editing 
Sequencer Scene 

Setting Your Project 
Video Editing App Template 

Directory Structure 

Editing Your Project 
Montage 
Strips 
Introduzione 

Strip Properties 

Scene Strip 

Clip Strip 

Mask Strip 

Movie Strip 

Sound Strip 

Image/Sequence Strip 

Color Strip 

Text Strip 

Adjustment Layer Strip 

Effect Strips 
Multicam Selector Strip 

Speed Control Strip 

Glow Strip 

Gaussian Blur Strip 

Add Strip 

Subtract Strip 

Multiply Strip 

Alpha Over & Alpha Under Strips 

Color Mix Strip 

Transitions 
Sound Crossfade 

Cross Strip 

Gamma Cross Strip 

Wipe Strip 

Strip Modifiers 

Selezione 

Modifica 

Meta Strips 

Storyboarding 
Storyboarding App Template 

Assets, Files, & Data System 
Introduzione 

Blender File 
Opening & Saving 

Compatibilità 

Packed Data 

Blend-Files Previews 

Rinomina 

Blocchi-Dati 

Custom Properties 

File Paths 

Linked Libraries 
Link & Append 

Library Overrides 

Asset Libraries 
Introduzione 

Asset Catalogs 

Media Formats 
Supported Graphics Formats 

Supported Video & Audio Formats 

Importing & Exporting Files 
Alembic 

Motion Capture (BVH) 

Universal Scene Description 

Wavefront OBJ 

Stanford PLY 

STL 

FBX 

FBX (Legacy) 

Scalable Vector Graphics (SVG) 

Import/Export SVG as Grease Pencil 

Export Grease Pencil as PDF 

Add-ons 
Node Wrangler 

Rigify 
Introduzione 

Basic Usage 

Bone Positioning Guide 

Generated Rig Features 

Creating Meta-rigs 

Rig Types 
Basic 

Spines 

Limbs 

Facce 

Skin 

Faccia 

Feature Sets 

glTF 2.0 

Manage UI Translations 

VR Scene Inspection 

Avanzate 
Using Blender From The Command Line 
Launching from the Command Line 
Linux 

macOS 

Windows 

Arguments 

Extensions Command Line Arguments 

Rendering From The Command Line 

Scripting & Extending Blender 
Introduzione 

Scripting & Security 

Add-on Tutorial 

Creating Extensions 
Getting started 

Compatible licenses 

Supported tags 

Version Number Guidelines 

Add-ons 

Python Wheels 

Creating a Repository 
Static Repository 

Dynamic Repository 

Application Templates 

Keymap Customization 

Working Limits 

Operators 

Blender’s Directory Layout 

Deploying Blender in Production 

Appendices 
Rotation Modes 

Risoluzione problemi 
Startup 

Vista 3D 

Graphics Hardware 
Windows 
NVIDIA 

AMD 

Intel 

Other GPU 

Linux 
NVIDIA 

AMD 

Intel 

Other GPU 

macOS 
NVIDIA 

AMD 

Intel 

Other GPU 

Crashes 

Network 

Python Errors 

Recovering Data 

Reporting a Bug 

Glossary 

Manual Index 

Partecipa 

Contribute Documentation 
Online Editing 

Local Editing 
Installing Dependencies 
Linux 

macOS 

Windows 

Building the Manual 

Editing the Manual 

Pull Requests 

Iniziare 

Guidelines 
Writing Style Guide 

Markup Style Guide 
Icons 

Commit Guidelines 

Templates 

Icons 

Maintenance 

Documentation Todo List 

Documenting New Features and Changes 

Translate Blender 

Translate the User Manual 
Contribute 

Style Guide 

Adding a Language 

5.2 Versioni 
Caricamento... 

Versioni Precedenti 

it Lingue 
Caricamento... 

Note 

Non stai usando la versione più recente della documentazione. è l'ultima versione. 
Back to top Edit this page 
Geometry Nodes Modifier ¶ 

The Geometry Nodes modifier creates a modifier with a node group which defines its functionality. 

A new Geometry Nodes modifier with a new node group. ¶ 

This modifier is supported by mesh, curve, text, and volume objects. 

Opzioni ¶ 

Node Group 

A Node Group with the geometry input and output.
Those are respectively what is received and passed to the previous and next modifier in the stack.
See Nodes for all available nodes. 

Ingressi 

A list of the node group’s inputs which can have unique values even
if the group is shared among multiple modifiers. 

If the input is connected to a Field socket,
there will be a toggle to switch between using a single value for the input or
using an attribute on the input geometry. Using an attribute for input means the
value can be different for every element. 

The attribute name used by default when using the node group in a modifier for the first
time is defined in the node group inputs panel . 

Nota 

The attribute domain and the data type used to access the attribute is defined by the
node the input is connected to. 

Warnings ¶ 

Nodes that show a warning message in the node editor will also show that message here. 

Custom warning messages can be created using the Warning Node . 

Output Attributes ¶ 

By connecting a field socket to the group output node,
you can create custom Attributes from a Field output of any node in the node tree.
The domain of the attribute must be specified in the group node’s output properties.
Note, this does not work with Instanced Data . 

The attribute name used by default when using the node group in a modifier for the first
time is defined in the node group outputs panel . 

This panel is hidden unless the output node has attribute sockets. 

Manage ¶ 

Displays options for managing data within the node group, 

The Manage panel can be hidden by disabling Show Manage Panel in the modifier’s header options.
This controls whether the panel is shown for that specific modifier. 

To disable the panel by default for new modifiers created from a node group asset,
toggle Show Manage Panel Geometry Nodes in the node group’s properties. 
Bake ¶ 
Bake Target 

Specifies where baked data should be stored. This can be overridden for individual bakes. 

Packed : 

The baked data is packed into the .blend file. So no separate file is necessary. 

Disk : 

The baked data is stored in a separate directory on disk. 

Bake Path 

Location on disk where the baked data for Simulation Zones and Bake Nodes are stored. 

Vedi anche 

Geometry Node Baking 
Named Attributes ¶ 
This panel displays information about all custom named attributes used by the node group.
More information is available in the geometry nodes inspection page . 

Move to Nodes Operator ¶ 

Creates a new geometry node tree with the name of the current node tree with 
.wrapper appended to the name.
This operation moves all inputs and outputs from the old modifier into a new node group.
In order for this operator to function, there must be a Group Input and a Group Output
each with a Geometry socket attached to the node group.
This action causes all Output Attributes to become Internal Dependencies utilizing the Store Named Attribute Node .
All modifier «inputs» will then also become inputs of the newly created node group. 

This operator is useful to easily allow a node tree to be reused in other trees
or to mark it as an Asset to be reused in other projects. 
Next Geometry Nodes Previous Soft Body Modifier Copyright © : This page is licensed under a CC-BY-SA 4.0 Int. License Made with Furo Last updated on 2026-04-25 
Visualizza Fonte 

Visualizza Traduzione 

Segnala il problema in questa pagina 
On this page 
Geometry Nodes Modifier 
Opzioni 
Warnings 

Output Attributes 

Manage 
Bake 

Named Attributes 

Move to Nodes Operator
