# Blender Manual Chunk 32

- Source: `C:\Users\carmi\blender\manual\blender_manual_html\blender_manual_vexp_it.html\animation\drivers\drivers_panel.html`
- Manual group: `blender_manual_html`
- Score: `108`
- Part: `4`

## Content

Convert to Display Node 

Invert Color Node 

RGB to BW Node 

Creative Nodes 
Kuwahara Node 

Pixelate Node 

Posterize 

Sepia Node 

Split Toning Node 

Tune Image Node 

Unsharp Mask Node 

Filter Nodes 
Blur Filter Nodes 
Bilateral Blur Node 

Blur Node 

Bokeh Blur Node 

Defocus Node 

Directional Blur Node 

Vector Blur Node 

Anti-Aliasing Node 

Convolve Node 

Denoise Node 

Despeckle Node 

Dilate/Erode Node 

Mask To SDF Node 

Inpaint Node 

Filter Node 

Glare Node 

Keying Nodes 
Channel Key Node 

Chroma Key Node 

Color Key Node 

Color Spill Node 

Difference Key Node 

Distance Key Node 

Keying Node 

Keying Screen Node 

Luminance Key Node 

Mask Nodes 
Cryptomatte Node 

Cryptomatte Node (Legacy) 

Box Mask Node 

Ellipse Mask Node 

Double Edge Mask Node 

ID Mask Node 

Tracking Nodes 
Plane Track Deform Node 

Stabilize 2D Node 

Nodo Posizione Traccia 

Nodi Texture 
Brick Texture Node 

Checker Texture Node 

Gabor Texture Node 

Gradient Texture Node 

Magic Texture Node 

Noise Texture Node 

Voronoi Texture Node 

Wave Texture Node 

White Noise Texture Node 

Transform Nodes 
Rotate Node 

Scale Node 

Transform Node 

Translate Node 

Corner Pin Node 

Crop Node 

Displace Node 

Flip Node 

Map UV Node 

Lens Distortion Node 

Movie Distortion Node 

Utilities Nodes 
Math Nodes 
Clamp Node 

Float Curve 

Map Range Node 

Math Node 

Mix Node 

Vector Nodes 
Combine XYZ Node 

Separate XYZ Node 

Mix Vector Node 

Radial Tiling Node 

Vector Curves Node 

Vector Math Node 

Vector Rotate Node 

Combine Cylindrical Node 

Combine Spherical Node 

Separate Cylindrical Node 

Separate Spherical Node 

Matrix Utility Nodes 
Combine Matrix Node 

Invert Matrix Node 

Matrix Determinant Node 

Multiply Matrices Node 

Project Point Node 

Separate Matrix Node 

Transform Direction Node 

Transform Point Node 

Transpose Matrix Node 

Nodo Livelli 

Normalize Node 

Implicit Conversion 

Split Node 

Switch Node 

Index Switch Node 

Menu Switch Node 

Switch View Node 

Relative To Pixel Node 

Retime Node 

Camera & Lens Effects Nodes 
Chromatic Aberration Node 

Sensor Noise Node 

Vignette Node 

Gruppo 

Layout Nodes 

Motion Tracking & Masking 
Movie Clip Data-Blocks 

Tracciamento del Movimento 
Introduzione 

Clip View 
Introduzione 

Tracking Marker 

Barra degli strumenti 
Track 

Solve 

Selezione 

Modifica 
Ritaglia 

Track 

Reconstruction 

Sidebar 
Track 
Track 

Objects Panel 

Plane Track 

Telecamera 

Marker 

2D Stabilization 
Introduzione 

2D Stabilization Panel 

Flusso di Lavoro 

Vista 

Graph View 

Dope Sheet View 

Mascheramento 
Introduzione 

S-Curves 

Selezione 

Modifica 

Sidebar 

Video Editing 
Sequencer Scene 

Setting Your Project 
Video Editing App Template 

Directory Structure 

Editing Your Project 
Montage 
Strips 
Introduzione 

Strip Properties 

Scene Strip 

Clip Strip 

Mask Strip 

Movie Strip 

Sound Strip 

Image/Sequence Strip 

Color Strip 

Text Strip 

Adjustment Layer Strip 

Effect Strips 
Multicam Selector Strip 

Speed Control Strip 

Glow Strip 

Gaussian Blur Strip 

Add Strip 

Subtract Strip 

Multiply Strip 

Alpha Over & Alpha Under Strips 

Color Mix Strip 

Transitions 
Sound Crossfade 

Cross Strip 

Gamma Cross Strip 

Wipe Strip 

Strip Modifiers 

Selezione 

Modifica 

Meta Strips 

Storyboarding 
Storyboarding App Template 

Assets, Files, & Data System 
Introduzione 

Blender File 
Opening & Saving 

Compatibilità 

Packed Data 

Blend-Files Previews 

Rinomina 

Blocchi-Dati 

Custom Properties 

File Paths 

Linked Libraries 
Link & Append 

Library Overrides 

Asset Libraries 
Introduzione 

Asset Catalogs 

Media Formats 
Supported Graphics Formats 

Supported Video & Audio Formats 

Importing & Exporting Files 
Alembic 

Motion Capture (BVH) 

Universal Scene Description 

Wavefront OBJ 

Stanford PLY 

STL 

FBX 

FBX (Legacy) 

Scalable Vector Graphics (SVG) 

Import/Export SVG as Grease Pencil 

Export Grease Pencil as PDF 

Add-ons 
Node Wrangler 

Rigify 
Introduzione 

Basic Usage 

Bone Positioning Guide 

Generated Rig Features 

Creating Meta-rigs 

Rig Types 
Basic 

Spines 

Limbs 

Facce 

Skin 

Faccia 

Feature Sets 

glTF 2.0 

Manage UI Translations 

VR Scene Inspection 

Avanzate 
Using Blender From The Command Line 
Launching from the Command Line 
Linux 

macOS 

Windows 

Arguments 

Extensions Command Line Arguments 

Rendering From The Command Line 

Scripting & Extending Blender 
Introduzione 

Scripting & Security 

Add-on Tutorial 

Creating Extensions 
Getting started 

Compatible licenses 

Supported tags 

Version Number Guidelines 

Add-ons 

Python Wheels 

Creating a Repository 
Static Repository 

Dynamic Repository 

Application Templates 

Keymap Customization 

Working Limits 

Operators 

Blender’s Directory Layout 

Deploying Blender in Production 

Appendices 
Rotation Modes 

Risoluzione problemi 
Startup 

Vista 3D 

Graphics Hardware 
Windows 
NVIDIA 

AMD 

Intel 

Other GPU 

Linux 
NVIDIA 

AMD 

Intel 

Other GPU 

macOS 
NVIDIA 

AMD 

Intel 

Other GPU 

Crashes 

Network 

Python Errors 

Recovering Data 

Reporting a Bug 

Glossary 

Manual Index 

Partecipa 

Contribute Documentation 
Online Editing 

Local Editing 
Installing Dependencies 
Linux 

macOS 

Windows 

Building the Manual 

Editing the Manual 

Pull Requests 

Iniziare 

Guidelines 
Writing Style Guide 

Markup Style Guide 
Icons 

Commit Guidelines 

Templates 

Icons 

Maintenance 

Documentation Todo List 

Documenting New Features and Changes 

Translate Blender 

Translate the User Manual 
Contribute 

Style Guide 

Adding a Language 

5.2 Versioni 
Caricamento... 

Versioni Precedenti 

it Lingue 
Caricamento... 

Note 

Non stai usando la versione più recente della documentazione. è l'ultima versione. 
Back to top Edit this page 
Drivers Panel ¶ 

Edit Driver popover. ¶ 

Riferimento 

Editor : 

Graph editor 

Modalità : 

Guide (driver) 

Pannello : 

Sidebar region ‣ Drivers 

Scorciatoia : 

N 

Riferimento 

Menù : 

Context menu ‣ Edit Driver 

Scorciatoia : 

Ctrl - D 

This panel is visible in Sidebar of the Drivers Editor or as a popover when adding a driver to a property. 

It shows the property that is being driven, followed by a series of settings
that determine how the driver works. 

Driver Settings ¶ 

Tipo ¶ 

There are two categories of drivers: 

Built-in functions ( Average , Sum , Min and Max ) 

The driven property will have the value of the average, sum, lowest or highest (respectively)
of the values of the referenced Driver Variables .
If there is only one driver variable, these functions will yield the same result. 

Custom ( Scripted Expression ). 

An arbitrary Python expression that can refer to the Driver Variables by name. See Expressions . 

Driver Value ¶ 

The current result of the driver setup. Useful for debug purposes. 

Variables ¶ 

See Driver Variables . 

Update Dependencies ¶ 

Forces an update for the Driver Value dependencies. 

Show in Drivers Editor ¶ 

Opens the fully featured Drivers Editor .
This button only appears in the popover version of the Drivers panel. 

Driver Variables ¶ 

Variables are references to properties, transformation channels, or the result of a comparison
between transformations of two objects. 

Drivers should access object data via Driver Variables , rather than direct references in the Python expression,
in order for dependencies to be correctly tracked. 

Add, Copy, Paste buttons. ¶ 

Add Input Variable 

Adds a new Driver Variable. 

Copy/Paste Variables 

Copies the current variable list so it can be pasted into another driver’s variable list. 

Nome 

Name for use in scripted expressions.
The name must start with a letter, and only contain letters, digits, or underscores. 

Variable Type 

The type of variable to use. 

Single Property 

Retrieves the value of an RNA property, specified by a data-block reference and a path string. 

In case of transform properties, this will return the exact value of the UI property,
while Transform Channel will take parenting and/or constraints into account as needed. 

See also Custom Properties . 

ID Type 

The ID-block type. For example: Key, Image, Object, Material. 

ID 

The ID of the ID-block type. For example: «Material.001». 

RNA Path 

The RNA name of the property, based on a subset of Python attribute access syntax.
For example: 
location.x or 
location[0] for the X location animation channel
value (before parenting or constraints), or 
["prop_name"] for a custom property. 

Fallback 

If enabled, allows specifying a fallback value to use as the variable value if the RNA Path cannot
be resolved, instead of causing a driver evaluation failure. For more info see Context Property below. 

Suggerimento 

The easiest way to create a variable of this type is to use
the Copy As New Driver context menu option of the input property, and paste the result
into the driver via Paste Driver Variables . 

Transform Channel 

Retrieves the value of a Transform channel from an object or bone. 

ID 

ID of the object. For example: Cube, Armature, Camera. 

Osso 

For armatures, the name of the Armature bone. For example: «Bone», «Bone.002», «Arm.r». 

Tipo 

For example, X Location, X Rotation, X Scale. 

The Average Scale option retrieves the combined scale value,
computed as the cubic root of the total change in volume.
Unlike X/Y/Z Scale , this value can be negative if the object is flipped by negative scaling. 

Mode (Rotation) 

For rotation channels, specifies the type of rotation data to use, including
different explicit Euler orders. Defaults to using the Euler order of
the target. See Rotation Channel Modes . 

Space 

World Space, Transform Space, Local Space. 

Rotational Difference 

Provides the value of the rotational difference between two objects or bones, in radians. 

Osso 

For armatures, the name of the Armature bone. For example: «Bone», «Bone.002», «Arm.r». 

Distance 

Provides the value of the distance between two objects or bones. 

Osso 

For armatures, the name of the Armature bone. For example: «Bone», «Bone.002», «Arm.r». 

Space 

World Space, Transform Space, Local Space. 

Context Property 

Provides the value of a property that is implicitly referring to either a scene
or a view layer of the currently evaluating animation system.
This is a weak reference which does not lead to the scene or view layer
referenced from the driver to be linked when linking animation data. 

An example when such properties comes in play is referring to a transformation
of the active camera. It is possible to set up a driver in a character file,
and make the driver use the set camera when the character is linked into a set. 

Context 

Active Scene, Active View Layer. 

RNA Path 

The RNA name of the property, based on a subset of Python attribute access syntax.
For example: 
camera.location.x or
