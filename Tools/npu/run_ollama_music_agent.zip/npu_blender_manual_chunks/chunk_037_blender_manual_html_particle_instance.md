# Blender Manual Chunk 37

- Source: `C:\Users\carmi\blender\manual\blender_manual_html\blender_manual_vexp_it.html\modeling\modifiers\physics\particle_instance.html`
- Manual group: `blender_manual_html`
- Score: `108`
- Part: `4`

## Content

Convert to Display Node 

Invert Color Node 

RGB to BW Node 

Creative Nodes 
Kuwahara Node 

Pixelate Node 

Posterize 

Sepia Node 

Split Toning Node 

Tune Image Node 

Unsharp Mask Node 

Filter Nodes 
Blur Filter Nodes 
Bilateral Blur Node 

Blur Node 

Bokeh Blur Node 

Defocus Node 

Directional Blur Node 

Vector Blur Node 

Anti-Aliasing Node 

Convolve Node 

Denoise Node 

Despeckle Node 

Dilate/Erode Node 

Mask To SDF Node 

Inpaint Node 

Filter Node 

Glare Node 

Keying Nodes 
Channel Key Node 

Chroma Key Node 

Color Key Node 

Color Spill Node 

Difference Key Node 

Distance Key Node 

Keying Node 

Keying Screen Node 

Luminance Key Node 

Mask Nodes 
Cryptomatte Node 

Cryptomatte Node (Legacy) 

Box Mask Node 

Ellipse Mask Node 

Double Edge Mask Node 

ID Mask Node 

Tracking Nodes 
Plane Track Deform Node 

Stabilize 2D Node 

Nodo Posizione Traccia 

Nodi Texture 
Brick Texture Node 

Checker Texture Node 

Gabor Texture Node 

Gradient Texture Node 

Magic Texture Node 

Noise Texture Node 

Voronoi Texture Node 

Wave Texture Node 

White Noise Texture Node 

Transform Nodes 
Rotate Node 

Scale Node 

Transform Node 

Translate Node 

Corner Pin Node 

Crop Node 

Displace Node 

Flip Node 

Map UV Node 

Lens Distortion Node 

Movie Distortion Node 

Utilities Nodes 
Math Nodes 
Clamp Node 

Float Curve 

Map Range Node 

Math Node 

Mix Node 

Vector Nodes 
Combine XYZ Node 

Separate XYZ Node 

Mix Vector Node 

Radial Tiling Node 

Vector Curves Node 

Vector Math Node 

Vector Rotate Node 

Combine Cylindrical Node 

Combine Spherical Node 

Separate Cylindrical Node 

Separate Spherical Node 

Matrix Utility Nodes 
Combine Matrix Node 

Invert Matrix Node 

Matrix Determinant Node 

Multiply Matrices Node 

Project Point Node 

Separate Matrix Node 

Transform Direction Node 

Transform Point Node 

Transpose Matrix Node 

Nodo Livelli 

Normalize Node 

Implicit Conversion 

Split Node 

Switch Node 

Index Switch Node 

Menu Switch Node 

Switch View Node 

Relative To Pixel Node 

Retime Node 

Camera & Lens Effects Nodes 
Chromatic Aberration Node 

Sensor Noise Node 

Vignette Node 

Gruppo 

Layout Nodes 

Motion Tracking & Masking 
Movie Clip Data-Blocks 

Tracciamento del Movimento 
Introduzione 

Clip View 
Introduzione 

Tracking Marker 

Barra degli strumenti 
Track 

Solve 

Selezione 

Modifica 
Ritaglia 

Track 

Reconstruction 

Sidebar 
Track 
Track 

Objects Panel 

Plane Track 

Telecamera 

Marker 

2D Stabilization 
Introduzione 

2D Stabilization Panel 

Flusso di Lavoro 

Vista 

Graph View 

Dope Sheet View 

Mascheramento 
Introduzione 

S-Curves 

Selezione 

Modifica 

Sidebar 

Video Editing 
Sequencer Scene 

Setting Your Project 
Video Editing App Template 

Directory Structure 

Editing Your Project 
Montage 
Strips 
Introduzione 

Strip Properties 

Scene Strip 

Clip Strip 

Mask Strip 

Movie Strip 

Sound Strip 

Image/Sequence Strip 

Color Strip 

Text Strip 

Adjustment Layer Strip 

Effect Strips 
Multicam Selector Strip 

Speed Control Strip 

Glow Strip 

Gaussian Blur Strip 

Add Strip 

Subtract Strip 

Multiply Strip 

Alpha Over & Alpha Under Strips 

Color Mix Strip 

Transitions 
Sound Crossfade 

Cross Strip 

Gamma Cross Strip 

Wipe Strip 

Strip Modifiers 

Selezione 

Modifica 

Meta Strips 

Storyboarding 
Storyboarding App Template 

Assets, Files, & Data System 
Introduzione 

Blender File 
Opening & Saving 

Compatibilità 

Packed Data 

Blend-Files Previews 

Rinomina 

Blocchi-Dati 

Custom Properties 

File Paths 

Linked Libraries 
Link & Append 

Library Overrides 

Asset Libraries 
Introduzione 

Asset Catalogs 

Media Formats 
Supported Graphics Formats 

Supported Video & Audio Formats 

Importing & Exporting Files 
Alembic 

Motion Capture (BVH) 

Universal Scene Description 

Wavefront OBJ 

Stanford PLY 

STL 

FBX 

FBX (Legacy) 

Scalable Vector Graphics (SVG) 

Import/Export SVG as Grease Pencil 

Export Grease Pencil as PDF 

Add-ons 
Node Wrangler 

Rigify 
Introduzione 

Basic Usage 

Bone Positioning Guide 

Generated Rig Features 

Creating Meta-rigs 

Rig Types 
Basic 

Spines 

Limbs 

Facce 

Skin 

Faccia 

Feature Sets 

glTF 2.0 

Manage UI Translations 

VR Scene Inspection 

Avanzate 
Using Blender From The Command Line 
Launching from the Command Line 
Linux 

macOS 

Windows 

Arguments 

Extensions Command Line Arguments 

Rendering From The Command Line 

Scripting & Extending Blender 
Introduzione 

Scripting & Security 

Add-on Tutorial 

Creating Extensions 
Getting started 

Compatible licenses 

Supported tags 

Version Number Guidelines 

Add-ons 

Python Wheels 

Creating a Repository 
Static Repository 

Dynamic Repository 

Application Templates 

Keymap Customization 

Working Limits 

Operators 

Blender’s Directory Layout 

Deploying Blender in Production 

Appendices 
Rotation Modes 

Risoluzione problemi 
Startup 

Vista 3D 

Graphics Hardware 
Windows 
NVIDIA 

AMD 

Intel 

Other GPU 

Linux 
NVIDIA 

AMD 

Intel 

Other GPU 

macOS 
NVIDIA 

AMD 

Intel 

Other GPU 

Crashes 

Network 

Python Errors 

Recovering Data 

Reporting a Bug 

Glossary 

Manual Index 

Partecipa 

Contribute Documentation 
Online Editing 

Local Editing 
Installing Dependencies 
Linux 

macOS 

Windows 

Building the Manual 

Editing the Manual 

Pull Requests 

Iniziare 

Guidelines 
Writing Style Guide 

Markup Style Guide 
Icons 

Commit Guidelines 

Templates 

Icons 

Maintenance 

Documentation Todo List 

Documenting New Features and Changes 

Translate Blender 

Translate the User Manual 
Contribute 

Style Guide 

Adding a Language 

5.2 Versioni 
Caricamento... 

Versioni Precedenti 

it Lingue 
Caricamento... 

Note 

Non stai usando la versione più recente della documentazione. è l'ultima versione. 
Back to top Edit this page 
Particle Instance Modifier ¶ 

When a Particle Instance modifier is added to an object,
the mesh of this object will be duplicated
at the location of the particles of the selected particle system from another target object.
This means that to use this modifier, you must have at least one other object
that has a Particle System on it. 

Because of the correlation in which the Particle Instance modifier is
influenced by the underlying particle systems on other objects, some of the apparent effects
generated by the modifier can look and act vastly different,
depending on the underlying settings of the particle systems it is associated with.
This is worth taking account of, when it seems that the Particle Instance modifier settings
do not return the expected results. 

Opzioni ¶ 

The Particle Instance modifier. ¶ 

Oggetto 

The target object which has a particle system associated with it. 

Particle System 

Which particle system from the target Object to apply this modifier to. 

Create Instances 

Regular 

When enabled, the modifier will use the regular (parents) particles
to duplicate the mesh of the modified object. 

Children 

When enabled, the modifier will use the children particles
to duplicate the mesh of the modified object. 

Dimensione 

Scale the instanced copies of the mesh by the particle size attribute.
When this is disabled, all the copies appear the same size as the origin. 

See the particle system’s Render and Children panels for particle’s size options. 

Mostra 

Unborn 

When enabled, the modifier will use the unborn particles
to duplicate the mesh of the modified object. 

Alive 

When enabled, the modifier will use the alive particles
to duplicate the mesh of the modified object. 

Dead 

When enabled, the modifier will use the dead particles
to duplicate the mesh of the modified object. 

Amount 

The proportion of particles to be used.
Allows you to randomly skip particles to adjust the amount of instances. 

Avvertimento 

The random algorithm used currently only ensures that relative amount to be respected statistically .
The actual amount of instances generated will differ from the theoretical one,
depending on the Seed value of the target particle system (and the Offset value described below, too). 

That deviation is not significant with high number of particles,
but it will be highly noticeable with low numbers
(e.g. with 100 particles in the target system, and an Amount value of 
0.1 ,
it can generate either up to 15 or 5 instances, instead of the 10 expected). 

Scostamento 

A relative offset in the range of particles used for instantiation.
Allows you to avoid overlapping of the used particles,
when the same particle system is used in multiple modifier instances. 

Suggerimento 

If you want to fully avoid overlaps, your Offset value must be at least as high as your Amount value. 

Coordinate Space 

World, Local 

Use World Space , or Local Space of the target object (that the particle system is assigned to). 

World space means that the locations of the copies of the modified mesh will depend
on the location of the modified object and of the target object. 

Local space means that the locations of the copies of the modified mesh will depend
only on the location of the modified object. 

Asse 

Specify which axis of the modified object to use as pole axis to apply
the rotation from the instantiated particles. 

Create Along Paths ¶ 

By default, the instances are placed depending on the particles position in the current frame.
By enabling Create Along Paths , the instance of the modified object follows and
deforms its shape along the particle path (or the hair strand).
This allows you to select the position along the particles path regardless of the current frame. 

Suggerimento 

You can adjust the particles” path (using the Path visualization type)
on the Render panel of the Particle System tab. 

Nota 

The particle system must be baked , except for Hair type or Keyed physics. 

Posizione 

Specify what percentage of the path that the instance fills,
or the position on the path if the Keep Shape option is enabled. 

Casuale 

Adds randomness to the Position value of each instance. 

Rotazione 

Specifies the rotation around the path. 

Casuale 

Adds randomness to the Rotation value of each instance. 

Keep Shape 

Enabling this prevents the instance from being deformed,
and places it on the path according to the Position value. 

Livelli ¶ 

With these fields you can select the Color Attribute,
which will be filled with colors based on the particles information.
These Color Attributes can be used, for example, in a shader to add variance to a material. 

Index 

A Color Attribute for values based on the particles index. 

Valore 

A Color Attribute for random per-particle values. 

Nota 

Index and Value attributes must be in face corner domain and use byte color data type. 

Esempi ¶ 

Particle Instance modifier example. ¶ 

The render above shows a single plane mesh object assigned to two different vertex groups
