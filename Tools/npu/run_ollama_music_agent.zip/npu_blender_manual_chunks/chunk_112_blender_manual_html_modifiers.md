# Blender Manual Chunk 112

- Source: `C:\Users\carmi\blender\manual\blender_manual_html\blender_manual_vexp_it.html\editors\graph_editor\fcurves\modifiers.html`
- Manual group: `blender_manual_html`
- Score: `105`
- Part: `5`

## Content

Phase 

Adjusts the random seed of the noise. 

Depth 

Adjusts how detailed the noise function is. 

Lacunarity 

Gap between successive frequencies. Depth has to be greater than 0 for this to have an effect. 

Roughness 

The amount of high frequency detail. Depth has to be greater than 0 for this to have an effect. 

Limits Modifier ¶ 

Limits the curve to specific time and value ranges. 

Minimum, Maximum X 

Removes the original curve data to the left of the minimum frame and to the right of the maximum,
replacing it by Constant extrapolation . 

Minimum, Maximum Y 

Clamps the curve values, never letting them go below the minimum or above the maximum. 

Stepped Interpolation Modifier ¶ 

Gives the curve a stepped appearance by sampling it every N frames and making it hold its value
after each sample. In a sense, this lowers the curve’s frame rate by letting it change its value
less frequently, producing choppy movement as a result. 

Step Size 

The number of frames to hold each step. 

Scostamento 

The number of frames to offset the sample points. 

Start Frame 

The frame where to start applying the effect. 

End Frame 

The frame where to stop applying the effect. 

Smooth (Gaussian) Modifier ¶ 

Uses Gaussian smoothing to reduce detail and noise in the curve.
It performs the same smoothing as the Smoothing Operator . 

This uses linear interpolation for subframes which can introduce issues related to motion blur. 

Note that this can be a resource-heavy modifier, and its effect on performance can become noticeable
when used on many F-Curves. 

Nota 

The Smooth (Gaussian) modifier has to be the first modifier in the list. 

This modifier needs to know exactly where the keyframes are located,
which is not possible when other modifiers are processed first.
This means this modifier is not compatible with the Cycles Modifier . 

Sigma 

The shape of the Gaussian distribution in frames.
Lower values will increase sharpness, reducing the smoothing effect.
Larger values will result in more smoothing, but are limited by the Filter Width (see below). 

Filter Width 

The number of frames the filter «sees» around each keyframe.
Higher values allow more smoothing (larger Sigma can then smooth over more frames),
but this will decrease performance. 

Next Drivers Editor Previous F-Curve Properties Copyright © : This page is licensed under a CC-BY-SA 4.0 Int. License Made with Furo Last updated on 2026-04-25 
Visualizza Fonte 

Visualizza Traduzione 

Segnala il problema in questa pagina 
On this page 
F-Curve Modifiers 
Interfaccia 

Adding a Modifier 

Types of Modifiers 
Generator Modifier 

Built-in Function Modifier 

Envelope Modifier 

Cycles Modifier 
Trivially Cyclic Curves 

Noise Modifier 

Limits Modifier 

Stepped Interpolation Modifier 

Smooth (Gaussian) Modifier
