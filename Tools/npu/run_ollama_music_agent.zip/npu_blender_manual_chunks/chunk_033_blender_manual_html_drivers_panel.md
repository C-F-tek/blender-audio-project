# Blender Manual Chunk 33

- Source: `C:\Users\carmi\blender\manual\blender_manual_html\blender_manual_vexp_it.html\animation\drivers\drivers_panel.html`
- Manual group: `blender_manual_html`
- Score: `108`
- Part: `5`

## Content

camera.location[0] for the camera X location animation
channel value (before parenting or constraints), or 
["prop_name"] for a custom property. 

Fallback 

If enabled, allows specifying a fallback value to use as the variable value if the RNA Path cannot
be resolved, instead of causing a driver evaluation failure. 

This feature can be very useful for making drivers more robust when implementing scene-global options
using custom properties. When the object is linked into a different scene, these custom properties may
not exist there, and the fallbacks can be used to provide sensible default values. 

Fallbacks can also be used to emulate the lookup behavior of the View Layer mode of the material Attribute Node . 

Suggerimento 

Although the values of the x/y/z animation channels for the camera location can be accessed
via 
camera.location[0/1/2] , retrieving its world space location and orientation after parenting
and constraints currently requires using 
camera.matrix_world . This property can be understood
easily by viewing the matrix as an array of four vectors in World space: 

matrix_world[0][0/1/2] is the Screen Right direction vector (camera local X). 

matrix_world[1][0/1/2] is the Screen Up direction vector (camera local Y). 

matrix_world[2][0/1/2] is the opposite of the direction the camera is pointing. 

matrix_world[3][0/1/2] is the location of the camera. 

Valore 

Shows the value of the variable. 

Rotation Channel Modes ¶ 

Rotation Transform Channels support a number of operation modes, including: 

Auto Euler 

Uses the Euler order of the target to decompose rotation into channels. 

XYZ Euler, … 

Explicitly specifies the Euler rotation order to use. 

Quaternion 

Provides the Quaternion representation of the rotation. 

Swing and X/Y/Z Twist 

Decomposes the rotation into two parts: a Swing rotation that aims the specified
axis in its final direction, followed by a Twist rotation around that axis.
This is often necessary for driving corrective Shape Keys and bones for organic joint rotation. 

This decomposition is often produced in rigs by using a helper bone with
a Damped Track Constraint to extract the swing part, and its child with Copy Transforms to extract the twist component. 

The channels values for Swing and Y Twist are: 

Falloff curves for weighted angles. ¶ 

Y Rotation 

True angle of the twist rotation. 

W Rotation 

True angle of the swing rotation, independent of its direction. 

X Rotation, Z Rotation 

Weighted angles that represent the amount of swing around the X/Z axis. 

The magnitude of the angle equals W Rotation when the rotation is purely around
that axis, and fades out to zero as the direction changes toward the other axis,
following the falloff curves from the graph on the right. 

Mathematically, the swing angles are computed from quaternion components,
using \(2 \arccos(w)\) for W and \(2 \arcsin(x)\) etc. for the others.
The component of the swing rotation that corresponds to the twist axis is always 0,
and is replaced by the twist angle. 

Espressioni ¶ 

Expression 

A text field where you can enter an arbitrary Python expression that refers to Driver Variables by their names. 

The expression has access to a set of standard constants and math functions from 
math , 
bl_math and other modules, provided in the Driver Namespace . For an example of adding
a custom function to the namespace, see the driver namespace example . 

For performance reasons it is best to use the Simple Expressions subset as much as possible. 

Use Self 

If this option is enabled, the variable 
self can be used for drivers to reference their own data.
Useful for objects and bones to avoid having to create a Driver Variable pointing to itself. 

Example: 
self.location.x applied to the Y rotation property of the same object
will make the object tumble when moving. 

Note that dependencies for properties accessed via 
self may not be fully tracked. 

Simple Expressions ¶ 

Blender can evaluate a useful subset of Python driver expressions directly,
which significantly improves performance, especially on multi-core systems.
To take advantage of this, the driver expression must only use the following features: 

Variable Names 

Use only ASCII characters. 

Literals 

Floating-point and decimal integer. 

Globals 

frame 

Constants 

pi , 
True , 
False 

Operators 

+ , 
- , 
* , 
/ , 
== , 
!= , 
< , 
<= , 
> , 
>= , 
and , 
or , 
not , conditional operator/ ternary if 

Standard Functions 

min , 
max , 
radians , 
degrees , 
abs , 
fabs , 
floor , 
ceil , 
trunc , 
round , 
int , 
sin , 
cos , 
tan , 
asin , 
acos , 
atan , 
atan2 , 
exp , 
log , 
sqrt , 
pow , 
fmod 

Blender Provided Functions 

lerp , 
clamp , 
smoothstep 

Simple expressions are evaluated even when Python script execution is disabled. 

When an expression outside of this subset is used, Blender displays a «Slow Python expression»
warning. However, as long as the majority of drivers use simple expressions, using a complex
expression in select few is OK. 

Vedi anche 

Extending Blender with Python . 

Python and its documentation . 

functions.wolfram.com . 

Next Workflow & Examples Previous Uso Copyright © : This page is licensed under a CC-BY-SA 4.0 Int. License Made with Furo Last updated on 2026-04-25 
Visualizza Fonte 

Visualizza Traduzione 

Segnala il problema in questa pagina 
On this page 
Drivers Panel 
Driver Settings 
Tipo 

Driver Value 

Variables 

Update Dependencies 

Show in Drivers Editor 

Driver Variables 
Rotation Channel Modes 

Espressioni 
Simple Expressions
