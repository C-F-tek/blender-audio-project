# Blender Manual Chunk 188

- Source: `C:\Users\carmi\blender\manual\blender_manual_html\blender_manual_vexp_it.html\animation\keyframes\introduction.html`
- Manual group: `blender_manual_html`
- Score: `104`
- Part: `5`

## Content

Next Editing Keyframes Previous Fotogrammi Chiave (keyframes) Copyright © : This page is licensed under a CC-BY-SA 4.0 Int. License Made with Furo Last updated on 2026-04-25 
Visualizza Fonte 

Visualizza Traduzione 

Segnala il problema in questa pagina 
On this page 
Introduzione 
Visualization 

Interpolation 

Keyframe Types 

Handles & Interpolation Mode Display
