# Blender Manual Chunk 78

- Source: `C:\Users\carmi\blender\manual\blender_manual_html\blender_manual_vexp_it.html\animation\drivers\workflow_examples.html`
- Manual group: `blender_manual_html`
- Score: `106`
- Part: `4`

## Content

Convert to Display Node 

Invert Color Node 

RGB to BW Node 

Creative Nodes 
Kuwahara Node 

Pixelate Node 

Posterize 

Sepia Node 

Split Toning Node 

Tune Image Node 

Unsharp Mask Node 

Filter Nodes 
Blur Filter Nodes 
Bilateral Blur Node 

Blur Node 

Bokeh Blur Node 

Defocus Node 

Directional Blur Node 

Vector Blur Node 

Anti-Aliasing Node 

Convolve Node 

Denoise Node 

Despeckle Node 

Dilate/Erode Node 

Mask To SDF Node 

Inpaint Node 

Filter Node 

Glare Node 

Keying Nodes 
Channel Key Node 

Chroma Key Node 

Color Key Node 

Color Spill Node 

Difference Key Node 

Distance Key Node 

Keying Node 

Keying Screen Node 

Luminance Key Node 

Mask Nodes 
Cryptomatte Node 

Cryptomatte Node (Legacy) 

Box Mask Node 

Ellipse Mask Node 

Double Edge Mask Node 

ID Mask Node 

Tracking Nodes 
Plane Track Deform Node 

Stabilize 2D Node 

Nodo Posizione Traccia 

Nodi Texture 
Brick Texture Node 

Checker Texture Node 

Gabor Texture Node 

Gradient Texture Node 

Magic Texture Node 

Noise Texture Node 

Voronoi Texture Node 

Wave Texture Node 

White Noise Texture Node 

Transform Nodes 
Rotate Node 

Scale Node 

Transform Node 

Translate Node 

Corner Pin Node 

Crop Node 

Displace Node 

Flip Node 

Map UV Node 

Lens Distortion Node 

Movie Distortion Node 

Utilities Nodes 
Math Nodes 
Clamp Node 

Float Curve 

Map Range Node 

Math Node 

Mix Node 

Vector Nodes 
Combine XYZ Node 

Separate XYZ Node 

Mix Vector Node 

Radial Tiling Node 

Vector Curves Node 

Vector Math Node 

Vector Rotate Node 

Combine Cylindrical Node 

Combine Spherical Node 

Separate Cylindrical Node 

Separate Spherical Node 

Matrix Utility Nodes 
Combine Matrix Node 

Invert Matrix Node 

Matrix Determinant Node 

Multiply Matrices Node 

Project Point Node 

Separate Matrix Node 

Transform Direction Node 

Transform Point Node 

Transpose Matrix Node 

Nodo Livelli 

Normalize Node 

Implicit Conversion 

Split Node 

Switch Node 

Index Switch Node 

Menu Switch Node 

Switch View Node 

Relative To Pixel Node 

Retime Node 

Camera & Lens Effects Nodes 
Chromatic Aberration Node 

Sensor Noise Node 

Vignette Node 

Gruppo 

Layout Nodes 

Motion Tracking & Masking 
Movie Clip Data-Blocks 

Tracciamento del Movimento 
Introduzione 

Clip View 
Introduzione 

Tracking Marker 

Barra degli strumenti 
Track 

Solve 

Selezione 

Modifica 
Ritaglia 

Track 

Reconstruction 

Sidebar 
Track 
Track 

Objects Panel 

Plane Track 

Telecamera 

Marker 

2D Stabilization 
Introduzione 

2D Stabilization Panel 

Flusso di Lavoro 

Vista 

Graph View 

Dope Sheet View 

Mascheramento 
Introduzione 

S-Curves 

Selezione 

Modifica 

Sidebar 

Video Editing 
Sequencer Scene 

Setting Your Project 
Video Editing App Template 

Directory Structure 

Editing Your Project 
Montage 
Strips 
Introduzione 

Strip Properties 

Scene Strip 

Clip Strip 

Mask Strip 

Movie Strip 

Sound Strip 

Image/Sequence Strip 

Color Strip 

Text Strip 

Adjustment Layer Strip 

Effect Strips 
Multicam Selector Strip 

Speed Control Strip 

Glow Strip 

Gaussian Blur Strip 

Add Strip 

Subtract Strip 

Multiply Strip 

Alpha Over & Alpha Under Strips 

Color Mix Strip 

Transitions 
Sound Crossfade 

Cross Strip 

Gamma Cross Strip 

Wipe Strip 

Strip Modifiers 

Selezione 

Modifica 

Meta Strips 

Storyboarding 
Storyboarding App Template 

Assets, Files, & Data System 
Introduzione 

Blender File 
Opening & Saving 

Compatibilità 

Packed Data 

Blend-Files Previews 

Rinomina 

Blocchi-Dati 

Custom Properties 

File Paths 

Linked Libraries 
Link & Append 

Library Overrides 

Asset Libraries 
Introduzione 

Asset Catalogs 

Media Formats 
Supported Graphics Formats 

Supported Video & Audio Formats 

Importing & Exporting Files 
Alembic 

Motion Capture (BVH) 

Universal Scene Description 

Wavefront OBJ 

Stanford PLY 

STL 

FBX 

FBX (Legacy) 

Scalable Vector Graphics (SVG) 

Import/Export SVG as Grease Pencil 

Export Grease Pencil as PDF 

Add-ons 
Node Wrangler 

Rigify 
Introduzione 

Basic Usage 

Bone Positioning Guide 

Generated Rig Features 

Creating Meta-rigs 

Rig Types 
Basic 

Spines 

Limbs 

Facce 

Skin 

Faccia 

Feature Sets 

glTF 2.0 

Manage UI Translations 

VR Scene Inspection 

Avanzate 
Using Blender From The Command Line 
Launching from the Command Line 
Linux 

macOS 

Windows 

Arguments 

Extensions Command Line Arguments 

Rendering From The Command Line 

Scripting & Extending Blender 
Introduzione 

Scripting & Security 

Add-on Tutorial 

Creating Extensions 
Getting started 

Compatible licenses 

Supported tags 

Version Number Guidelines 

Add-ons 

Python Wheels 

Creating a Repository 
Static Repository 

Dynamic Repository 

Application Templates 

Keymap Customization 

Working Limits 

Operators 

Blender’s Directory Layout 

Deploying Blender in Production 

Appendices 
Rotation Modes 

Risoluzione problemi 
Startup 

Vista 3D 

Graphics Hardware 
Windows 
NVIDIA 

AMD 

Intel 

Other GPU 

Linux 
NVIDIA 

AMD 

Intel 

Other GPU 

macOS 
NVIDIA 

AMD 

Intel 

Other GPU 

Crashes 

Network 

Python Errors 

Recovering Data 

Reporting a Bug 

Glossary 

Manual Index 

Partecipa 

Contribute Documentation 
Online Editing 

Local Editing 
Installing Dependencies 
Linux 

macOS 

Windows 

Building the Manual 

Editing the Manual 

Pull Requests 

Iniziare 

Guidelines 
Writing Style Guide 

Markup Style Guide 
Icons 

Commit Guidelines 

Templates 

Icons 

Maintenance 

Documentation Todo List 

Documenting New Features and Changes 

Translate Blender 

Translate the User Manual 
Contribute 

Style Guide 

Adding a Language 

5.2 Versioni 
Caricamento... 

Versioni Precedenti 

it Lingue 
Caricamento... 

Note 

Non stai usando la versione più recente della documentazione. è l'ultima versione. 
Back to top Edit this page 
Workflow & Examples ¶ 

Simple Drivers can be configured from the pop-over that appears when adding a new Driver.
When adding multiple Drivers or for more advanced configurations,
it is useful to have open the Drivers Editor . 

Transform Driver ¶ 

Control a property with an object’s transform.
In this example, the Y rotation of Object 2 will be driven by the X position of Object 1.
Starting from a simple setup with two objects: 

Add a Driver to the Rotation Y property of the second object via the context menu or with Ctrl - D . 

Open the Drivers Editor and select the Y Euler Rotation property in the channels region. 

Open the Sidebar region and select the Drivers tab. 

Configure the driver to be the Averaged Value of a Transform Channel of the first object. 

Experiment with moving the first object and notice how it affects the Y rotation of the second object. 

Scripted Expression - Orbit a Point ¶ 

Orbit an object’s position around a point with a custom Scripted Expression .
The object’s position will change when scrubbing the timeline.
Using trigonometry, circular motion can be defined in 2D using the sine and cosine functions.
(See Unit Circle .)
In this example, the current frame is used as the variable that induces the motion. 
frame is a Simple Expression that corresponds to 
bpy.context.scene.frame_current . 

Add a driver to the X Location property. 

Set the Driver Type to Scripted Expression . 

Add the expression 
0 + (sin(frame / 8) * 4) , where: 

frame/8 : is the current frame of the animation, divided by 8 to slow the orbit down. 

(sin( )*4) : multiplies the result of 
sin(frame/8) by 4 for a bigger circle. 

0 + : is used to control the offset to the orbit center point. 

Add a driver to the Y Location property with the expression 
0 + (cos(frame / 8) * 4) . 

Scrub the timeline to see the effect.
Experiment with the variables to control the size and center of the orbit. 

Custom Function - Square Value ¶ 

Create a custom function to get the square of a value (i.e. value 2 ).
Adding the function to the Driver Namespace allows it to be used from driver expressions.
The Driver Namespace has a list of built-in functions for use in driver expressions,
as well as constants such as π and e.
These can be inspected via the Python Console: 

>>> bpy . app . driver_namespace [ ' <tab> acos'] acosh'] asin'] asinh'] atan'] ... 

To add a new function to the Driver Namespace , the function itself needs to be implemented
and then added to the 
bpy.app.driver_namespace . 

Add the following to the Text Editor inside Blender and press Run Script . 

import bpy def square ( val ): """Returns the square of the given value""" return val * val # Add function to driver_namespace. bpy . app . driver_namespace [ 'square' ] = square 

Add a driver with a Scripted Expression such as 
square(frame) . 

Observe the effect when scrubbing the timeline. 

There are more custom function examples available in Blender’s Text Editor Templates ‣ Python ‣ Driver Functions .
Since Simple Expressions cannot access
custom functions, using them only makes sense for complex computations. 

Avvertimento 

Trying to replace built-in entries of the driver namespace may result in undefined behavior. 

View Layer Attribute Lookup ¶ 

The material Attribute Node in the View Layer mode
automatically searches for the attribute property in multiple locations. This, for example, can allow
setting a certain value of the custom attribute at the Scene or World level, and then overriding it
differently for one View Layer . 

Context Properties of drivers don’t implement this behavior, so if necessary it has to be manually
emulated via fallback values and a conditional expression (conditions are Simple Expressions ). 

For an attribute named 
attr , the node tries the following six RNA path lookups in order: 

["attr"] in the active View Layer (custom property). 

attr in the active View Layer (built-in property). 

["attr"] in the active Scene. 

attr in the active Scene. 

world["attr"] in the active Scene. 

world.attr in the active Scene. 

Depending on the specific property it may be sufficient to check only a subset of these locations.
For example, the image on the right shows how to access an attribute that is known to definitely be
a custom property with a color value. 

Driver variables accessing locations that are not final in the lookup chain should use fallback values that are
invalid for the attribute (e.g. negative color values), which can then be checked by the conditional expression.
The final variable should fallback to a valid default value to be used when the property is not set at all. 

Shape Key Drivers ¶ 

Improved Mesh Deformation ¶ 

Fix intersection problems that happen when using armatures and weight painting, especially at joints.
Shape keys can also be used to tweak and refine a rig, for example to suggest muscle formations.
In this example, a shape key is used to improve the deformation at the elbow of a rudimentary arm. 

Left: Skeletal mesh deformation without correction.
Right: Corrective shape key applied ¶ 

Setup
