# Blender Manual Chunk 166

- Source: `C:\Users\carmi\blender\manual\blender_manual_html\blender_manual_vexp_it.html\render\materials\components\volume.html`
- Manual group: `blender_manual_html`
- Score: `105`
- Part: `4`

## Content

Convert to Display Node 

Invert Color Node 

RGB to BW Node 

Creative Nodes 
Kuwahara Node 

Pixelate Node 

Posterize 

Sepia Node 

Split Toning Node 

Tune Image Node 

Unsharp Mask Node 

Filter Nodes 
Blur Filter Nodes 
Bilateral Blur Node 

Blur Node 

Bokeh Blur Node 

Defocus Node 

Directional Blur Node 

Vector Blur Node 

Anti-Aliasing Node 

Convolve Node 

Denoise Node 

Despeckle Node 

Dilate/Erode Node 

Mask To SDF Node 

Inpaint Node 

Filter Node 

Glare Node 

Keying Nodes 
Channel Key Node 

Chroma Key Node 

Color Key Node 

Color Spill Node 

Difference Key Node 

Distance Key Node 

Keying Node 

Keying Screen Node 

Luminance Key Node 

Mask Nodes 
Cryptomatte Node 

Cryptomatte Node (Legacy) 

Box Mask Node 

Ellipse Mask Node 

Double Edge Mask Node 

ID Mask Node 

Tracking Nodes 
Plane Track Deform Node 

Stabilize 2D Node 

Nodo Posizione Traccia 

Nodi Texture 
Brick Texture Node 

Checker Texture Node 

Gabor Texture Node 

Gradient Texture Node 

Magic Texture Node 

Noise Texture Node 

Voronoi Texture Node 

Wave Texture Node 

White Noise Texture Node 

Transform Nodes 
Rotate Node 

Scale Node 

Transform Node 

Translate Node 

Corner Pin Node 

Crop Node 

Displace Node 

Flip Node 

Map UV Node 

Lens Distortion Node 

Movie Distortion Node 

Utilities Nodes 
Math Nodes 
Clamp Node 

Float Curve 

Map Range Node 

Math Node 

Mix Node 

Vector Nodes 
Combine XYZ Node 

Separate XYZ Node 

Mix Vector Node 

Radial Tiling Node 

Vector Curves Node 

Vector Math Node 

Vector Rotate Node 

Combine Cylindrical Node 

Combine Spherical Node 

Separate Cylindrical Node 

Separate Spherical Node 

Matrix Utility Nodes 
Combine Matrix Node 

Invert Matrix Node 

Matrix Determinant Node 

Multiply Matrices Node 

Project Point Node 

Separate Matrix Node 

Transform Direction Node 

Transform Point Node 

Transpose Matrix Node 

Nodo Livelli 

Normalize Node 

Implicit Conversion 

Split Node 

Switch Node 

Index Switch Node 

Menu Switch Node 

Switch View Node 

Relative To Pixel Node 

Retime Node 

Camera & Lens Effects Nodes 
Chromatic Aberration Node 

Sensor Noise Node 

Vignette Node 

Gruppo 

Layout Nodes 

Motion Tracking & Masking 
Movie Clip Data-Blocks 

Tracciamento del Movimento 
Introduzione 

Clip View 
Introduzione 

Tracking Marker 

Barra degli strumenti 
Track 

Solve 

Selezione 

Modifica 
Ritaglia 

Track 

Reconstruction 

Sidebar 
Track 
Track 

Objects Panel 

Plane Track 

Telecamera 

Marker 

2D Stabilization 
Introduzione 

2D Stabilization Panel 

Flusso di Lavoro 

Vista 

Graph View 

Dope Sheet View 

Mascheramento 
Introduzione 

S-Curves 

Selezione 

Modifica 

Sidebar 

Video Editing 
Sequencer Scene 

Setting Your Project 
Video Editing App Template 

Directory Structure 

Editing Your Project 
Montage 
Strips 
Introduzione 

Strip Properties 

Scene Strip 

Clip Strip 

Mask Strip 

Movie Strip 

Sound Strip 

Image/Sequence Strip 

Color Strip 

Text Strip 

Adjustment Layer Strip 

Effect Strips 
Multicam Selector Strip 

Speed Control Strip 

Glow Strip 

Gaussian Blur Strip 

Add Strip 

Subtract Strip 

Multiply Strip 

Alpha Over & Alpha Under Strips 

Color Mix Strip 

Transitions 
Sound Crossfade 

Cross Strip 

Gamma Cross Strip 

Wipe Strip 

Strip Modifiers 

Selezione 

Modifica 

Meta Strips 

Storyboarding 
Storyboarding App Template 

Assets, Files, & Data System 
Introduzione 

Blender File 
Opening & Saving 

Compatibilità 

Packed Data 

Blend-Files Previews 

Rinomina 

Blocchi-Dati 

Custom Properties 

File Paths 

Linked Libraries 
Link & Append 

Library Overrides 

Asset Libraries 
Introduzione 

Asset Catalogs 

Media Formats 
Supported Graphics Formats 

Supported Video & Audio Formats 

Importing & Exporting Files 
Alembic 

Motion Capture (BVH) 

Universal Scene Description 

Wavefront OBJ 

Stanford PLY 

STL 

FBX 

FBX (Legacy) 

Scalable Vector Graphics (SVG) 

Import/Export SVG as Grease Pencil 

Export Grease Pencil as PDF 

Add-ons 
Node Wrangler 

Rigify 
Introduzione 

Basic Usage 

Bone Positioning Guide 

Generated Rig Features 

Creating Meta-rigs 

Rig Types 
Basic 

Spines 

Limbs 

Facce 

Skin 

Faccia 

Feature Sets 

glTF 2.0 

Manage UI Translations 

VR Scene Inspection 

Avanzate 
Using Blender From The Command Line 
Launching from the Command Line 
Linux 

macOS 

Windows 

Arguments 

Extensions Command Line Arguments 

Rendering From The Command Line 

Scripting & Extending Blender 
Introduzione 

Scripting & Security 

Add-on Tutorial 

Creating Extensions 
Getting started 

Compatible licenses 

Supported tags 

Version Number Guidelines 

Add-ons 

Python Wheels 

Creating a Repository 
Static Repository 

Dynamic Repository 

Application Templates 

Keymap Customization 

Working Limits 

Operators 

Blender’s Directory Layout 

Deploying Blender in Production 

Appendices 
Rotation Modes 

Risoluzione problemi 
Startup 

Vista 3D 

Graphics Hardware 
Windows 
NVIDIA 

AMD 

Intel 

Other GPU 

Linux 
NVIDIA 

AMD 

Intel 

Other GPU 

macOS 
NVIDIA 

AMD 

Intel 

Other GPU 

Crashes 

Network 

Python Errors 

Recovering Data 

Reporting a Bug 

Glossary 

Manual Index 

Partecipa 

Contribute Documentation 
Online Editing 

Local Editing 
Installing Dependencies 
Linux 

macOS 

Windows 

Building the Manual 

Editing the Manual 

Pull Requests 

Iniziare 

Guidelines 
Writing Style Guide 

Markup Style Guide 
Icons 

Commit Guidelines 

Templates 

Icons 

Maintenance 

Documentation Todo List 

Documenting New Features and Changes 

Translate Blender 

Translate the User Manual 
Contribute 

Style Guide 

Adding a Language 

5.2 Versioni 
Caricamento... 

Versioni Precedenti 

it Lingue 
Caricamento... 

Note 

Non stai usando la versione più recente della documentazione. è l'ultima versione. 
Back to top Edit this page 
Volumes ¶ 

Volume rendering is used to render various effects that cannot be represented by hard surfaces alone. 

Smoke, fire or clouds are set up using a volume object or fluid simulation,
with only a volume shader. 

Meshes can also be used to create such shapes by removing the default surface shader
and using a volume shader with the mesh shape defining the volume bounds
and textures defining the volume density. 

Mist is created with a volume shader for the world,
or with a large mesh object encompassing the scene. 

Absorption in glass is simulated by combining a glass surface shader with refraction
and a volume absorption shader for the interior of the object. 

Ombreggiatura ¶ 

Principled Volume ¶ 

Principled Volume is a physically-based volume shader that can be used to create a wide range of volume materials.
It supports scattering, absorption and emission in one easy to use node.
Fire can be rendered with blackbody emission. 

Smoke and fire rendered with Principled Volume shader. ¶ 

Volume Components ¶ 

For more control, volume shading components can be manually combined into a custom shader setup. 

Volume Absorption will absorb part of the light as it passes through the volume.
This can be used to shade for example black smoke or colored glass objects, or mixed with the Volume Scatter node.
This node is similar to the transparent BSDF node,
it blocks part of the light and lets other light pass straight through. 

Volume Scatter lets light scatter in other directions as it hits particles in the volume.
The anisotropy defines in which direction the light is more likely to scatter.
A value of 0 will let light scatter evenly in all directions (similar to the diffuse BSDF node),
negative values let light scatter mostly backwards, and positive values let light scatter mostly forward.
This can be used to shade white smoke or clouds for example. 

Emission will emit light from the volume, for example for fire. 

Volume Absorption, Scatter and Emission ¶ 

Attributes ¶ 

When rendering smoke and fire, volume attributes are used to define the shape and shading of the volume.
The Principled Volume shader will use them by default, while custom volume shaders can use
the Attribute node to get attributes such as density, color and temperature. 

Density ¶ 

All volume shaders have a density input.
The density defines how much of the light will interact with the volume,
getting absorbed or scattered, and how much will pass straight through. For effects such as
smoke you would specify a density field to indicate where in the volume there is smoke and
how much (density bigger than 0), and where there is no smoke (density equals 0). 

Volumes in the real world consist of particles,
a higher density means there are more particles per unit volume. More particles means there is
a higher chance for light to collide with a particle and get absorbed or scattered,
rather than passing straight through. 

Mesh Volumes ¶ 

Meshes used for volume render should be closed and Manifold .
That means that there should be no holes in the mesh.
Each edge must be connected to exactly two faces
such that there are no holes or T-shaped faces
where three or more faces are connected to an edge. 

Normals must point outside for correct results.
The normals are used to determine if a ray enters or exits a volume,
and if they point in a wrong direction, or there is a hole in the mesh,
then the renderer is unable to decide what is the inside or outside of the volume. 

These rules are the same as for rendering glass refraction correctly. 

World Volume ¶ 

A volume shader can also be applied to the world, filling the entire space. 

Currently, this is most useful for night time or other dark scenes,
as the world surface shader or sun lights will have no effect if a volume shader is used.
This is because the world background is assumed to be infinitely far away,
which is accurate enough for the sun for example.
However, for modeling effects such as fog or atmospheric scattering,
it is not a good assumption that the volume fills the entire space,
as most of the distance between the sun and the earth is empty space.
For such effects it is be better to create a volume object surrounding the scene.
The size of this object will determine how much light is scattered or absorbed. 

Multiple Scattering ¶ 

Real-world effects such as scattering in clouds or subsurface scattering require many
scattering bounces. However, unbiased rendering of such effects can be noisy, so by default
the number of bounces is zero in Cycles, and no support is available in EEVEE.
The effect you get when rendering with zero volume bounces is what is known as
«single scattering», the effect from more bounces is «multiple scattering». 

For rendering materials like skin or milk that require multiple scattering,
subsurface scattering is more efficient and easier to control. Particularly the random walk
method can accurately render such materials. 

For materials such as clouds or smoke that do not have a well-defined surface,
volume rendering is required.
