# Blender Manual Chunk 281

- Source: `C:\Users\carmi\blender\manual\blender_manual_html\blender_manual_vexp_it.html\render\shader_nodes\shader\principled.html`
- Manual group: `blender_manual_html`
- Score: `104`
- Part: `4`

## Content

Convert to Display Node 

Invert Color Node 

RGB to BW Node 

Creative Nodes 
Kuwahara Node 

Pixelate Node 

Posterize 

Sepia Node 

Split Toning Node 

Tune Image Node 

Unsharp Mask Node 

Filter Nodes 
Blur Filter Nodes 
Bilateral Blur Node 

Blur Node 

Bokeh Blur Node 

Defocus Node 

Directional Blur Node 

Vector Blur Node 

Anti-Aliasing Node 

Convolve Node 

Denoise Node 

Despeckle Node 

Dilate/Erode Node 

Mask To SDF Node 

Inpaint Node 

Filter Node 

Glare Node 

Keying Nodes 
Channel Key Node 

Chroma Key Node 

Color Key Node 

Color Spill Node 

Difference Key Node 

Distance Key Node 

Keying Node 

Keying Screen Node 

Luminance Key Node 

Mask Nodes 
Cryptomatte Node 

Cryptomatte Node (Legacy) 

Box Mask Node 

Ellipse Mask Node 

Double Edge Mask Node 

ID Mask Node 

Tracking Nodes 
Plane Track Deform Node 

Stabilize 2D Node 

Nodo Posizione Traccia 

Nodi Texture 
Brick Texture Node 

Checker Texture Node 

Gabor Texture Node 

Gradient Texture Node 

Magic Texture Node 

Noise Texture Node 

Voronoi Texture Node 

Wave Texture Node 

White Noise Texture Node 

Transform Nodes 
Rotate Node 

Scale Node 

Transform Node 

Translate Node 

Corner Pin Node 

Crop Node 

Displace Node 

Flip Node 

Map UV Node 

Lens Distortion Node 

Movie Distortion Node 

Utilities Nodes 
Math Nodes 
Clamp Node 

Float Curve 

Map Range Node 

Math Node 

Mix Node 

Vector Nodes 
Combine XYZ Node 

Separate XYZ Node 

Mix Vector Node 

Radial Tiling Node 

Vector Curves Node 

Vector Math Node 

Vector Rotate Node 

Combine Cylindrical Node 

Combine Spherical Node 

Separate Cylindrical Node 

Separate Spherical Node 

Matrix Utility Nodes 
Combine Matrix Node 

Invert Matrix Node 

Matrix Determinant Node 

Multiply Matrices Node 

Project Point Node 

Separate Matrix Node 

Transform Direction Node 

Transform Point Node 

Transpose Matrix Node 

Nodo Livelli 

Normalize Node 

Implicit Conversion 

Split Node 

Switch Node 

Index Switch Node 

Menu Switch Node 

Switch View Node 

Relative To Pixel Node 

Retime Node 

Camera & Lens Effects Nodes 
Chromatic Aberration Node 

Sensor Noise Node 

Vignette Node 

Gruppo 

Layout Nodes 

Motion Tracking & Masking 
Movie Clip Data-Blocks 

Tracciamento del Movimento 
Introduzione 

Clip View 
Introduzione 

Tracking Marker 

Barra degli strumenti 
Track 

Solve 

Selezione 

Modifica 
Ritaglia 

Track 

Reconstruction 

Sidebar 
Track 
Track 

Objects Panel 

Plane Track 

Telecamera 

Marker 

2D Stabilization 
Introduzione 

2D Stabilization Panel 

Flusso di Lavoro 

Vista 

Graph View 

Dope Sheet View 

Mascheramento 
Introduzione 

S-Curves 

Selezione 

Modifica 

Sidebar 

Video Editing 
Sequencer Scene 

Setting Your Project 
Video Editing App Template 

Directory Structure 

Editing Your Project 
Montage 
Strips 
Introduzione 

Strip Properties 

Scene Strip 

Clip Strip 

Mask Strip 

Movie Strip 

Sound Strip 

Image/Sequence Strip 

Color Strip 

Text Strip 

Adjustment Layer Strip 

Effect Strips 
Multicam Selector Strip 

Speed Control Strip 

Glow Strip 

Gaussian Blur Strip 

Add Strip 

Subtract Strip 

Multiply Strip 

Alpha Over & Alpha Under Strips 

Color Mix Strip 

Transitions 
Sound Crossfade 

Cross Strip 

Gamma Cross Strip 

Wipe Strip 

Strip Modifiers 

Selezione 

Modifica 

Meta Strips 

Storyboarding 
Storyboarding App Template 

Assets, Files, & Data System 
Introduzione 

Blender File 
Opening & Saving 

Compatibilità 

Packed Data 

Blend-Files Previews 

Rinomina 

Blocchi-Dati 

Custom Properties 

File Paths 

Linked Libraries 
Link & Append 

Library Overrides 

Asset Libraries 
Introduzione 

Asset Catalogs 

Media Formats 
Supported Graphics Formats 

Supported Video & Audio Formats 

Importing & Exporting Files 
Alembic 

Motion Capture (BVH) 

Universal Scene Description 

Wavefront OBJ 

Stanford PLY 

STL 

FBX 

FBX (Legacy) 

Scalable Vector Graphics (SVG) 

Import/Export SVG as Grease Pencil 

Export Grease Pencil as PDF 

Add-ons 
Node Wrangler 

Rigify 
Introduzione 

Basic Usage 

Bone Positioning Guide 

Generated Rig Features 

Creating Meta-rigs 

Rig Types 
Basic 

Spines 

Limbs 

Facce 

Skin 

Faccia 

Feature Sets 

glTF 2.0 

Manage UI Translations 

VR Scene Inspection 

Avanzate 
Using Blender From The Command Line 
Launching from the Command Line 
Linux 

macOS 

Windows 

Arguments 

Extensions Command Line Arguments 

Rendering From The Command Line 

Scripting & Extending Blender 
Introduzione 

Scripting & Security 

Add-on Tutorial 

Creating Extensions 
Getting started 

Compatible licenses 

Supported tags 

Version Number Guidelines 

Add-ons 

Python Wheels 

Creating a Repository 
Static Repository 

Dynamic Repository 

Application Templates 

Keymap Customization 

Working Limits 

Operators 

Blender’s Directory Layout 

Deploying Blender in Production 

Appendices 
Rotation Modes 

Risoluzione problemi 
Startup 

Vista 3D 

Graphics Hardware 
Windows 
NVIDIA 

AMD 

Intel 

Other GPU 

Linux 
NVIDIA 

AMD 

Intel 

Other GPU 

macOS 
NVIDIA 

AMD 

Intel 

Other GPU 

Crashes 

Network 

Python Errors 

Recovering Data 

Reporting a Bug 

Glossary 

Manual Index 

Partecipa 

Contribute Documentation 
Online Editing 

Local Editing 
Installing Dependencies 
Linux 

macOS 

Windows 

Building the Manual 

Editing the Manual 

Pull Requests 

Iniziare 

Guidelines 
Writing Style Guide 

Markup Style Guide 
Icons 

Commit Guidelines 

Templates 

Icons 

Maintenance 

Documentation Todo List 

Documenting New Features and Changes 

Translate Blender 

Translate the User Manual 
Contribute 

Style Guide 

Adding a Language 

5.2 Versioni 
Caricamento... 

Versioni Precedenti 

it Lingue 
Caricamento... 

Note 

Non stai usando la versione più recente della documentazione. è l'ultima versione. 
Back to top Edit this page 
Generico BSDF (Principled) ¶ 

The Principled BSDF that combines multiple layers into a single easy to use node.
It can model a wide variety of materials. 

It is based on the OpenPBR Surface shading model, and provides parameters
compatible with similar PBR shaders found in other software,
such as the Disney and Standard Surface models.
Image textures painted or baked from software like Substance Painter
may be directly linked to the corresponding input in this shader. 

Livelli ¶ 

The base layer is a mix between metal, diffuse, subsurface, and transmission components.
Most materials will use one of these components, though it is possible to smoothly mix
between them. 

The metal component is opaque and only reflect lights. Diffuse is fully opaque, while
subsurface also involves light scattering just below the surface. Both diffuse and
subsurface sit below a specular layer. The transmission component includes both
specular reflection and refraction. 

On top of all base layers there is an optional glossy coat. And finally the sheen layer
sits on top of all other layers, to add fuzz or dust. 

Light emission can also be added. Light emits from below the coat and sheen layers,
to model for example emissive displays with a coat or dust. 

Ingressi ¶ 

Base Color 

Overall color of the material used for diffuse, subsurface, metal and transmission. 

Same base color for multiple materials types ¶ 

Roughness 

Specifies microfacet roughness of the surface for specular reflection and transmission.
A value of 0.0 gives a perfectly sharp reflection, while 1.0 gives a diffuse reflection. 

Roughness from 0.0 to 1.0 ¶ 

Metallic 

Blends between a dielectric and metallic material model.
At 0.0 the material consists of a diffuse or transmissive base layer, with a specular reflection layer on top.
A value of 1.0 gives a fully specular reflection tinted with the base color,
without diffuse reflection or transmission. 

Metallic from 0.0 to 1.0 ¶ 

IOR 

Index of refraction ( IOR ) for specular reflection and transmission.
For most materials, the IOR is between 1.0 (vacuum and air) and 4.0 (germanium).
The default value of 1.5 is a good approximation for glass. 

IOR from 1.0 to 2.0 ¶ 

Trasparenza 

Controls the transparency of the surface, with 1.0 fully opaque.
Usually linked to the Alpha output of an Image Texture node. 

Alpha from 0.0 to 1.0 ¶ 

Normale 

Controls the normals of the base layers. 

Diffuso ¶ 

Roughness Cycles Only 

Surface roughness; 0.0 gives standard Lambertian reflection, higher values activate the Oren-Nayar BSDF. 

Roughness from 0.0 to 1.0 ¶ 

SubSuperficie ¶ 

Subsurface scattering is used to render materials such as skin, milk and wax.
Light scatters below the surface to create a soft appearance. 

Method 

Rendering method to simulate Subsurface scattering . 

Christensen-Burley : 

An approximation to physically-based volume scattering.
This method is less accurate than Random Walk however,
in some situations this method will resolve noise faster. 

Random Walk : 

Cycles Only Provides accurate results for thin and curved objects.
Random Walk uses true volumetric scattering inside the mesh,
which means that it works best for closed meshes.
Overlapping faces and holes in the mesh can cause problems. 

Random Walk (Skin) : 

Cycles Only Random walk method optimized for skin rendering. The radius
is automatically adjusted based on the color texture, and
the subsurface entry direction uses a mix of diffuse and
specular transmission with custom IOR . This tends to retain
greater surface detail and color and matches measured skin
more closely. 

Random Walk (Legacy) : 

Cycles Only The same as Random Walk, but uses a different mapping from albedo to
scattering parameters. Will be deleted in the future. 

Weight 

Blend between diffuse surface and subsurface scattering.
Typically should be zero or one (either fully diffuse or subsurface). 

Weight from 0.0 to 1.0 ¶ 

Radius 

Average distance that light scatters below the surface.
Higher radius gives a softer appearance, as light bleeds into shadows and through the object.
The scattering distance is specified separately for the RGB channels,
to render materials such as skin where red light scatters deeper.
The X, Y and Z values are mapped to the R, G and B values, respectively. 

Radius from white to red ¶ 

Scala 

Scale applied to the radius. 

Scale from 0 cm to 50 cm ¶ 

IOR Cycles Only 

Index of refraction ( IOR ) used for rays that enter the subsurface component. This may be set to
a different value than the global IOR to simulate different layers of skin. 

IOR from 1.0 to 2.0 ¶ 

Anisotropy Cycles Only 

Directionality of volume scattering within the subsurface medium. Zero scatters uniformly
in all directions, positive values scatter more in the forward direction, and negative
values scatter more backwards.
For example, skin has been measured to have an anisotropy of 0.8. 

Anisotropy from -0.9 to 0.9 ¶ 

Specular ¶ 

Controls for both the metallic component and specular layer on top of diffuse and subsurface. 

Distribution 

Microfacet distribution to use.
