# Blender Manual Chunk 158

- Source: `C:\Users\carmi\blender\manual\blender_manual_html\blender_manual_vexp_it.html\render\eevee\light_probes\volume.html`
- Manual group: `blender_manual_html`
- Score: `105`
- Part: `5`

## Content

In order to reduce artifacts caused by bad capture point positioning,
the bake process adjusts their location before capturing light.
It moves the capture points slightly away from surrounding surfaces and tries to move them out of objects
if they are not too far bellow the surface. 

Surface Offset 

Distance to move the capture points away from surfaces. 

Search Distance 

Distance to search for valid capture positions if the capture point is near the back-face of a single-sided object. 

Nota 

Only materials with Single Sided turned on for Light Probe Volumes will move capture point position. 

Viewport Display ¶ 

Dati 

Show the captured light using small diffuse spheres of the given size. 

Clipping 

Show the clipping distance in the 3D Viewport. 

Influenza 

Show the influence bounds in the 3D Viewport. The inner sphere is where the falloff starts. 

Next Limitations Previous Light Probe Plane Copyright © : This page is licensed under a CC-BY-SA 4.0 Int. License Made with Furo Last updated on 2026-04-25 
Visualizza Fonte 

Visualizza Traduzione 

Segnala il problema in questa pagina 
On this page 
Light Probe Volume 
Proprietà 
Bake 

Resolution 

Capture 
Clamping 

Scostamento 

Viewport Display
