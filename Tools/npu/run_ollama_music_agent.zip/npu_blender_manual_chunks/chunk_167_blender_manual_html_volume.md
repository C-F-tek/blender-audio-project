# Blender Manual Chunk 167

- Source: `C:\Users\carmi\blender\manual\blender_manual_html\blender_manual_vexp_it.html\render\materials\components\volume.html`
- Manual group: `blender_manual_html`
- Score: `105`
- Part: `5`

## Content

These look best with many scattering bounces,
but in practice one might have to limit the number of bounces to keep render times acceptable. 
Next Displacement Previous Superfici Copyright © : This page is licensed under a CC-BY-SA 4.0 Int. License Made with Furo Last updated on 2026-04-25 
Visualizza Fonte 

Visualizza Traduzione 

Segnala il problema in questa pagina 
On this page 
Volumes 
Ombreggiatura 
Principled Volume 

Volume Components 

Attributes 

Density 

Mesh Volumes 

World Volume 

Multiple Scattering
