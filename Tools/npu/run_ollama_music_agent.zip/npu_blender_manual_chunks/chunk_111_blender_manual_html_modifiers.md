# Blender Manual Chunk 111

- Source: `C:\Users\carmi\blender\manual\blender_manual_html\blender_manual_vexp_it.html\editors\graph_editor\fcurves\modifiers.html`
- Manual group: `blender_manual_html`
- Score: `105`
- Part: `4`

## Content

Convert to Display Node 

Invert Color Node 

RGB to BW Node 

Creative Nodes 
Kuwahara Node 

Pixelate Node 

Posterize 

Sepia Node 

Split Toning Node 

Tune Image Node 

Unsharp Mask Node 

Filter Nodes 
Blur Filter Nodes 
Bilateral Blur Node 

Blur Node 

Bokeh Blur Node 

Defocus Node 

Directional Blur Node 

Vector Blur Node 

Anti-Aliasing Node 

Convolve Node 

Denoise Node 

Despeckle Node 

Dilate/Erode Node 

Mask To SDF Node 

Inpaint Node 

Filter Node 

Glare Node 

Keying Nodes 
Channel Key Node 

Chroma Key Node 

Color Key Node 

Color Spill Node 

Difference Key Node 

Distance Key Node 

Keying Node 

Keying Screen Node 

Luminance Key Node 

Mask Nodes 
Cryptomatte Node 

Cryptomatte Node (Legacy) 

Box Mask Node 

Ellipse Mask Node 

Double Edge Mask Node 

ID Mask Node 

Tracking Nodes 
Plane Track Deform Node 

Stabilize 2D Node 

Nodo Posizione Traccia 

Nodi Texture 
Brick Texture Node 

Checker Texture Node 

Gabor Texture Node 

Gradient Texture Node 

Magic Texture Node 

Noise Texture Node 

Voronoi Texture Node 

Wave Texture Node 

White Noise Texture Node 

Transform Nodes 
Rotate Node 

Scale Node 

Transform Node 

Translate Node 

Corner Pin Node 

Crop Node 

Displace Node 

Flip Node 

Map UV Node 

Lens Distortion Node 

Movie Distortion Node 

Utilities Nodes 
Math Nodes 
Clamp Node 

Float Curve 

Map Range Node 

Math Node 

Mix Node 

Vector Nodes 
Combine XYZ Node 

Separate XYZ Node 

Mix Vector Node 

Radial Tiling Node 

Vector Curves Node 

Vector Math Node 

Vector Rotate Node 

Combine Cylindrical Node 

Combine Spherical Node 

Separate Cylindrical Node 

Separate Spherical Node 

Matrix Utility Nodes 
Combine Matrix Node 

Invert Matrix Node 

Matrix Determinant Node 

Multiply Matrices Node 

Project Point Node 

Separate Matrix Node 

Transform Direction Node 

Transform Point Node 

Transpose Matrix Node 

Nodo Livelli 

Normalize Node 

Implicit Conversion 

Split Node 

Switch Node 

Index Switch Node 

Menu Switch Node 

Switch View Node 

Relative To Pixel Node 

Retime Node 

Camera & Lens Effects Nodes 
Chromatic Aberration Node 

Sensor Noise Node 

Vignette Node 

Gruppo 

Layout Nodes 

Motion Tracking & Masking 
Movie Clip Data-Blocks 

Tracciamento del Movimento 
Introduzione 

Clip View 
Introduzione 

Tracking Marker 

Barra degli strumenti 
Track 

Solve 

Selezione 

Modifica 
Ritaglia 

Track 

Reconstruction 

Sidebar 
Track 
Track 

Objects Panel 

Plane Track 

Telecamera 

Marker 

2D Stabilization 
Introduzione 

2D Stabilization Panel 

Flusso di Lavoro 

Vista 

Graph View 

Dope Sheet View 

Mascheramento 
Introduzione 

S-Curves 

Selezione 

Modifica 

Sidebar 

Video Editing 
Sequencer Scene 

Setting Your Project 
Video Editing App Template 

Directory Structure 

Editing Your Project 
Montage 
Strips 
Introduzione 

Strip Properties 

Scene Strip 

Clip Strip 

Mask Strip 

Movie Strip 

Sound Strip 

Image/Sequence Strip 

Color Strip 

Text Strip 

Adjustment Layer Strip 

Effect Strips 
Multicam Selector Strip 

Speed Control Strip 

Glow Strip 

Gaussian Blur Strip 

Add Strip 

Subtract Strip 

Multiply Strip 

Alpha Over & Alpha Under Strips 

Color Mix Strip 

Transitions 
Sound Crossfade 

Cross Strip 

Gamma Cross Strip 

Wipe Strip 

Strip Modifiers 

Selezione 

Modifica 

Meta Strips 

Storyboarding 
Storyboarding App Template 

Assets, Files, & Data System 
Introduzione 

Blender File 
Opening & Saving 

Compatibilità 

Packed Data 

Blend-Files Previews 

Rinomina 

Blocchi-Dati 

Custom Properties 

File Paths 

Linked Libraries 
Link & Append 

Library Overrides 

Asset Libraries 
Introduzione 

Asset Catalogs 

Media Formats 
Supported Graphics Formats 

Supported Video & Audio Formats 

Importing & Exporting Files 
Alembic 

Motion Capture (BVH) 

Universal Scene Description 

Wavefront OBJ 

Stanford PLY 

STL 

FBX 

FBX (Legacy) 

Scalable Vector Graphics (SVG) 

Import/Export SVG as Grease Pencil 

Export Grease Pencil as PDF 

Add-ons 
Node Wrangler 

Rigify 
Introduzione 

Basic Usage 

Bone Positioning Guide 

Generated Rig Features 

Creating Meta-rigs 

Rig Types 
Basic 

Spines 

Limbs 

Facce 

Skin 

Faccia 

Feature Sets 

glTF 2.0 

Manage UI Translations 

VR Scene Inspection 

Avanzate 
Using Blender From The Command Line 
Launching from the Command Line 
Linux 

macOS 

Windows 

Arguments 

Extensions Command Line Arguments 

Rendering From The Command Line 

Scripting & Extending Blender 
Introduzione 

Scripting & Security 

Add-on Tutorial 

Creating Extensions 
Getting started 

Compatible licenses 

Supported tags 

Version Number Guidelines 

Add-ons 

Python Wheels 

Creating a Repository 
Static Repository 

Dynamic Repository 

Application Templates 

Keymap Customization 

Working Limits 

Operators 

Blender’s Directory Layout 

Deploying Blender in Production 

Appendices 
Rotation Modes 

Risoluzione problemi 
Startup 

Vista 3D 

Graphics Hardware 
Windows 
NVIDIA 

AMD 

Intel 

Other GPU 

Linux 
NVIDIA 

AMD 

Intel 

Other GPU 

macOS 
NVIDIA 

AMD 

Intel 

Other GPU 

Crashes 

Network 

Python Errors 

Recovering Data 

Reporting a Bug 

Glossary 

Manual Index 

Partecipa 

Contribute Documentation 
Online Editing 

Local Editing 
Installing Dependencies 
Linux 

macOS 

Windows 

Building the Manual 

Editing the Manual 

Pull Requests 

Iniziare 

Guidelines 
Writing Style Guide 

Markup Style Guide 
Icons 

Commit Guidelines 

Templates 

Icons 

Maintenance 

Documentation Todo List 

Documenting New Features and Changes 

Translate Blender 

Translate the User Manual 
Contribute 

Style Guide 

Adding a Language 

5.2 Versioni 
Caricamento... 

Versioni Precedenti 

it Lingue 
Caricamento... 

Note 

Non stai usando la versione più recente della documentazione. è l'ultima versione. 
Back to top Edit this page 
F-Curve Modifiers ¶ 

Riferimento 

Pannello : 

Sidebar region ‣ Modifiers 

F-Curve modifiers are similar to object modifiers, in that they add non-destructive effects
that can be adjusted at any time and layered to create more complex effects. 

Modifiers are evaluated from top to bottom.
You can change their order by dragging the dots in their top right corner. 

Some modifiers require being first and cannot be used together.
These currently include the Cycles and Smooth (Gaussian) modifiers. 

Interfaccia ¶ 

Nome 

By default, modifiers are named after their function, but this can be changed. 

Disattiva 

Click the checkbox in a modifier’s header to disable it. 

Cancella 

Click the cross in a modifier’s header to delete it. 

Influenza 

Lets you blend between the original curve and the modified one. 

Restrict Frame Range 

Start/End 

The frame on which the modifier’s effect starts/ends. 

Blend In/Out 

The number of frames, relative the start/end values above, it takes the modifier to fade in/out. 

Adding a Modifier ¶ 

Modifiers panel. ¶ 

Modifiers can be managed on the Modifiers tab of the Sidebar.
Select an F-Curve (in the channel region or by selecting one of its keyframes),
then click the Add Modifier dropdown and choose the modifier to add. 

Types of Modifiers ¶ 

Generator Modifier ¶ 

Creates a polynomial function.
These are basic mathematical formulas that represent lines, parabolas,
and other more complex curves, depending on the values used. 

Vedi anche 

The Wikipedia Page for more information on polynomials. 

Modalità 

Method used to represent the equation. 

Expanded Polynomial : 

Equation in the form \(y = A + Bx^1 + Cx^2 + ... + Dx^n\) . 

Factorized Polynomial : 

Equation in the form \(y = (Ax + B)(Cx + D)\) . 

Additive 

Add the polynomial to the curve rather than replacing it. 

Order 

The highest power of 
x for this polynomial. 

Costante 

The constants A, B, C… in the equation. 

Built-in Function Modifier ¶ 

These are additional formulas, each with the same options to control their shape.
Consult mathematics reference for more detailed information on each function: 

Tipo 

The built-in function to use: 

Sine 

Cosine 

Tangent 

Square Root 

Natural Logarithm 

Normalized Sine: \(sin(x)/x\) 

Additive 

Add the function to the curve rather than replacing it. 

Amplitude 

Adjusts the Y scaling. 

Phase Multiplier 

Adjusts the X scaling. 

Phase Offset 

Adjusts the X offset. 

Value Offset 

Adjusts the Y offset. 

Envelope Modifier ¶ 

Lets you reshape the curve. First, you define an envelope, which consists of two horizontal
lines that more or less match the curve’s lower and upper bounds. Then, you add control points,
where each point can push, squeeze, and stretch the envelope (and the curve along with it)
at a certain frame. 

The Envelope modifier. ¶ 

Riferimento 

The value which the envelope is centered around. 

Min/Max 

The offset from the reference value to the envelope’s initial lower/upper bound. 

Add Control Point 

Adds a control point at the current frame. 

Point 

Fotogramma 

The frame of the control point. 

Min/Max 

The offset from the reference value to the envelope’s adjusted lower/upper bound
at this frame. 

Cycles Modifier ¶ 

Makes the curve repeat itself. 

Nota 

The Cycles Modifier has to be the first modifier in the list. 

This modifier needs to know exactly where the keyframes are located,
which is not possible when other modifiers are processed first.
This means this modifier is not compatible with the Smooth (Gaussian) Modifier . 

Before/After Mode 

No Cycles 

Do not repeat the curve before/after the original. 

Repeat Motion 

Repeats the curve, keeping the values of each copy the same. 

Repeat with Offset 

Repeats the curve, offsetting each copy vertically so that its first keyframe matches the
previous last keyframe. 

Repeat Mirrored 

Repeats the curve, flipping every other copy horizontally. 

Count 

The number of copies to create. A value of 0 means infinite. 

Trivially Cyclic Curves ¶ 
When the Cycle Mode for both ends is set to either Repeat Motion or Repeat with Offset , and no other options of the modifier are
changed from their defaults, it defines a simple infinite cycle. 

This special case receives some additional support from other areas of Blender: 

Automatic Bézier handle placement is aware of the cycle and adjusts to achieve a smooth transition. 

The Cycle-Aware Keying option can be enabled to take the cycle into account when inserting new keyframes. 

Noise Modifier ¶ 

Modifies the curve with a noise formula.
This is useful for adding subtle or extreme randomness to animated movements,
like camera shake. 

Blend Type 

Sostituisci : 

Adds noise in the range [-0.5, 0.5]. 

Aggiungi : 

Adds noise in the range [0, 1]. 

Sottrai : 

Subtracts noise in the range [0, 1]. 

Multiply : 

Multiplies by noise in the range [0, 1]. 

Scala 

Changes the horizontal scale of the noise. Higher values make for less dense oscillation. 

Forza 

Changes the vertical scale of the noise. 

Scostamento 

Offsets the noise in time.
