# Blender Manual Chunk 144

- Source: `C:\Users\carmi\blender\manual\blender_manual_html\blender_manual_vexp_it.html\render\cycles\material_settings.html`
- Manual group: `blender_manual_html`
- Score: `105`
- Part: `4`

## Content

Convert to Display Node 

Invert Color Node 

RGB to BW Node 

Creative Nodes 
Kuwahara Node 

Pixelate Node 

Posterize 

Sepia Node 

Split Toning Node 

Tune Image Node 

Unsharp Mask Node 

Filter Nodes 
Blur Filter Nodes 
Bilateral Blur Node 

Blur Node 

Bokeh Blur Node 

Defocus Node 

Directional Blur Node 

Vector Blur Node 

Anti-Aliasing Node 

Convolve Node 

Denoise Node 

Despeckle Node 

Dilate/Erode Node 

Mask To SDF Node 

Inpaint Node 

Filter Node 

Glare Node 

Keying Nodes 
Channel Key Node 

Chroma Key Node 

Color Key Node 

Color Spill Node 

Difference Key Node 

Distance Key Node 

Keying Node 

Keying Screen Node 

Luminance Key Node 

Mask Nodes 
Cryptomatte Node 

Cryptomatte Node (Legacy) 

Box Mask Node 

Ellipse Mask Node 

Double Edge Mask Node 

ID Mask Node 

Tracking Nodes 
Plane Track Deform Node 

Stabilize 2D Node 

Nodo Posizione Traccia 

Nodi Texture 
Brick Texture Node 

Checker Texture Node 

Gabor Texture Node 

Gradient Texture Node 

Magic Texture Node 

Noise Texture Node 

Voronoi Texture Node 

Wave Texture Node 

White Noise Texture Node 

Transform Nodes 
Rotate Node 

Scale Node 

Transform Node 

Translate Node 

Corner Pin Node 

Crop Node 

Displace Node 

Flip Node 

Map UV Node 

Lens Distortion Node 

Movie Distortion Node 

Utilities Nodes 
Math Nodes 
Clamp Node 

Float Curve 

Map Range Node 

Math Node 

Mix Node 

Vector Nodes 
Combine XYZ Node 

Separate XYZ Node 

Mix Vector Node 

Radial Tiling Node 

Vector Curves Node 

Vector Math Node 

Vector Rotate Node 

Combine Cylindrical Node 

Combine Spherical Node 

Separate Cylindrical Node 

Separate Spherical Node 

Matrix Utility Nodes 
Combine Matrix Node 

Invert Matrix Node 

Matrix Determinant Node 

Multiply Matrices Node 

Project Point Node 

Separate Matrix Node 

Transform Direction Node 

Transform Point Node 

Transpose Matrix Node 

Nodo Livelli 

Normalize Node 

Implicit Conversion 

Split Node 

Switch Node 

Index Switch Node 

Menu Switch Node 

Switch View Node 

Relative To Pixel Node 

Retime Node 

Camera & Lens Effects Nodes 
Chromatic Aberration Node 

Sensor Noise Node 

Vignette Node 

Gruppo 

Layout Nodes 

Motion Tracking & Masking 
Movie Clip Data-Blocks 

Tracciamento del Movimento 
Introduzione 

Clip View 
Introduzione 

Tracking Marker 

Barra degli strumenti 
Track 

Solve 

Selezione 

Modifica 
Ritaglia 

Track 

Reconstruction 

Sidebar 
Track 
Track 

Objects Panel 

Plane Track 

Telecamera 

Marker 

2D Stabilization 
Introduzione 

2D Stabilization Panel 

Flusso di Lavoro 

Vista 

Graph View 

Dope Sheet View 

Mascheramento 
Introduzione 

S-Curves 

Selezione 

Modifica 

Sidebar 

Video Editing 
Sequencer Scene 

Setting Your Project 
Video Editing App Template 

Directory Structure 

Editing Your Project 
Montage 
Strips 
Introduzione 

Strip Properties 

Scene Strip 

Clip Strip 

Mask Strip 

Movie Strip 

Sound Strip 

Image/Sequence Strip 

Color Strip 

Text Strip 

Adjustment Layer Strip 

Effect Strips 
Multicam Selector Strip 

Speed Control Strip 

Glow Strip 

Gaussian Blur Strip 

Add Strip 

Subtract Strip 

Multiply Strip 

Alpha Over & Alpha Under Strips 

Color Mix Strip 

Transitions 
Sound Crossfade 

Cross Strip 

Gamma Cross Strip 

Wipe Strip 

Strip Modifiers 

Selezione 

Modifica 

Meta Strips 

Storyboarding 
Storyboarding App Template 

Assets, Files, & Data System 
Introduzione 

Blender File 
Opening & Saving 

Compatibilità 

Packed Data 

Blend-Files Previews 

Rinomina 

Blocchi-Dati 

Custom Properties 

File Paths 

Linked Libraries 
Link & Append 

Library Overrides 

Asset Libraries 
Introduzione 

Asset Catalogs 

Media Formats 
Supported Graphics Formats 

Supported Video & Audio Formats 

Importing & Exporting Files 
Alembic 

Motion Capture (BVH) 

Universal Scene Description 

Wavefront OBJ 

Stanford PLY 

STL 

FBX 

FBX (Legacy) 

Scalable Vector Graphics (SVG) 

Import/Export SVG as Grease Pencil 

Export Grease Pencil as PDF 

Add-ons 
Node Wrangler 

Rigify 
Introduzione 

Basic Usage 

Bone Positioning Guide 

Generated Rig Features 

Creating Meta-rigs 

Rig Types 
Basic 

Spines 

Limbs 

Facce 

Skin 

Faccia 

Feature Sets 

glTF 2.0 

Manage UI Translations 

VR Scene Inspection 

Avanzate 
Using Blender From The Command Line 
Launching from the Command Line 
Linux 

macOS 

Windows 

Arguments 

Extensions Command Line Arguments 

Rendering From The Command Line 

Scripting & Extending Blender 
Introduzione 

Scripting & Security 

Add-on Tutorial 

Creating Extensions 
Getting started 

Compatible licenses 

Supported tags 

Version Number Guidelines 

Add-ons 

Python Wheels 

Creating a Repository 
Static Repository 

Dynamic Repository 

Application Templates 

Keymap Customization 

Working Limits 

Operators 

Blender’s Directory Layout 

Deploying Blender in Production 

Appendices 
Rotation Modes 

Risoluzione problemi 
Startup 

Vista 3D 

Graphics Hardware 
Windows 
NVIDIA 

AMD 

Intel 

Other GPU 

Linux 
NVIDIA 

AMD 

Intel 

Other GPU 

macOS 
NVIDIA 

AMD 

Intel 

Other GPU 

Crashes 

Network 

Python Errors 

Recovering Data 

Reporting a Bug 

Glossary 

Manual Index 

Partecipa 

Contribute Documentation 
Online Editing 

Local Editing 
Installing Dependencies 
Linux 

macOS 

Windows 

Building the Manual 

Editing the Manual 

Pull Requests 

Iniziare 

Guidelines 
Writing Style Guide 

Markup Style Guide 
Icons 

Commit Guidelines 

Templates 

Icons 

Maintenance 

Documentation Todo List 

Documenting New Features and Changes 

Translate Blender 

Translate the User Manual 
Contribute 

Style Guide 

Adding a Language 

5.2 Versioni 
Caricamento... 

Versioni Precedenti 

it Lingue 
Caricamento... 

Note 

Non stai usando la versione più recente della documentazione. è l'ultima versione. 
Back to top Edit this page 
Material Settings ¶ 

Riferimento 

Pannello : 

Material ‣ Settings and Shader Editor ‣ Sidebar ‣ Settings 

Superficie ¶ 

Displacement 

Method used to perform Displacement on materials. 

Displacement Only : 

Mesh vertices will be displaced before rendering, modifying the actual mesh.
This gives the best quality results, if the mesh is finely subdivided.
As a result, this method is also the most memory intensive. 

Bump Only : 

When executing the surface shader, a modified surface normal is used instead of the true normal.
This is a less memory intensive alternative to actual displacement, but only an approximation.
Surface silhouettes will not be accurate and there will be no self-shadowing of the displacement. 

Displacement and Bump : 

Both methods can be combined, to do displacement on a coarser mesh,
and use bump mapping for the final detail. 

Emission Sampling 

The method used for sampling the emissive component of the material.
This option will only have an influence if the material contains an emissive material node,
otherwise it will be ignored. 

Nessuno : 

Do not use this surface as a light for sampling. 

Auto : 

Automatically determine if the surface should be treated as a light for sampling based on
emission intensity. 

Davanti : 

Treat only the front side of the surface as a light, useful for closed meshes whose interior
is not visible. 

Dietro : 

Treat only the back side of the surface as a light for sampling. 

Front and Back : 

Treat surface as a light for sampling, emitting from both the front and back side. 

Ombre Trasparenti 

Use transparent shadows if it contains a Transparent BSDF ,
disabling will render faster but will not give accurate shadows. 

Bump Map Correction 

Applies corrections to solve shadow terminator artifacts caused by bump mapping. 

Volume ¶ 

Sampling Method 

Distance : 

For dense volumes lit from far away Distance sampling is usually more efficient. 

Equiangular : 

If you have got a light inside or near the volume then equiangular sampling is better. 

Multiple Importance : 

If you have a combination of both, then the multiple importance sampling will be better. 

Interpolation 

Interpolation method to use for the volume objects and smoke simulation grids. 

Lineare : 

Simple interpolation which gives good results for thin volumes. 

Cubic : 

Smoothed high-quality interpolation needed for more dense volumes, but slower. 

Step Rate Biased 

Adjust distance between volume shader samples for volume shaders.
This is typically used to reduce the step size for procedural shaders that add more detail
with procedural textures, when it is not captured by the default step size.
Only enabled when Render ‣ Volumes ‣ Biased is enabled.
See Volume Render Settings for more information. 

Next Light Settings (Cycles) Previous Camere Copyright © : This page is licensed under a CC-BY-SA 4.0 Int. License Made with Furo Last updated on 2026-04-25 
Visualizza Fonte 

Visualizza Traduzione 

Segnala il problema in questa pagina 
On this page 
Material Settings 
Superficie 

Volume
