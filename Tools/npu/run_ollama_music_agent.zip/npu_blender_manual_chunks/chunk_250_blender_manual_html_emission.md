# Blender Manual Chunk 250

- Source: `C:\Users\carmi\blender\manual\blender_manual_html\blender_manual_vexp_it.html\render\shader_nodes\shader\emission.html`
- Manual group: `blender_manual_html`
- Score: `104`
- Part: `2`

## Content

Geometry Nodes 
Read 
ID Node 

Index Node 

Named Attribute Node 

Normal Node 

Position Node 

Radius Node 

Selection Node 

Active Element Node 

Sample 
Geometry Proximity Node 

Index of Nearest 

Raycast Node 

Sample Index Node 

Sample Nearest Node 

Write 
Set Geometry Name Node 

Set ID Node 

Set Position Node 

Set Selection Node 

Material Nodes 
Replace Material Node 

Material Index Node 

Material Selection Node 

Set Material Node 

Set Material Index Node 

Operations 
Bake Node 

Bounding Box Node 

Convex Hull Node 

Delete Geometry Node 

Duplicate Elements Node 

Merge by Distance Node 

Split To Instances Node 

Sort Elements Node 

Transform Geometry Node 

Separate Components Node 

Separate Geometry Node 

Displace Geometry Node 

Smooth Geometry Node 

Geometry to Instance Node 

Join Geometry Node 

Geometry Input Node 

Selection Nodes 
Box Selection Node 

Normal Selection Node 

Sphere Selection Node 

Curve Nodes 
Read 
Curve Handle Positions Node 

Curve Length Node 

Curve Tangent Node 

Curve Tilt Node 

Endpoint Selection Node 

Handle Type Selection Node 

Is Spline Cyclic Node 

Spline Length Node 

Spline Parameter Node 

Spline Resolution Node 

Sample 
Sample Curve Node 

Write 
Set Curve Normal Node 

Set Curve Radius Node 

Set Curve Tilt Node 

Set Handle Positions Node 

Set Handle Type Node 

Set NURBS Order Node 

Set NURBS Weight Node 

Set Spline Cyclic Node 

Set Spline Resolution Node 

Set Spline Type Node 

Operations 
Curve to Mesh Node 

Curve to Points Node 

Curves to Grease Pencil Node 

Deform Curves on Surface Node 

Fill Curve Node 

Fillet Curve Node 

Interpolate Curves Node 

Resample Curve Node 

Reverse Curve Node 

Subdivide Curve Node 

Trim Curve Node 

Primitives 
Arc Node 

Bézier Segment Node 

Curve Circle Node 

Curve Line Node 

Spiral Node 

Quadratic Bézier Node 

Quadrilateral Node 

Star Node 

Topology 
Curve of Point Node 

Offset Point in Curve Node 

Points of Curve Node 

Grease Pencil Nodes 
Read 
Named Layer Selection Node 

Write 
Set Grease Pencil Color Node 

Set Grease Pencil Depth Node 

Set Grease Pencil Softness Node 

Operations 
Grease Pencil to Curves Node 

Merge Layers Node 

Instances Nodes 
Instance on Points Node 

Instances to Points Node 

Realize Instances Node 

Rotate Instances Node 

Scale Instances Node 

Translate Instances Node 

Set Instance Transform Node 

Instance Bounds Node 

Instance Transform Node 

Instance Rotation Node 

Instance Scale Node 

Instance on Elements Node 

Randomize Transforms Node 

Mesh Nodes 
Read 
Edge Angle Node 

Edge Neighbors Node 

Edge Vertices Node 

Edges to Face Groups Node 

Face Area Node 

Face Group Boundaries Node 

Face Neighbors Node 

Face Set Node 

Is Face Planar Node 

Is Edge Smooth Node 

Is Face Smooth Node 

Mesh Island Node 

Shortest Edge Paths Node 

Vertex Neighbors Node 

Edge Length Node 

Face Corner Angle Node 

Is Edge Boundary Node 

Is Edge Loose Node 

Is Edge Manifold Node 

Is UV Split Node 

Sample 
Sample Nearest Surface Node 

Sample UV Surface Node 

Write 
Set Face Set Node 

Set Mesh Normal Node 

Set Shade Smooth Node 

Operations 
Dual Mesh Node 

Edge Paths to Curves Node 

Edge Paths to Selection Node 

Extrude Mesh Node 

Flip Faces Node 

Mesh Boolean Node 

Mesh to Curve Node 

Mesh to Density Grid Node 

Mesh to Points Node 

Mesh to SDF Grid Node 

Mesh to Volume Node 

Scale Elements Node 

Split Edges Node 

Subdivide Mesh Node 

Subdivision Surface Node 

Triangulate Node 

Primitives 
Cone Node 

Cube Node 

Cylinder Node 

Grid Node 

Icosphere Node 

Mesh Circle Node 

Mesh Line Node 

UV Sphere Node 

Topology 
Corners of Edge Node 

Corners of Face Node 

Corners of Vertex Node 

Edges of Corner Node 

Edges of Vertex Node 

Face of Corner Node 

Offset Corner in Face Node 

Vertex of Corner Node 

UV 
Pack UV Islands Node 

UV Tangent Node 

UV Unwrap Node 

Point Nodes 
Distribute Points in Volume 

Distribute Points in Grid 

Distribute Points on Faces 

Points Node 

Points to Curves Node 

Points to SDF Grid 

Points to Vertices Node 

Points to Volume Node 

Set Point Radius Node 

Volume Nodes 
Read 
Get Named Grid Node 

Grid Info Node 

Voxel Index Node 

Sample 
Sample Grid Node 

Sample Grid Index Node 

Advect Grid Node 

Grid Curl Node 

Grid Divergence Node 

Grid Gradient Node 

Grid Laplacian Node 

Write 
Set Grid Background Node 

Set Grid Transform Node 

Store Named Grid Node 

Operations 
Grid to Mesh Node 

Grid to Points Node 

Volume to Mesh Node 

SDF Grid Boolean Node 

SDF Fillet Node 

SDF Grid Laplacian Node 

SDF Grid Mean Node 

SDF Grid Mean Curvature Node 

SDF Grid Median Node 

SDF Grid Offset Node 

Field to Grid Node 

Clip Grid Node 

Grid Dilate & Erode Node 

Grid Mean Node 

Grid Median Node 

Prune Grid Node 

Voxelize Grid Node 

Primitives 
Cube Grid Topology Node 

Volume Cube Node 

Simulation Zone 

Color Utility Nodes 
Blackbody Node 

Gamma Node 

Color Ramp Node 

RGB Curves Node 

Combine Color Node 

Mix Color Node 

Separate Color Node 

Nodi Texture 
Brick Texture Node 

Checker Texture Node 

Gabor Texture Node 

Gradient Texture Node 

Image Texture Node 

Magic Texture Node 

Musgrave Texture Node 

Noise Texture Node 

Voronoi Texture Node 

Wave Texture Node 

White Noise Texture Node 

Utilities Nodes 
Math 
Bit Math Node 

Boolean Math Node 

Clamp Node 

Compare Node 

Float Curve 

Float To Integer Node 

Hash Value Node 

Integer Math Node 

Map Range Node 

Math Node 

Mix Node 

Testo 
Format String Node 

Join Strings Node 

Match String Node 

Replace String Node 

Slice String Node 

Trim String Node 

Find in String Node 

String Length Node 

String to Curves Node 

String to Value Node 

Value to String Node 

Special Characters Node 

Vector 
Radial Tiling Node 

Vector Curves Node 

Vector Math Node 

Vector Rotate Node 

Combine XYZ Node 

Mix Vector Node 

Separate XYZ Node 

Combine Cylindrical Node 

Combine Spherical Node 

Separate Cylindrical Node 

Separate Spherical Node 

Bundle 
Combine Bundle Node 

Separate Bundle Node 

Get Bundle Item Node 

Store Bundle Item Node 

Join Bundle Node 

Closure 
Closure 

Evaluate Closure 

Field 
Accumulate Field Node 

Evaluate at Index Node 

Evaluate on Domain Node 

Field Average Node 

Field Min & Max Node 

Field Variance Node 

Matrix 
Combine Matrix Node 

Combine Transform Node 

Invert Matrix Node 

Matrix Determinant Node 

Matrix SVD Node 

Multiply Matrices Node 

Project Point Node 

Separate Matrix Node 

Separate Transform Node 

Transform Direction Node 

Transform Point Node 

Transpose Matrix Node 

Rotazione 
Align Rotation to Vector Node 

Axes to Rotation Node 

Axis Angle to Rotation Node 

Euler to Rotation Node 

Invert Rotation Node 

Mix Rotation 

Rotate Rotation Node 

Rotate Vector Node 

Rotation to Euler Node 

Rotation to Quaternion Node 

Quaternion to Rotation Node 

Implicit Conversion 

For Each Geometry Element Zone 

Index Switch Node 

Menu Switch Node 

Random Value Node 

Repeat Zone 

Switch Node 

Random Rotation Node 

Deprecated 
Align Euler to Vector Node 

Rotate Euler Node 

Gruppo 

Generate Nodes 
Array Node 

Curve to Tube Node 

Scatter on Surface Node 

Hair Nodes 
Deformation 
Blend Hair Curves 

Displace Hair Curves 

Frizz Hair Curves 

Hair Curves Noise 

Roll Hair Curves 

Rotate Hair Curves 

Shrinkwrap Hair Curves 

Smooth Hair Curves 

Straighten Hair Curves 

Trim Hair Curves 

Generation 
Duplicate Hair Curves 

Generate Hair Curves 

Interpolate Hair Curves 

Guide 
Braid Hair Curves 

Clump Hair Curves 

Create Guide Index Map 

Curl Hair Curves 

Read 
Curve Info 

Curve Root 

Curve Segment 

Curve Tip 

Hair Attachment Info 

Utility 
Attach Hair Curves to Surface 

Redistribute Curve Points 

Restore Curve Segment Length 

Write 
Set Hair Curve Profile 

Normals Nodes 
Smooth By Angle Node Group 

Trasforma 
Introduzione 

Transform Modal Map 

Sculpting & Painting 
Introduzione 

Brushes 
Introduzione 

Manage Brushes 

Brush Settings 

Texture & Texture Mask 

Stroke 

Riduzione 

Cursore 

Selection & Visibility 

Navigating in Paint Modes 

Sculpting 
Introduzione 
The Brush 

Gesture Tools 

Visibility, Masking & Face Sets 

Filters 

Transforming 

Painting 

Working with Multiple Objects 

Adaptive Resolution 

Cloth Sculpting 

Brushes 
Brush Types 
Draw 

Draw Sharp 

Clay 

Clay Strips 

Clay Thumb 

Layer 

Inflate 

Blob 

Crease 

Smooth 

Plane 

Scrape Multiplane 

Pinch 

Grab 

Elastic Deform 

Snake Hook 

Thumb 

Pose 

Nudge 

Ruota 

Relax Slide 

Boundary 

Cloth 

Density 

Maschera 

Draw Face Sets 

Erase Multires Displacement 

Smear Multires Displacement 

Pittura 

Smear 

Sfocatura 

Brush Assets 

Barra degli strumenti 

Strumenti 
Pennello 

Add Object Tools 

Mask Gesture Tools 

Hide Gesture Tools 

Face Set Gesture Tools 

Trim Gesture Tools 

Line Project 

Mesh Filter 

Cloth Filter 

Color Filter 

Edit Face Set 

Mask by Color 

Transforms 

Strumento Impostazioni 
Brushes 
Introduzione 

Manage Brushes 

Brush Settings 

Texture & Texture Mask 

Stroke 

Riduzione 

Cursore 

Brush Settings 
Brush Settings 

Texture 

Stroke 

Riduzione 

Cursore 

Dyntopo 

Remesh 

Symmetry 

Opzioni 

Controlli 

Modifica 
Sculpt 

Maschera 

Face Sets 

Expand 

Pittura Texture 
Introduzione 

Brushes 

Strumento Impostazioni 
Texture Slots 

Brushes 
Introduzione 

Manage Brushes 

Brush Settings 

Texture & Texture Mask 

Stroke 

Riduzione 

Cursore 

Brush Settings 
Texture 

Stroke 

Riduzione 

Cursore 

Maschera 

Symmetry 

Opzioni 

Tiling 

Modifica 

Vertex Paint 
Introduzione 

Brushes 

Vertex Paint Tools 

Strumento Impostazioni 
Brushes 
Introduzione 

Manage Brushes 

Brush Settings 

Texture & Texture Mask 

Stroke 

Riduzione 

Cursore 

Brush Settings 
Texture 

Stroke 

Riduzione 

Cursore 

Symmetry 

Modifica 

Weight Paint 
Introduzione 

Brushes 

Weight Paint Tools 

Strumento Impostazioni 
Brushes 
Introduzione 

Manage Brushes 

Brush Settings 

Texture & Texture Mask 

Stroke 

Riduzione 

Cursore 

Brush Settings 
Stroke 

Riduzione 

Cursore 

Symmetry 

Opzioni 

Using Vertex Groups 

Modifica 

Curves Sculpting 
Introduzione 

Brushes 
Selection Paint 

Add Curves 

Delete Curves 

Density Brush 

Comb Curves 

Snake Hook Curves 

Grow / Shrink Curves 

Pinch Curves 

Puff Curves 

Smooth Curves 

Slide Curves 

Common Settings 

Grease Pencil 
Introduzione 

Structure 

Primitives 

Proprietà 
Object Properties 

Data Properties 
Livelli 

Onion Skinning 

Impostazioni 

Curve Data 

Modificatori 
Introduzione 

Generazione 
Array Modifier 

Build Modifier 

Dot Dash Modifier 

Envelope Modifier 

Length Modifier 

Line Art Modifier 

Mirror Modifier 

Multiple Strokes 

Outline Modifier 

Simplify Modifier 

Subdivide Modifier 

Deformazione 
Armature Modifier 

Hook Modifier 

Lattice Modifier 

Noise Modifier 

Offset Modifier
