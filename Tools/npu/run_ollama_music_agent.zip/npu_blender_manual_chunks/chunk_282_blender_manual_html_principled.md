# Blender Manual Chunk 282

- Source: `C:\Users\carmi\blender\manual\blender_manual_html\blender_manual_vexp_it.html\render\shader_nodes\shader\principled.html`
- Manual group: `blender_manual_html`
- Score: `104`
- Part: `5`

## Content

GGX : 

A method that is faster than Multiple-scattering GGX but is less physically accurate. 

Multiscatter GGX : 

Takes multiple scattering events between microfacets into account.
This gives more energy conserving results,
which would otherwise be visible as excessive darkening. 

IOR Level 

Adjustment to the IOR to increase or decrease intensity of the specular layer.
0.5 means no adjustment, 0 removes all reflections, 1 doubles them at normal incidence. 

This input is designed for conveniently texturing the IOR and amount of specular
reflection. 

IOR level from 0.0 to 1.0 ¶ 

Tint 

Color tint for specular and metallic reflection. 

For non-metallic tints provides artistic control over the color specular reflections at normal incidence,
while grazing reflections remain white. In reality non-metallic specular reflection is fully white. 

For metallic materials tints the edges to simulate complex IOR as found in materials such as gold or copper. 

Tint from white to orange ¶ 

Anisotropy Cycles Only 

Amount of anisotropy for specular reflection. Higher values give elongated highlights along the tangent direction;
negative values give highlights shaped perpendicular to the tangent direction. 

Anisotropy from 0.0 to 1.0 ¶ 

Anisotropic Rotation Cycles Only 

Rotates the direction of anisotropy, with 1.0 going full circle. 

Compared to the Glossy BSDF node, the direction of highlight elongation
is rotated by 90°. Add 0.25 to the value to correct. 

Anisotropic rotation from 0.0 to 1.0 ¶ 

Tangente 

Controls the tangent direction for anisotropy. 

Trasmissione ¶ 

Transmission is used to render materials like glass and liquids, where the surface both
reflects light and transmits it into the interior of the object 

Weight 

Mix between fully opaque surface at zero and fully transmissive at one. 

Weight from 0.0 to 1.0 ¶ 

Coat ¶ 

Coat on top of the materials, to simulate for example a clearcoat, lacquer or car paint. 

Weight 

Controls the intensity of the coat layer, both the reflection and the tinting.
Typically should be zero or one for physically-based materials, but may be textured
to vary the amount of coating across the surface. 

Weight from 0.0 to 1.0 ¶ 

Roughness 

Roughness of the coat layer. 

Roughness from 0.0 to 1.0 ¶ 

IOR 

Index of refraction ( IOR ) of the coat layer.
Affects its reflectivity as well as the falloff of coat tinting. 

IOR from 1.0 to 2.0 ¶ 

Tint 

Adds a colored tint to the coat layer by modeling absorption in the layer.
Saturation increases at shallower angles, as the light travels farther
through the medium, depending on the IOR. 

Tint from white to blue ¶ 

Normale 

Controls the normals of the Coat layer, for example to add a smooth coating on a rough surface. 

Sheen ¶ 

Sheen simulates very small fibers on the surface.
For cloth this adds a soft velvet like reflection near edges.
It can also be used to simulate dust on arbitrary materials. 

Weight 

Controls the intensity of the sheen layer. 

Weight from 0.0 to 1.0 ¶ 

Roughness 

Roughness of the sheen reflection. 

Roughness from 0.0 to 1.0 ¶ 

Tint 

The color of the sheen reflection. 

Tint from white to green. ¶ 

Emission ¶ 

Light emission from the surface. 

Colore 

Color of light emission from the surface. 

Emission color variations ¶ 

Forza 

Strength of the emitted light. A value of 1.0 ensures that the object
in the image has the exact same color as the Emission Color , i.e. make it “shadeless”. 

Strength from 0.0 to 10.0 ¶ 

Thin Film Cycles Only ¶ 

Thin Film simulates the effect of interference in a thin film sitting on top of the material.
This causes the specular reflection to be colored in a way which strongly depends on the view
angle as well as the film thickness and the index of refraction ( IOR ) of the film and
the material itself. 

This effect is commonly seen on e.g. oil films, soap bubbles or glass coatings. While its
influence is more obvious in specular highlights, it also affects transmission. 

Spessore 

The thickness of the film in nanometers. A value of 0 disables the simulation.
The interference effect is strongest between roughly 100 and 1000 nanometers, since this is
near the wavelengths of visible light. 

Thickness from 400 to 800 nanometers ¶ 

IOR 

Index of refraction ( IOR ) of the thin film.
The common range for this value is between 1.0 (vacuum and air) and roughly 2.0,
though some materials can reach higher values.
The default value of 1.33 is a good approximation for water.
Note that when the value is set to 1.0 or to the main IOR of the material, the thin film
effect disappears since the film optically blends into the air or the material. 

IOR from 1.0 to 1.5 ¶ 

Uscite ¶ 

BSDF 

Standard shader output. 

Next Principled Hair BSDF Previous Metallic BSDF Copyright © : This page is licensed under a CC-BY-SA 4.0 Int. License Made with Furo Last updated on 2026-04-25 
Visualizza Fonte 

Visualizza Traduzione 

Segnala il problema in questa pagina 
On this page 
Generico BSDF (Principled) 
Livelli 

Ingressi 
Diffuso 

SubSuperficie 

Specular 

Trasmissione 

Coat 

Sheen 

Emission 

Thin Film Cycles Only 

Uscite
