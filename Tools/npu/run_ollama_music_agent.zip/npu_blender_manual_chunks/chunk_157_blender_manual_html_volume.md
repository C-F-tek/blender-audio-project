# Blender Manual Chunk 157

- Source: `C:\Users\carmi\blender\manual\blender_manual_html\blender_manual_vexp_it.html\render\eevee\light_probes\volume.html`
- Manual group: `blender_manual_html`
- Score: `105`
- Part: `4`

## Content

Convert to Display Node 

Invert Color Node 

RGB to BW Node 

Creative Nodes 
Kuwahara Node 

Pixelate Node 

Posterize 

Sepia Node 

Split Toning Node 

Tune Image Node 

Unsharp Mask Node 

Filter Nodes 
Blur Filter Nodes 
Bilateral Blur Node 

Blur Node 

Bokeh Blur Node 

Defocus Node 

Directional Blur Node 

Vector Blur Node 

Anti-Aliasing Node 

Convolve Node 

Denoise Node 

Despeckle Node 

Dilate/Erode Node 

Mask To SDF Node 

Inpaint Node 

Filter Node 

Glare Node 

Keying Nodes 
Channel Key Node 

Chroma Key Node 

Color Key Node 

Color Spill Node 

Difference Key Node 

Distance Key Node 

Keying Node 

Keying Screen Node 

Luminance Key Node 

Mask Nodes 
Cryptomatte Node 

Cryptomatte Node (Legacy) 

Box Mask Node 

Ellipse Mask Node 

Double Edge Mask Node 

ID Mask Node 

Tracking Nodes 
Plane Track Deform Node 

Stabilize 2D Node 

Nodo Posizione Traccia 

Nodi Texture 
Brick Texture Node 

Checker Texture Node 

Gabor Texture Node 

Gradient Texture Node 

Magic Texture Node 

Noise Texture Node 

Voronoi Texture Node 

Wave Texture Node 

White Noise Texture Node 

Transform Nodes 
Rotate Node 

Scale Node 

Transform Node 

Translate Node 

Corner Pin Node 

Crop Node 

Displace Node 

Flip Node 

Map UV Node 

Lens Distortion Node 

Movie Distortion Node 

Utilities Nodes 
Math Nodes 
Clamp Node 

Float Curve 

Map Range Node 

Math Node 

Mix Node 

Vector Nodes 
Combine XYZ Node 

Separate XYZ Node 

Mix Vector Node 

Radial Tiling Node 

Vector Curves Node 

Vector Math Node 

Vector Rotate Node 

Combine Cylindrical Node 

Combine Spherical Node 

Separate Cylindrical Node 

Separate Spherical Node 

Matrix Utility Nodes 
Combine Matrix Node 

Invert Matrix Node 

Matrix Determinant Node 

Multiply Matrices Node 

Project Point Node 

Separate Matrix Node 

Transform Direction Node 

Transform Point Node 

Transpose Matrix Node 

Nodo Livelli 

Normalize Node 

Implicit Conversion 

Split Node 

Switch Node 

Index Switch Node 

Menu Switch Node 

Switch View Node 

Relative To Pixel Node 

Retime Node 

Camera & Lens Effects Nodes 
Chromatic Aberration Node 

Sensor Noise Node 

Vignette Node 

Gruppo 

Layout Nodes 

Motion Tracking & Masking 
Movie Clip Data-Blocks 

Tracciamento del Movimento 
Introduzione 

Clip View 
Introduzione 

Tracking Marker 

Barra degli strumenti 
Track 

Solve 

Selezione 

Modifica 
Ritaglia 

Track 

Reconstruction 

Sidebar 
Track 
Track 

Objects Panel 

Plane Track 

Telecamera 

Marker 

2D Stabilization 
Introduzione 

2D Stabilization Panel 

Flusso di Lavoro 

Vista 

Graph View 

Dope Sheet View 

Mascheramento 
Introduzione 

S-Curves 

Selezione 

Modifica 

Sidebar 

Video Editing 
Sequencer Scene 

Setting Your Project 
Video Editing App Template 

Directory Structure 

Editing Your Project 
Montage 
Strips 
Introduzione 

Strip Properties 

Scene Strip 

Clip Strip 

Mask Strip 

Movie Strip 

Sound Strip 

Image/Sequence Strip 

Color Strip 

Text Strip 

Adjustment Layer Strip 

Effect Strips 
Multicam Selector Strip 

Speed Control Strip 

Glow Strip 

Gaussian Blur Strip 

Add Strip 

Subtract Strip 

Multiply Strip 

Alpha Over & Alpha Under Strips 

Color Mix Strip 

Transitions 
Sound Crossfade 

Cross Strip 

Gamma Cross Strip 

Wipe Strip 

Strip Modifiers 

Selezione 

Modifica 

Meta Strips 

Storyboarding 
Storyboarding App Template 

Assets, Files, & Data System 
Introduzione 

Blender File 
Opening & Saving 

Compatibilità 

Packed Data 

Blend-Files Previews 

Rinomina 

Blocchi-Dati 

Custom Properties 

File Paths 

Linked Libraries 
Link & Append 

Library Overrides 

Asset Libraries 
Introduzione 

Asset Catalogs 

Media Formats 
Supported Graphics Formats 

Supported Video & Audio Formats 

Importing & Exporting Files 
Alembic 

Motion Capture (BVH) 

Universal Scene Description 

Wavefront OBJ 

Stanford PLY 

STL 

FBX 

FBX (Legacy) 

Scalable Vector Graphics (SVG) 

Import/Export SVG as Grease Pencil 

Export Grease Pencil as PDF 

Add-ons 
Node Wrangler 

Rigify 
Introduzione 

Basic Usage 

Bone Positioning Guide 

Generated Rig Features 

Creating Meta-rigs 

Rig Types 
Basic 

Spines 

Limbs 

Facce 

Skin 

Faccia 

Feature Sets 

glTF 2.0 

Manage UI Translations 

VR Scene Inspection 

Avanzate 
Using Blender From The Command Line 
Launching from the Command Line 
Linux 

macOS 

Windows 

Arguments 

Extensions Command Line Arguments 

Rendering From The Command Line 

Scripting & Extending Blender 
Introduzione 

Scripting & Security 

Add-on Tutorial 

Creating Extensions 
Getting started 

Compatible licenses 

Supported tags 

Version Number Guidelines 

Add-ons 

Python Wheels 

Creating a Repository 
Static Repository 

Dynamic Repository 

Application Templates 

Keymap Customization 

Working Limits 

Operators 

Blender’s Directory Layout 

Deploying Blender in Production 

Appendices 
Rotation Modes 

Risoluzione problemi 
Startup 

Vista 3D 

Graphics Hardware 
Windows 
NVIDIA 

AMD 

Intel 

Other GPU 

Linux 
NVIDIA 

AMD 

Intel 

Other GPU 

macOS 
NVIDIA 

AMD 

Intel 

Other GPU 

Crashes 

Network 

Python Errors 

Recovering Data 

Reporting a Bug 

Glossary 

Manual Index 

Partecipa 

Contribute Documentation 
Online Editing 

Local Editing 
Installing Dependencies 
Linux 

macOS 

Windows 

Building the Manual 

Editing the Manual 

Pull Requests 

Iniziare 

Guidelines 
Writing Style Guide 

Markup Style Guide 
Icons 

Commit Guidelines 

Templates 

Icons 

Maintenance 

Documentation Todo List 

Documenting New Features and Changes 

Translate Blender 

Translate the User Manual 
Contribute 

Style Guide 

Adding a Language 

5.2 Versioni 
Caricamento... 

Versioni Precedenti 

it Lingue 
Caricamento... 

Note 

Non stai usando la versione più recente della documentazione. è l'ultima versione. 
Back to top Edit this page 
Light Probe Volume ¶ 

A volume probe records the light incoming from all directions at many locations inside a volume. 

The light is then filtered and only the diffuse light is recorded.
The capture point positions are visible as an overlay when the Irradiance Volume object is selected. 

If an object is not inside any Irradiance Volume, or if the indirect lighting has not been baked,
the world’s diffuse lighting will be used to shade it. 

Suggerimento 

When lighting indoor environments, try to align grids with the room shape. 

Try not to put too much resolution in empty areas or areas with a low amount of lighting variation. 

Bad samples can be fixed by adding a smaller grid near the problematic area. 

Large scenes may require using many volumes with different level of details. 

Proprietà ¶ 

Riferimento 

Pannello : 

Object Data ‣ Probe 

Intensity 

Intensity factor of the recorded lighting.
Making this parameter anything other than 1.0 is not physically correct.
To be used for tweaking, animating or artistic purposes. 

Sampling Bias 

Normal Bias 

Offset sampling of the irradiance grid in the surface normal direction to reduce light bleeding.
Can lead to specular appearance of diffuse surface if set too high. 

View Bias 

Offset sampling of the irradiance grid in the viewing direction to reduce light bleeding.
Can lead to view dependent result if set too high. Prefer this if camera is static. 

Facing Bias 

When set to zero, avoids capturing points behind the shaded surface to bleed light onto
the shaded surface. This produces non-smooth interpolation when the capture resolution is high.
Increasing this bias will make the interpolation smoother but also introduce some light bleeding. 

Validity & Dilation 

During the baking process, a validity score is assigned to each capture point.
This score is based on the number of back-faces hit when capturing the incoming lighting.
Only materials with Single Sided turned on for Light Probe Volumes will reduce the validity score. 

Validity Threshold 

Capture points with validity below this threshold will be ignored during lighting interpolation.
This removes the influence of capture points trapped inside closed geometry, reducing the artifacts they produced. 

Dilation Threshold 

Capture points with validity below this threshold will have their data replaced using valid neighbors. 

Radius 

Radius in capture points in which to search for a valid neighbor. 

Bake ¶ 

Light probe volume light data is static and needs to be manually baked.
Once baked, the data is stored inside the object data-block and can be moved, animated and linked
between blender files. 

Nota 

Baking uses the render visibility of the objects in the scene. 

During baking, the scene is converted into a different representation to accelerate light transport.
This representation can be very memory intensive and prevents baking if it cannot fit inside the GPU memory.
There are a few way to deal with this issue: 

Larger scenes should be divided into smaller sections or use different level of details. 

Reduce Surfel Resolution . 

Turn off the light probe volume visibility option on objects that have little to no effect in the bake. 

Suggerimento 

The internal scene representation can be inspected using the 
Debug Value 3, 4 and 5. 

Resolution ¶ 

Resolution X, Y, Z 

Spatial resolution for volumetric light probes is determined per probe.
The local volume is divided into a regular grid of the specified dimensions.
The lighting will be captured for each cell in this grid. 

Bake Samples 

Number of ray directions to evaluate when baking.
This increases the baking time proportionally to the size of the scene representation. 

Surfel Resolution 

Number of surfels to spawn in one local unit distance.
Higher values increase quality, but have a huge impact on memory usage. 

Suggerimento 

A good value is twice the maximum Resolution . 

Capture ¶ 

Capture Distance 

Distance around the light probe volume that will be captured during the bake.
A distance of 0 will only considered the inside of the volume. 

Contributions – World 

Bake incoming light from the world instead of just visibility for more accurate lighting,
but lose correct blending to surrounding irradiance volumes. 

Contributions – Indirect Light 

Capture light bounces from light source. 

Contributions – Emission 

Capture emissive surfaces when baking. 

Clamping ¶ 
Direct Light 

Clamp incoming direct light. 0.0 disables direct light clamping.
Here direct light refers to the light that bounces only once (from the light object)
or light coming from emissive materials. 

Indirect Light 

Clamp incoming indirect light. 0.0 disables indirect light clamping.
Here indirect light refers to the light that bounces off a surface after the first bounce (from the light object)
or during the first bounce if the light comes from emissive materials. 

Suggerimento 

Setting Clamp Indirect to a very small non-zero value will effectively only record the first light bounce
leading. 

Scostamento ¶
