# Blender Manual Chunk 107

- Source: `C:\Users\carmi\blender\manual\blender_manual_html\blender_manual_vexp_it.html\animation\constraints\transform\maintain_volume.html`
- Manual group: `blender_manual_html`
- Score: `105`
- Part: `4`

## Content

Convert to Display Node 

Invert Color Node 

RGB to BW Node 

Creative Nodes 
Kuwahara Node 

Pixelate Node 

Posterize 

Sepia Node 

Split Toning Node 

Tune Image Node 

Unsharp Mask Node 

Filter Nodes 
Blur Filter Nodes 
Bilateral Blur Node 

Blur Node 

Bokeh Blur Node 

Defocus Node 

Directional Blur Node 

Vector Blur Node 

Anti-Aliasing Node 

Convolve Node 

Denoise Node 

Despeckle Node 

Dilate/Erode Node 

Mask To SDF Node 

Inpaint Node 

Filter Node 

Glare Node 

Keying Nodes 
Channel Key Node 

Chroma Key Node 

Color Key Node 

Color Spill Node 

Difference Key Node 

Distance Key Node 

Keying Node 

Keying Screen Node 

Luminance Key Node 

Mask Nodes 
Cryptomatte Node 

Cryptomatte Node (Legacy) 

Box Mask Node 

Ellipse Mask Node 

Double Edge Mask Node 

ID Mask Node 

Tracking Nodes 
Plane Track Deform Node 

Stabilize 2D Node 

Nodo Posizione Traccia 

Nodi Texture 
Brick Texture Node 

Checker Texture Node 

Gabor Texture Node 

Gradient Texture Node 

Magic Texture Node 

Noise Texture Node 

Voronoi Texture Node 

Wave Texture Node 

White Noise Texture Node 

Transform Nodes 
Rotate Node 

Scale Node 

Transform Node 

Translate Node 

Corner Pin Node 

Crop Node 

Displace Node 

Flip Node 

Map UV Node 

Lens Distortion Node 

Movie Distortion Node 

Utilities Nodes 
Math Nodes 
Clamp Node 

Float Curve 

Map Range Node 

Math Node 

Mix Node 

Vector Nodes 
Combine XYZ Node 

Separate XYZ Node 

Mix Vector Node 

Radial Tiling Node 

Vector Curves Node 

Vector Math Node 

Vector Rotate Node 

Combine Cylindrical Node 

Combine Spherical Node 

Separate Cylindrical Node 

Separate Spherical Node 

Matrix Utility Nodes 
Combine Matrix Node 

Invert Matrix Node 

Matrix Determinant Node 

Multiply Matrices Node 

Project Point Node 

Separate Matrix Node 

Transform Direction Node 

Transform Point Node 

Transpose Matrix Node 

Nodo Livelli 

Normalize Node 

Implicit Conversion 

Split Node 

Switch Node 

Index Switch Node 

Menu Switch Node 

Switch View Node 

Relative To Pixel Node 

Retime Node 

Camera & Lens Effects Nodes 
Chromatic Aberration Node 

Sensor Noise Node 

Vignette Node 

Gruppo 

Layout Nodes 

Motion Tracking & Masking 
Movie Clip Data-Blocks 

Tracciamento del Movimento 
Introduzione 

Clip View 
Introduzione 

Tracking Marker 

Barra degli strumenti 
Track 

Solve 

Selezione 

Modifica 
Ritaglia 

Track 

Reconstruction 

Sidebar 
Track 
Track 

Objects Panel 

Plane Track 

Telecamera 

Marker 

2D Stabilization 
Introduzione 

2D Stabilization Panel 

Flusso di Lavoro 

Vista 

Graph View 

Dope Sheet View 

Mascheramento 
Introduzione 

S-Curves 

Selezione 

Modifica 

Sidebar 

Video Editing 
Sequencer Scene 

Setting Your Project 
Video Editing App Template 

Directory Structure 

Editing Your Project 
Montage 
Strips 
Introduzione 

Strip Properties 

Scene Strip 

Clip Strip 

Mask Strip 

Movie Strip 

Sound Strip 

Image/Sequence Strip 

Color Strip 

Text Strip 

Adjustment Layer Strip 

Effect Strips 
Multicam Selector Strip 

Speed Control Strip 

Glow Strip 

Gaussian Blur Strip 

Add Strip 

Subtract Strip 

Multiply Strip 

Alpha Over & Alpha Under Strips 

Color Mix Strip 

Transitions 
Sound Crossfade 

Cross Strip 

Gamma Cross Strip 

Wipe Strip 

Strip Modifiers 

Selezione 

Modifica 

Meta Strips 

Storyboarding 
Storyboarding App Template 

Assets, Files, & Data System 
Introduzione 

Blender File 
Opening & Saving 

Compatibilità 

Packed Data 

Blend-Files Previews 

Rinomina 

Blocchi-Dati 

Custom Properties 

File Paths 

Linked Libraries 
Link & Append 

Library Overrides 

Asset Libraries 
Introduzione 

Asset Catalogs 

Media Formats 
Supported Graphics Formats 

Supported Video & Audio Formats 

Importing & Exporting Files 
Alembic 

Motion Capture (BVH) 

Universal Scene Description 

Wavefront OBJ 

Stanford PLY 

STL 

FBX 

FBX (Legacy) 

Scalable Vector Graphics (SVG) 

Import/Export SVG as Grease Pencil 

Export Grease Pencil as PDF 

Add-ons 
Node Wrangler 

Rigify 
Introduzione 

Basic Usage 

Bone Positioning Guide 

Generated Rig Features 

Creating Meta-rigs 

Rig Types 
Basic 

Spines 

Limbs 

Facce 

Skin 

Faccia 

Feature Sets 

glTF 2.0 

Manage UI Translations 

VR Scene Inspection 

Avanzate 
Using Blender From The Command Line 
Launching from the Command Line 
Linux 

macOS 

Windows 

Arguments 

Extensions Command Line Arguments 

Rendering From The Command Line 

Scripting & Extending Blender 
Introduzione 

Scripting & Security 

Add-on Tutorial 

Creating Extensions 
Getting started 

Compatible licenses 

Supported tags 

Version Number Guidelines 

Add-ons 

Python Wheels 

Creating a Repository 
Static Repository 

Dynamic Repository 

Application Templates 

Keymap Customization 

Working Limits 

Operators 

Blender’s Directory Layout 

Deploying Blender in Production 

Appendices 
Rotation Modes 

Risoluzione problemi 
Startup 

Vista 3D 

Graphics Hardware 
Windows 
NVIDIA 

AMD 

Intel 

Other GPU 

Linux 
NVIDIA 

AMD 

Intel 

Other GPU 

macOS 
NVIDIA 

AMD 

Intel 

Other GPU 

Crashes 

Network 

Python Errors 

Recovering Data 

Reporting a Bug 

Glossary 

Manual Index 

Partecipa 

Contribute Documentation 
Online Editing 

Local Editing 
Installing Dependencies 
Linux 

macOS 

Windows 

Building the Manual 

Editing the Manual 

Pull Requests 

Iniziare 

Guidelines 
Writing Style Guide 

Markup Style Guide 
Icons 

Commit Guidelines 

Templates 

Icons 

Maintenance 

Documentation Todo List 

Documenting New Features and Changes 

Translate Blender 

Translate the User Manual 
Contribute 

Style Guide 

Adding a Language 

5.2 Versioni 
Caricamento... 

Versioni Precedenti 

it Lingue 
Caricamento... 

Note 

Non stai usando la versione più recente della documentazione. è l'ultima versione. 
Back to top Edit this page 
Maintain Volume Constraint ¶ 

The Maintain Volume constraint ensures that an object or bone keeps its
original volume by automatically scaling down two axes when another axis
is scaled up (and vice versa). This can be useful for stretching and squashing
stylized characters, for example. 

Opzioni ¶ 

Maintain Volume constraint. ¶ 

Modalità 

Specifies how the constraint handles scaling of the non-free axes. 

Strict : 

Adjusts the scales of the non-free axes so that the volume is always exactly maintained.
Scaling up the free axis will scale down both non-free axes. Scaling up a non-free axis
will scale down the other non-free axis. 

Uniform : 

Unlike Strict , this mode only maintains the volume correctly as long as the object
is scaled equally along all three axes. 

Scaling up the free axis alone will also scale down the non-free axes, but
in an exaggerated manner that results in a loss of volume. As such, this is
not recommended. 

Scaling up a non-free axis has no effect on the other non-free axis. This
makes it possible to deviate from the target volume. 

Single Axis : 

Similar to Uniform , except the mode only maintains the volume correctly as long
as the object is scaled purely along the free axis. Because only one axis needs to
be adjusted to keep the volume instead of three, this may reduce the number of
animation curves needed. 

Changing the scale of a non-free axis again has no effect on the other non-free axis. 

Free Axis 

The axis that should keep its user-specified scale. The other two (non-free) axes will
be adjusted to maintain the volume. 

Volume 

The target volume as a ratio of the original volume (when all axes have a scale of 1). 

If all three axes have a default scale of 2 and this should be maintained, Volume should
be set to 2×2×2 = 8. 

Owner 

The space for determining and adjusting the scale of the owner. 

Influenza 

How strongly the constraint affects the owner. 

Esempio ¶ 
Next Transformation Constraint Previous Limit Scale Constraint Copyright © : This page is licensed under a CC-BY-SA 4.0 Int. License Made with Furo Last updated on 2026-04-25 
Visualizza Fonte 

Visualizza Traduzione 

Segnala il problema in questa pagina 
On this page 
Maintain Volume Constraint 
Opzioni 

Esempio
