# Blender Manual Chunk 66

- Source: `C:\Users\carmi\blender\manual\blender_manual_html\blender_manual_vexp_it.html\animation\drivers\introduction.html`
- Manual group: `blender_manual_html`
- Score: `106`
- Part: `4`

## Content

Convert to Display Node 

Invert Color Node 

RGB to BW Node 

Creative Nodes 
Kuwahara Node 

Pixelate Node 

Posterize 

Sepia Node 

Split Toning Node 

Tune Image Node 

Unsharp Mask Node 

Filter Nodes 
Blur Filter Nodes 
Bilateral Blur Node 

Blur Node 

Bokeh Blur Node 

Defocus Node 

Directional Blur Node 

Vector Blur Node 

Anti-Aliasing Node 

Convolve Node 

Denoise Node 

Despeckle Node 

Dilate/Erode Node 

Mask To SDF Node 

Inpaint Node 

Filter Node 

Glare Node 

Keying Nodes 
Channel Key Node 

Chroma Key Node 

Color Key Node 

Color Spill Node 

Difference Key Node 

Distance Key Node 

Keying Node 

Keying Screen Node 

Luminance Key Node 

Mask Nodes 
Cryptomatte Node 

Cryptomatte Node (Legacy) 

Box Mask Node 

Ellipse Mask Node 

Double Edge Mask Node 

ID Mask Node 

Tracking Nodes 
Plane Track Deform Node 

Stabilize 2D Node 

Nodo Posizione Traccia 

Nodi Texture 
Brick Texture Node 

Checker Texture Node 

Gabor Texture Node 

Gradient Texture Node 

Magic Texture Node 

Noise Texture Node 

Voronoi Texture Node 

Wave Texture Node 

White Noise Texture Node 

Transform Nodes 
Rotate Node 

Scale Node 

Transform Node 

Translate Node 

Corner Pin Node 

Crop Node 

Displace Node 

Flip Node 

Map UV Node 

Lens Distortion Node 

Movie Distortion Node 

Utilities Nodes 
Math Nodes 
Clamp Node 

Float Curve 

Map Range Node 

Math Node 

Mix Node 

Vector Nodes 
Combine XYZ Node 

Separate XYZ Node 

Mix Vector Node 

Radial Tiling Node 

Vector Curves Node 

Vector Math Node 

Vector Rotate Node 

Combine Cylindrical Node 

Combine Spherical Node 

Separate Cylindrical Node 

Separate Spherical Node 

Matrix Utility Nodes 
Combine Matrix Node 

Invert Matrix Node 

Matrix Determinant Node 

Multiply Matrices Node 

Project Point Node 

Separate Matrix Node 

Transform Direction Node 

Transform Point Node 

Transpose Matrix Node 

Nodo Livelli 

Normalize Node 

Implicit Conversion 

Split Node 

Switch Node 

Index Switch Node 

Menu Switch Node 

Switch View Node 

Relative To Pixel Node 

Retime Node 

Camera & Lens Effects Nodes 
Chromatic Aberration Node 

Sensor Noise Node 

Vignette Node 

Gruppo 

Layout Nodes 

Motion Tracking & Masking 
Movie Clip Data-Blocks 

Tracciamento del Movimento 
Introduzione 

Clip View 
Introduzione 

Tracking Marker 

Barra degli strumenti 
Track 

Solve 

Selezione 

Modifica 
Ritaglia 

Track 

Reconstruction 

Sidebar 
Track 
Track 

Objects Panel 

Plane Track 

Telecamera 

Marker 

2D Stabilization 
Introduzione 

2D Stabilization Panel 

Flusso di Lavoro 

Vista 

Graph View 

Dope Sheet View 

Mascheramento 
Introduzione 

S-Curves 

Selezione 

Modifica 

Sidebar 

Video Editing 
Sequencer Scene 

Setting Your Project 
Video Editing App Template 

Directory Structure 

Editing Your Project 
Montage 
Strips 
Introduzione 

Strip Properties 

Scene Strip 

Clip Strip 

Mask Strip 

Movie Strip 

Sound Strip 

Image/Sequence Strip 

Color Strip 

Text Strip 

Adjustment Layer Strip 

Effect Strips 
Multicam Selector Strip 

Speed Control Strip 

Glow Strip 

Gaussian Blur Strip 

Add Strip 

Subtract Strip 

Multiply Strip 

Alpha Over & Alpha Under Strips 

Color Mix Strip 

Transitions 
Sound Crossfade 

Cross Strip 

Gamma Cross Strip 

Wipe Strip 

Strip Modifiers 

Selezione 

Modifica 

Meta Strips 

Storyboarding 
Storyboarding App Template 

Assets, Files, & Data System 
Introduzione 

Blender File 
Opening & Saving 

Compatibilità 

Packed Data 

Blend-Files Previews 

Rinomina 

Blocchi-Dati 

Custom Properties 

File Paths 

Linked Libraries 
Link & Append 

Library Overrides 

Asset Libraries 
Introduzione 

Asset Catalogs 

Media Formats 
Supported Graphics Formats 

Supported Video & Audio Formats 

Importing & Exporting Files 
Alembic 

Motion Capture (BVH) 

Universal Scene Description 

Wavefront OBJ 

Stanford PLY 

STL 

FBX 

FBX (Legacy) 

Scalable Vector Graphics (SVG) 

Import/Export SVG as Grease Pencil 

Export Grease Pencil as PDF 

Add-ons 
Node Wrangler 

Rigify 
Introduzione 

Basic Usage 

Bone Positioning Guide 

Generated Rig Features 

Creating Meta-rigs 

Rig Types 
Basic 

Spines 

Limbs 

Facce 

Skin 

Faccia 

Feature Sets 

glTF 2.0 

Manage UI Translations 

VR Scene Inspection 

Avanzate 
Using Blender From The Command Line 
Launching from the Command Line 
Linux 

macOS 

Windows 

Arguments 

Extensions Command Line Arguments 

Rendering From The Command Line 

Scripting & Extending Blender 
Introduzione 

Scripting & Security 

Add-on Tutorial 

Creating Extensions 
Getting started 

Compatible licenses 

Supported tags 

Version Number Guidelines 

Add-ons 

Python Wheels 

Creating a Repository 
Static Repository 

Dynamic Repository 

Application Templates 

Keymap Customization 

Working Limits 

Operators 

Blender’s Directory Layout 

Deploying Blender in Production 

Appendices 
Rotation Modes 

Risoluzione problemi 
Startup 

Vista 3D 

Graphics Hardware 
Windows 
NVIDIA 

AMD 

Intel 

Other GPU 

Linux 
NVIDIA 

AMD 

Intel 

Other GPU 

macOS 
NVIDIA 

AMD 

Intel 

Other GPU 

Crashes 

Network 

Python Errors 

Recovering Data 

Reporting a Bug 

Glossary 

Manual Index 

Partecipa 

Contribute Documentation 
Online Editing 

Local Editing 
Installing Dependencies 
Linux 

macOS 

Windows 

Building the Manual 

Editing the Manual 

Pull Requests 

Iniziare 

Guidelines 
Writing Style Guide 

Markup Style Guide 
Icons 

Commit Guidelines 

Templates 

Icons 

Maintenance 

Documentation Todo List 

Documenting New Features and Changes 

Translate Blender 

Translate the User Manual 
Contribute 

Style Guide 

Adding a Language 

5.2 Versioni 
Caricamento... 

Versioni Precedenti 

it Lingue 
Caricamento... 

Note 

Non stai usando la versione più recente della documentazione. è l'ultima versione. 
Back to top Edit this page 
Introduzione ¶ 

Drivers are a way to control values of properties by means of a function,
or a mathematical expression. 

Effectively, drivers consist of: 

A driver configuration that specifies zero, one, or more input values using
other properties or object transformation channels, and combines them using
a predefined mathematical function or a custom Python expression. 

An animation F-Curve that maps the output of the driver configuration to the final value to apply
to the driven property. 

As an example, the rotation of Object 1 can be controlled by the scale of Object 2.
It is then said that the scale of Object 2 drives the rotation of Object 1. 

Not only can drivers directly set the value of a property to the value of a different one,
they can also combine multiple values using a fixed function or a Python expression
and further modulate it with a manually defined curve and/or a modifier stack. 

Drivers are an extremely powerful tool for building rigs and are typically used
to drive bone transforms and the influence of shape keys, action constraints and
modifiers, often using custom properties as inputs. 

Graph View ¶ 

Driver curve in the Drivers editor. ¶ 

The main area of the Drivers editor shows an F-Curve that
represents the driver function. 

The X axis maps to the output value of the driver configuration. The units depend on the setup. 

The Y axis shows the value applied to the target property. The units depend on the property. 

In the example image, if the driver value is 2.0 the property value will be 0.5. 

The default F-Curve is an identity map, i.e. the value produced by the driver configuration
is applied to the driven property unchanged. If the driver output value is 2.0,
the property will be 2.0. 

The driver function can be defined artistically with Bézier curve handles or
mathematically with trigonometric functions or polynomial expressions such as \(y = a + bx\) .
Furthermore, the function can also be procedurally modulated with noise or cyclic repetitions.
See Modifiers for more details. 

Driver Configuration ¶ 

The Drivers panel shows the setup for a driver. 

A driver can have zero, one, or more variables . Variables specify which properties,
object transformation channels, or relative distances between objects, are used as inputs
by the driver. 

The driver type determines how the variables are used. The type can be: 

a built-in function: for example, the sum of the variables” values, or 

a scripted expression: an arbitrary Python expression that refers to the variables by their names. 

This driver configuration outputs a single value which changes when the variables change.
This value is then evaluated through the driver function curve to produce the result
to be applied to the driven property. 

Notes on Scripted Expressions ¶ 

When a driver uses a Scripted Expression , Blender can evaluate it without using
the fully featured Python interpreter if it is simple enough.
This means that drivers are fast to evaluate with simple divisions, additions and other «simple» expressions.
The built-in functions are always evaluated natively. 

See Simple Expressions for a comprehensive list of expressions that can be evaluated natively. 

When the expression is not simple, it will be evaluated using Python.
As a consequence, the driver will be slower and there is a security risk
if the author of the Python code is unknown.
This is an important thing to take into consideration for heavy scenes and
when sharing files with other people.
See also: Auto run . 
Next Uso Previous Guide (driver) Copyright © : This page is licensed under a CC-BY-SA 4.0 Int. License Made with Furo Last updated on 2026-04-25 
Visualizza Fonte 

Visualizza Traduzione 

Segnala il problema in questa pagina 
On this page 
Introduzione 
Graph View 

Driver Configuration 

Notes on Scripted Expressions
