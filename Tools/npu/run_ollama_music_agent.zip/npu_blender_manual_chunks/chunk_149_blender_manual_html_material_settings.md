# Blender Manual Chunk 149

- Source: `C:\Users\carmi\blender\manual\blender_manual_html\blender_manual_vexp_it.html\render\eevee\material_settings.html`
- Manual group: `blender_manual_html`
- Score: `105`
- Part: `5`

## Content

Transparency Overlap 

If enabled, all transparent fragments will be rendered.
If disabled, only the front-most surface fragments will be rendered.
This option can be disabled to fix sorting issues caused by blending order.
Only available for the Blended render method. 

Spessore 

Determines what model to use to approximate the object geometry. 

Sfera : 

Approximate the object as a sphere whose diameter is equal to the thickness defined by the node tree.
This is more suited to objects with rounder edges (e.g. a monkey head), and is perfectly suited to spheres. 

Slab : 

Approximate the object as an infinite slab of thickness defined by the node tree.
This is more suited to very flat or thin objects (e.g. glass panels, grass blades). 

From Shadow 

Use the shadow maps from shadow casting lights to refine the thickness defined by the material node tree.
This takes the minimum thickness between the shadow map and the material node tree value.
This is useful for objects where pre-computation is difficult (e.g. complex meshes), impossible
(e.g. procedural geometry with displacement) or just impractical.
However, this will have a performance impact that scale with the number of render samples. 

Volume ¶ 

Intersection 

Determines which inner part of the mesh will produce volumetric effect. 

Fast : 

Each face is considered as a medium interface. Gives correct results for manifold geometry
that contains no inner part. 

Accurate : 

Faces are considered as medium interface only when they have different consecutive facing.
Gives correct results as long as the max ray depth is not exceeded. Has significant memory
overhead compared to the fast method. 

Alpha Clip Setup ¶ 

When using raytracing with material set to dithered render mode, this can lead to noisy renders around transparent
areas. To make edges clean, it is necessary to quantize alpha value to either 0 or 1. This can be done using greater
than math node. 

Alpha clip setup ¶ 
Next Light Settings (EEVEE) Previous Object Properties Copyright © : This page is licensed under a CC-BY-SA 4.0 Int. License Made with Furo Last updated on 2026-04-25 
Visualizza Fonte 

Visualizza Traduzione 

Segnala il problema in questa pagina 
On this page 
Materials 
Spessore 

Material Settings 

Superficie 

Volume 

Alpha Clip Setup
