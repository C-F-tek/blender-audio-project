# Blender Manual Chunk 269

- Source: `C:\Users\carmi\blender\manual\blender_manual_html\blender_manual_vexp_it.html\render\shader_nodes\shader\hair_principled.html`
- Manual group: `blender_manual_html`
- Score: `104`
- Part: `5`

## Content

The color of this component is always white. Keep this 1.0 for physical correctness. 

Trasmissione 

Optional factor for modulating the transmission component. Picks up the color of the
pigment inside the hair. Keep this 1.0 for physical correctness. 

Secondary Reflection 

Optional factor for modulating the component which is transmitted into the hair,
reflected off the backside of the hair and then transmitted out of the hair. This
component is oriented approximately around the incoming direction, and picks up the
color of the pigment inside the hair. Keep this 1.0 for physical correctness 

Proprietà ¶ 

Color Parametrization 

The shader provides three different ways, or parametrizations , to color the hair strands. 

Direct Coloring : 

Choose the desired RGB color and the shader will approximate
the necessary absorption coefficient (below). 

Melanin Concentration : 

This mode defines the color as the quantity and
ratio of the pigments which are commonly found in hair and fur, eumelanin (prevalent in brown-black hair) and pheomelanin (red hair).
The quantity is specified in the Melanin input, and the ratio between them in Melanin Redness .
Increasing concentrations darken the hair (the following are with Melanin Redness \(1\) ): 

White (Melanin \(0\) ) 

Blonde (Melanin \(0.25\) ) 

Reddish (Melanin \(0.5\) ) 

Brown (Melanin \(0.75\) ) 

Black (Melanin \(1\) ) 

Additionally, the Tint inputs allows to dye the hair with the desired color. 

Absorption Coefficient : 

Specifies the attenuation coefficient \(\sigma_{a}\) , as applied by the Beer-Lambert law .
This mode is intended mainly for technical users who want to use coefficients from the literature
without any sort of conversion. 

Uscite ¶ 

BSDF 

Standard shader output. 

References ¶ 

This shader is an implementation of the papers by Chiang et al. [CBTB16] and Huang et al. [HHH22] . 
[ CBTB16 ] ( 1 , 2 , 3 ) 
Chiang, M. J. , Bitterli, B. , Tappan, C. and Burley, B. (2016),
A Practical and Controllable Hair and Fur Model for Production Path Tracing. Computer Graphics Forum, 35: 275-283. doi:10.1111/cgf.12830 
[ EFHLA11 ] 
d’Eon, E. , Francois, G. , Hill, M. , Letteri, J. and Aubry, J. (2011),
An Energy‐Conserving Hair Reflectance Model. Computer Graphics Forum, 30: 1181-1187. doi:10.1111/j.1467-8659.2011.01976.x 
[ HHH22 ] 
Huang W., Hullin M.B. Hanika J. (2022),
A Microfacet-based Hair Scattering Model. Computer Graphics Forum, 41: 79-91. doi:10.1111/cgf.14588 
Next Principled Volume Previous Generico BSDF (Principled) Copyright © : This page is licensed under a CC-BY-SA 4.0 Int. License Made with Furo Last updated on 2026-04-25 
Visualizza Fonte 

Visualizza Traduzione 

Segnala il problema in questa pagina 
On this page 
Principled Hair BSDF 
Ingressi 
Comune 

Chiang Model 

Huang Model 

Proprietà 

Uscite 

References
