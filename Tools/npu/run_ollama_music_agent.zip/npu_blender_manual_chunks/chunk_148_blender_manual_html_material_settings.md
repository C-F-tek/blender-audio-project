# Blender Manual Chunk 148

- Source: `C:\Users\carmi\blender\manual\blender_manual_html\blender_manual_vexp_it.html\render\eevee\material_settings.html`
- Manual group: `blender_manual_html`
- Score: `105`
- Part: `4`

## Content

Convert to Display Node 

Invert Color Node 

RGB to BW Node 

Creative Nodes 
Kuwahara Node 

Pixelate Node 

Posterize 

Sepia Node 

Split Toning Node 

Tune Image Node 

Unsharp Mask Node 

Filter Nodes 
Blur Filter Nodes 
Bilateral Blur Node 

Blur Node 

Bokeh Blur Node 

Defocus Node 

Directional Blur Node 

Vector Blur Node 

Anti-Aliasing Node 

Convolve Node 

Denoise Node 

Despeckle Node 

Dilate/Erode Node 

Mask To SDF Node 

Inpaint Node 

Filter Node 

Glare Node 

Keying Nodes 
Channel Key Node 

Chroma Key Node 

Color Key Node 

Color Spill Node 

Difference Key Node 

Distance Key Node 

Keying Node 

Keying Screen Node 

Luminance Key Node 

Mask Nodes 
Cryptomatte Node 

Cryptomatte Node (Legacy) 

Box Mask Node 

Ellipse Mask Node 

Double Edge Mask Node 

ID Mask Node 

Tracking Nodes 
Plane Track Deform Node 

Stabilize 2D Node 

Nodo Posizione Traccia 

Nodi Texture 
Brick Texture Node 

Checker Texture Node 

Gabor Texture Node 

Gradient Texture Node 

Magic Texture Node 

Noise Texture Node 

Voronoi Texture Node 

Wave Texture Node 

White Noise Texture Node 

Transform Nodes 
Rotate Node 

Scale Node 

Transform Node 

Translate Node 

Corner Pin Node 

Crop Node 

Displace Node 

Flip Node 

Map UV Node 

Lens Distortion Node 

Movie Distortion Node 

Utilities Nodes 
Math Nodes 
Clamp Node 

Float Curve 

Map Range Node 

Math Node 

Mix Node 

Vector Nodes 
Combine XYZ Node 

Separate XYZ Node 

Mix Vector Node 

Radial Tiling Node 

Vector Curves Node 

Vector Math Node 

Vector Rotate Node 

Combine Cylindrical Node 

Combine Spherical Node 

Separate Cylindrical Node 

Separate Spherical Node 

Matrix Utility Nodes 
Combine Matrix Node 

Invert Matrix Node 

Matrix Determinant Node 

Multiply Matrices Node 

Project Point Node 

Separate Matrix Node 

Transform Direction Node 

Transform Point Node 

Transpose Matrix Node 

Nodo Livelli 

Normalize Node 

Implicit Conversion 

Split Node 

Switch Node 

Index Switch Node 

Menu Switch Node 

Switch View Node 

Relative To Pixel Node 

Retime Node 

Camera & Lens Effects Nodes 
Chromatic Aberration Node 

Sensor Noise Node 

Vignette Node 

Gruppo 

Layout Nodes 

Motion Tracking & Masking 
Movie Clip Data-Blocks 

Tracciamento del Movimento 
Introduzione 

Clip View 
Introduzione 

Tracking Marker 

Barra degli strumenti 
Track 

Solve 

Selezione 

Modifica 
Ritaglia 

Track 

Reconstruction 

Sidebar 
Track 
Track 

Objects Panel 

Plane Track 

Telecamera 

Marker 

2D Stabilization 
Introduzione 

2D Stabilization Panel 

Flusso di Lavoro 

Vista 

Graph View 

Dope Sheet View 

Mascheramento 
Introduzione 

S-Curves 

Selezione 

Modifica 

Sidebar 

Video Editing 
Sequencer Scene 

Setting Your Project 
Video Editing App Template 

Directory Structure 

Editing Your Project 
Montage 
Strips 
Introduzione 

Strip Properties 

Scene Strip 

Clip Strip 

Mask Strip 

Movie Strip 

Sound Strip 

Image/Sequence Strip 

Color Strip 

Text Strip 

Adjustment Layer Strip 

Effect Strips 
Multicam Selector Strip 

Speed Control Strip 

Glow Strip 

Gaussian Blur Strip 

Add Strip 

Subtract Strip 

Multiply Strip 

Alpha Over & Alpha Under Strips 

Color Mix Strip 

Transitions 
Sound Crossfade 

Cross Strip 

Gamma Cross Strip 

Wipe Strip 

Strip Modifiers 

Selezione 

Modifica 

Meta Strips 

Storyboarding 
Storyboarding App Template 

Assets, Files, & Data System 
Introduzione 

Blender File 
Opening & Saving 

Compatibilità 

Packed Data 

Blend-Files Previews 

Rinomina 

Blocchi-Dati 

Custom Properties 

File Paths 

Linked Libraries 
Link & Append 

Library Overrides 

Asset Libraries 
Introduzione 

Asset Catalogs 

Media Formats 
Supported Graphics Formats 

Supported Video & Audio Formats 

Importing & Exporting Files 
Alembic 

Motion Capture (BVH) 

Universal Scene Description 

Wavefront OBJ 

Stanford PLY 

STL 

FBX 

FBX (Legacy) 

Scalable Vector Graphics (SVG) 

Import/Export SVG as Grease Pencil 

Export Grease Pencil as PDF 

Add-ons 
Node Wrangler 

Rigify 
Introduzione 

Basic Usage 

Bone Positioning Guide 

Generated Rig Features 

Creating Meta-rigs 

Rig Types 
Basic 

Spines 

Limbs 

Facce 

Skin 

Faccia 

Feature Sets 

glTF 2.0 

Manage UI Translations 

VR Scene Inspection 

Avanzate 
Using Blender From The Command Line 
Launching from the Command Line 
Linux 

macOS 

Windows 

Arguments 

Extensions Command Line Arguments 

Rendering From The Command Line 

Scripting & Extending Blender 
Introduzione 

Scripting & Security 

Add-on Tutorial 

Creating Extensions 
Getting started 

Compatible licenses 

Supported tags 

Version Number Guidelines 

Add-ons 

Python Wheels 

Creating a Repository 
Static Repository 

Dynamic Repository 

Application Templates 

Keymap Customization 

Working Limits 

Operators 

Blender’s Directory Layout 

Deploying Blender in Production 

Appendices 
Rotation Modes 

Risoluzione problemi 
Startup 

Vista 3D 

Graphics Hardware 
Windows 
NVIDIA 

AMD 

Intel 

Other GPU 

Linux 
NVIDIA 

AMD 

Intel 

Other GPU 

macOS 
NVIDIA 

AMD 

Intel 

Other GPU 

Crashes 

Network 

Python Errors 

Recovering Data 

Reporting a Bug 

Glossary 

Manual Index 

Partecipa 

Contribute Documentation 
Online Editing 

Local Editing 
Installing Dependencies 
Linux 

macOS 

Windows 

Building the Manual 

Editing the Manual 

Pull Requests 

Iniziare 

Guidelines 
Writing Style Guide 

Markup Style Guide 
Icons 

Commit Guidelines 

Templates 

Icons 

Maintenance 

Documentation Todo List 

Documenting New Features and Changes 

Translate Blender 

Translate the User Manual 
Contribute 

Style Guide 

Adding a Language 

5.2 Versioni 
Caricamento... 

Versioni Precedenti 

it Lingue 
Caricamento... 

Note 

Non stai usando la versione più recente della documentazione. è l'ultima versione. 
Back to top Edit this page 
Materials ¶ 

Vedi anche 

While EEVEE shares the same material node system as Cycles, not all features are supported.
See Shader nodes limitations . 

Spessore ¶ 

Riferimento 

Pannello : 

Properties ‣ Material ‣ Thickness 

Used to approximate the inner geometry structure of the object without heavy computation.
This is currently used for Subsurface Scattering , Translucent BSDF , Refraction BSDF , and the nodes containing these effects. 

If no value is plugged into the output node,
a default thickness based on the smallest dimension of the object is used.
If a value is connected it will be used as object space thickness (i.e. scaled by object transform).
A value of zero will disable the thickness approximation and treat the object as having only one interface. 

This output is only used by the EEVEE render engine. 

Nota 

The thickness is used to skip the inner part of the object. 

Refraction will not refract objects inside the thickness distance. 

Shadow casting object will not cast shadow within the thickness distance. 

Suggerimento 

For large or compound meshes (e.g. vegetation),
the thickness should be set to the thickness of individual parts (e.g. leaves, grass blades). 

Thickness can be baked to textures or custom attributes for more accurate result. 

Vedi anche 

Thickness Mode – controls how the thickness value is used. 

Material Settings ¶ 

Riferimento 

Pannello : 

Properties ‣ Material ‣ Settings 

Pass Index 

Index number for the Material Index render pass .
This can be used to give a mask to a material which then can be read with
the ID Mask Node in the Compositor. 

Nota 

Volume Objects do not support the pass index. 

Superficie ¶ 

Abbattimento della faccia posteriore 

Backface Culling hides the back side of faces.
This option should be turned on whenever it is possible, as it has an impact on performance. 

Telecamera 

Use back face culling to hide the back side of the face. 

Ombra 

Use back face culling when casting shadows. 

Light Probe Volume 

Use back face culling when baking Light Probe Volumes .
Additionally helps rejecting capture point inside the object to avoid light leaking 

Displacement 

Controls how the displacement output from the shader node tree is used. 

Bump Only : 

Use Bump Mapping to simulated the appearance of displacement.
This only modifies the shading normal of the object. Vertex position is not affected. 

Displacement Only : 

This mode is not supported and falls back to Displacement and Bump . 

Displacement and Bump : 

Combination of true displacement and bump mapping for finer details.
Vertex position is modified. 

Nota 

This type of displacement is not precomputed. It has a performance impact multiplied by the
render sample count. However, the evaluation is much faster than doing it using geometry
nodes or a displacement modifier. 

Nota 

Displacing flat shaded geometry will split adjacent faces.
This can be worked around by passing the vertex normals as a custom attribute. 

Max Distance 

The maximum distance a vertex can be displaced when using true displacement.
Displacements over this threshold may cause visibility issues.
These visibility issues can be observed when the object is out of view at the edge of screen
with parts being displaced inside the view. The object would then disappear because of camera culling.
This can also produce missing shadow updates where the displaced geometry is. 

Transparent shadows 

Use transparent shadows for this material if it contains a Transparent BSDF.
Disabling will render faster but not give accurate shadows. 

Render Method 

Controls the blending and the compatibility with certain features. 

Dithered : 

Allows for grayscale hashed transparency, and compatible with render passes and raytracing.
Also known as deferred rendering. 

When using Dithered render method, the materials are rendered in layers.
Each layer can only transmit (e.g. refract) light emitted from previous layers.
If no intersection with the layers below exists, the transmissive BSDFs will fallback to light probes. 

Raytraced Transmission 

Use raytracing to determine transmitted color instead of using only light probes.
This prevents the surface from contributing to the lighting of surfaces not using this setting. 

Blended : 

Allows the colored transparency, but incompatible with render passes and raytracing.
Also known as forward rendering. 

Sorting Problem 

When using Blended render method, the order in which the color blending
happens is important as it can change the final output color.
EEVEE does not support per-fragment (pixel) sorting or per-triangle sorting.
Only per-object sorting is available and is automatically done on all
transparent surfaces based on object origin.
Opaque surfaces (i.e. that have no transparency)
will still have correct sorting regardless of the render method. 

Suggerimento 

Face order can be adjusted in edit mode by using sort element or using a geometry node . 

Nota 

Per-object sorting has a performance cost and having thousands of
objects in a scene will greatly degrade performance.
