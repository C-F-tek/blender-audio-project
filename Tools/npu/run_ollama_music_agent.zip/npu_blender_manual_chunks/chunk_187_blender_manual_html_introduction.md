# Blender Manual Chunk 187

- Source: `C:\Users\carmi\blender\manual\blender_manual_html\blender_manual_vexp_it.html\animation\keyframes\introduction.html`
- Manual group: `blender_manual_html`
- Score: `104`
- Part: `4`

## Content

Convert to Display Node 

Invert Color Node 

RGB to BW Node 

Creative Nodes 
Kuwahara Node 

Pixelate Node 

Posterize 

Sepia Node 

Split Toning Node 

Tune Image Node 

Unsharp Mask Node 

Filter Nodes 
Blur Filter Nodes 
Bilateral Blur Node 

Blur Node 

Bokeh Blur Node 

Defocus Node 

Directional Blur Node 

Vector Blur Node 

Anti-Aliasing Node 

Convolve Node 

Denoise Node 

Despeckle Node 

Dilate/Erode Node 

Mask To SDF Node 

Inpaint Node 

Filter Node 

Glare Node 

Keying Nodes 
Channel Key Node 

Chroma Key Node 

Color Key Node 

Color Spill Node 

Difference Key Node 

Distance Key Node 

Keying Node 

Keying Screen Node 

Luminance Key Node 

Mask Nodes 
Cryptomatte Node 

Cryptomatte Node (Legacy) 

Box Mask Node 

Ellipse Mask Node 

Double Edge Mask Node 

ID Mask Node 

Tracking Nodes 
Plane Track Deform Node 

Stabilize 2D Node 

Nodo Posizione Traccia 

Nodi Texture 
Brick Texture Node 

Checker Texture Node 

Gabor Texture Node 

Gradient Texture Node 

Magic Texture Node 

Noise Texture Node 

Voronoi Texture Node 

Wave Texture Node 

White Noise Texture Node 

Transform Nodes 
Rotate Node 

Scale Node 

Transform Node 

Translate Node 

Corner Pin Node 

Crop Node 

Displace Node 

Flip Node 

Map UV Node 

Lens Distortion Node 

Movie Distortion Node 

Utilities Nodes 
Math Nodes 
Clamp Node 

Float Curve 

Map Range Node 

Math Node 

Mix Node 

Vector Nodes 
Combine XYZ Node 

Separate XYZ Node 

Mix Vector Node 

Radial Tiling Node 

Vector Curves Node 

Vector Math Node 

Vector Rotate Node 

Combine Cylindrical Node 

Combine Spherical Node 

Separate Cylindrical Node 

Separate Spherical Node 

Matrix Utility Nodes 
Combine Matrix Node 

Invert Matrix Node 

Matrix Determinant Node 

Multiply Matrices Node 

Project Point Node 

Separate Matrix Node 

Transform Direction Node 

Transform Point Node 

Transpose Matrix Node 

Nodo Livelli 

Normalize Node 

Implicit Conversion 

Split Node 

Switch Node 

Index Switch Node 

Menu Switch Node 

Switch View Node 

Relative To Pixel Node 

Retime Node 

Camera & Lens Effects Nodes 
Chromatic Aberration Node 

Sensor Noise Node 

Vignette Node 

Gruppo 

Layout Nodes 

Motion Tracking & Masking 
Movie Clip Data-Blocks 

Tracciamento del Movimento 
Introduzione 

Clip View 
Introduzione 

Tracking Marker 

Barra degli strumenti 
Track 

Solve 

Selezione 

Modifica 
Ritaglia 

Track 

Reconstruction 

Sidebar 
Track 
Track 

Objects Panel 

Plane Track 

Telecamera 

Marker 

2D Stabilization 
Introduzione 

2D Stabilization Panel 

Flusso di Lavoro 

Vista 

Graph View 

Dope Sheet View 

Mascheramento 
Introduzione 

S-Curves 

Selezione 

Modifica 

Sidebar 

Video Editing 
Sequencer Scene 

Setting Your Project 
Video Editing App Template 

Directory Structure 

Editing Your Project 
Montage 
Strips 
Introduzione 

Strip Properties 

Scene Strip 

Clip Strip 

Mask Strip 

Movie Strip 

Sound Strip 

Image/Sequence Strip 

Color Strip 

Text Strip 

Adjustment Layer Strip 

Effect Strips 
Multicam Selector Strip 

Speed Control Strip 

Glow Strip 

Gaussian Blur Strip 

Add Strip 

Subtract Strip 

Multiply Strip 

Alpha Over & Alpha Under Strips 

Color Mix Strip 

Transitions 
Sound Crossfade 

Cross Strip 

Gamma Cross Strip 

Wipe Strip 

Strip Modifiers 

Selezione 

Modifica 

Meta Strips 

Storyboarding 
Storyboarding App Template 

Assets, Files, & Data System 
Introduzione 

Blender File 
Opening & Saving 

Compatibilità 

Packed Data 

Blend-Files Previews 

Rinomina 

Blocchi-Dati 

Custom Properties 

File Paths 

Linked Libraries 
Link & Append 

Library Overrides 

Asset Libraries 
Introduzione 

Asset Catalogs 

Media Formats 
Supported Graphics Formats 

Supported Video & Audio Formats 

Importing & Exporting Files 
Alembic 

Motion Capture (BVH) 

Universal Scene Description 

Wavefront OBJ 

Stanford PLY 

STL 

FBX 

FBX (Legacy) 

Scalable Vector Graphics (SVG) 

Import/Export SVG as Grease Pencil 

Export Grease Pencil as PDF 

Add-ons 
Node Wrangler 

Rigify 
Introduzione 

Basic Usage 

Bone Positioning Guide 

Generated Rig Features 

Creating Meta-rigs 

Rig Types 
Basic 

Spines 

Limbs 

Facce 

Skin 

Faccia 

Feature Sets 

glTF 2.0 

Manage UI Translations 

VR Scene Inspection 

Avanzate 
Using Blender From The Command Line 
Launching from the Command Line 
Linux 

macOS 

Windows 

Arguments 

Extensions Command Line Arguments 

Rendering From The Command Line 

Scripting & Extending Blender 
Introduzione 

Scripting & Security 

Add-on Tutorial 

Creating Extensions 
Getting started 

Compatible licenses 

Supported tags 

Version Number Guidelines 

Add-ons 

Python Wheels 

Creating a Repository 
Static Repository 

Dynamic Repository 

Application Templates 

Keymap Customization 

Working Limits 

Operators 

Blender’s Directory Layout 

Deploying Blender in Production 

Appendices 
Rotation Modes 

Risoluzione problemi 
Startup 

Vista 3D 

Graphics Hardware 
Windows 
NVIDIA 

AMD 

Intel 

Other GPU 

Linux 
NVIDIA 

AMD 

Intel 

Other GPU 

macOS 
NVIDIA 

AMD 

Intel 

Other GPU 

Crashes 

Network 

Python Errors 

Recovering Data 

Reporting a Bug 

Glossary 

Manual Index 

Partecipa 

Contribute Documentation 
Online Editing 

Local Editing 
Installing Dependencies 
Linux 

macOS 

Windows 

Building the Manual 

Editing the Manual 

Pull Requests 

Iniziare 

Guidelines 
Writing Style Guide 

Markup Style Guide 
Icons 

Commit Guidelines 

Templates 

Icons 

Maintenance 

Documentation Todo List 

Documenting New Features and Changes 

Translate Blender 

Translate the User Manual 
Contribute 

Style Guide 

Adding a Language 

5.2 Versioni 
Caricamento... 

Versioni Precedenti 

it Lingue 
Caricamento... 

Note 

Non stai usando la versione più recente della documentazione. è l'ultima versione. 
Back to top Edit this page 
Introduzione ¶ 

A Keyframe is simply a marker of time which stores the value of a property. 

For example, a Keyframe might define that the horizontal position of a cube is at 3 m on frame 1. 

The purpose of a Keyframe is to allow for interpolated animation, meaning, for example,
that the user could then add another key on frame 10, specifying the cube’s horizontal position at 20 m,
and Blender will automatically determine the correct position of the cube for all the frames between frame 1 and 10
depending on the chosen interpolation method (e.g. Linear, Bézier, Quadratic, etc.). 

An overview of existing keyframes can be seen via the Dope Sheet editor. 

Visualization ¶ 

There are some important visualization features in the 3D Viewport that can help animation. 

When the current frame is a keyframe for the current active object, the name of this object
(shown in the upper left corner of the 3D Viewport) turns yellow. 

Top: Current frame is a keyframe for Cube. Bottom: Current frame isn’t a keyframe. ¶ 

Interpolation ¶ 

Keyframe interpolation is represented and controlled by animation curves ,
also known as F-Curves . These curves can be viewed and modified
via the Graph Editor . 

Constant, Linear, Quadratic and Bézier interpolation, with Linear extrapolation. ¶ 

The X axis of the curve corresponds to time, while Y represents the value of the property.
Keyframes themselves define points of the curve, while interpolation is controlled by additional parameters. 

The Interpolation Mode is the main setting
that specifies for each keyframe how the curve is interpolated from that key to
the next one. There are a number of modes with fixed shapes,
e.g. Constant , Linear , Quadratic etc, and a free form Bézier mode. 

Extrapolation specifies how
the curve extends before the first, and after the last keyframe.
The main available choices are Constant and Linear ;
it is also possible to configure the curve to loop. 

Bézier interpolation is controlled by handles, which have
a handle type and position.
The position of Free and Aligned handles must be set manually from the Graph editor,
while Vector , Automatic and Auto Clamped handles are computed automatically from
keyframe values. 

Interpolation, Extrapolation and Handle Type can also be changed from
the Dope Sheet editor. 

Handle smoothing modes. Red: None , Green: Continuous Acceleration . ¶ 

The method how the three automatic handle types are computed is controlled by
the per-curve Auto Handle Smoothing setting.
The None mode resembles how most other software works and only considers the values
of the immediately adjacent keys. The Continuous Acceleration mode considers the shape
of the whole curve, which produces smoother results out of the box, but means that changes
in one key affect interpolation over a larger section of the curve; it also tends to
overshoot more with Automatic handles. 

Keyframe Types ¶ 

For visually distinguishing regular keyframes from different animation events or
states (extremes, breakdowns, or other in-betweens)
there is the possibility of applying different colors on them for visualization. 

Left: not selected; Right: selected. ¶ 

Keyframe (white / yellow diamond) 

Normal keyframe. 

Breakdown (small cyan diamond) 

Breakdown state. e.g. for transitions between key poses. 

Moving Hold (dark gray / orange diamond) 

A keyframe that adds a small amount of motion around a holding pose.
In the Dope Sheet it will also display a bar between them. 

Extreme (big pink diamond) 

An “extreme” state, or some other purpose as needed. 

Jitter (tiny green diamond) 

A filler or baked keyframe for keying on ones, or some other purpose as needed. 

Generated (dark diamond) 

A key generated by some tool, for example Copy Global Transform: Fix to
Camera . This keyframe type indicates
to Blender and add-ons that it is safe to remove and re-generate them, so be
careful when manually marking your hand-made animation with this type. 

Handles & Interpolation Mode Display ¶ 

Dope Sheet can display the Bézier handle type associated with the keyframe,
and mark segments with non-Bézier interpolation.
This facilitates basic editing of interpolation without the use of the Graph Editor. 

The icon shape represents the type of the Bézier Handles belonging to the keyframe. 

From top: summary, Bézier, linear. ¶ 

Cerchio 

Auto Clamped (default) 

Circle With Dot 

Automatic 

Quadrato 

Vector 

Clipped Diamond 

Aligned 

Diamond 

Free 

If the handles of a keyframe have different types,
or in case of summary rows representing multiple curves,
out of the available choices the icon that is furthest down the list is used.
This means that if a grouped row uses a circle icon,
it is guaranteed that none of the grouped channels have a non-auto key. 

Horizontal green lines mark the use of
non-Bézier Interpolation .
The line is dimmed in summary rows if not all grouped channels have the same interpolation. 

Display of this information can be disabled via the Show Handles and Interpolation option of the Dope Sheet’s View Menu .
