# Blender Manual Chunk 305

- Source: `C:\Users\carmi\blender\manual\blender_manual_html\blender_manual_vexp_it.html\render\shader_nodes\shader\toon.html`
- Manual group: `blender_manual_html`
- Score: `104`
- Part: `3`

## Content

Shrinkwrap Modifier 

Smooth Modifier 

Thickness Modifier 

Colore 
Hue/Saturation Modifier 

Opacity Modifier 

Tint Modifier 

Modifica 
Texture Mapping Modifier 

Time Offset Modifier 

Vertex Weight Angle Modifier 

Vertex Weight Proximity Modifier 

Visual Effects 
Introduzione 

Blur Visual Effect 

Colorize Visual Effect 

Flip Visual Effect 

Glow Visual Effect 

Pixelate Visual Effect 

Rim Visual Effect 

Shadow Visual Effect 

Swirl Visual Effect 

Wave Distortion Visual Effect 

Materials 
Proprietà 

Multiframe 

Animazione 
Introduzione 

Interpolation 

Animation Tools 

Modalità Oggetto 
Draw Mode 
Introduzione 

Brushes 
Draw Brushes 

Tint Brush 

Drawing Tools 

Strumenti 
Brush Tool 

Erase Tool 

Fill Tool 

Trim Tool 

Contagocce 

Line Tool 

Polyline Tool 

Arc Tool 

Curve Tool 

Box Tool 

Circle Tool 

Interpolate 

Tools Settings 
Brush Asset 

Brush Settings 

Colore 

Stroke Placement 

Drawing Plane 

Drawing Operations 

Modalità Scolpitura 
Introduzione 

Sculpting Brushes 

Sculpting Tools 

Brush Settings 

Modalità Modifica 
Introduzione 

Selezione 

Strumenti 
Editing Tools 

Pen 

Grease Pencil Menu 

Stroke Menu 

Point Menu 

Vertex Paint Mode 
Introduzione 

Vertex Paint Brushes 

Vertex Paint Tools 

Brush Settings 

Modifica 

Weight Paint Mode 
Introduzione 

Weight Paint Brushes 

Weight Paint Tools 

Strumento Impostazioni 
Brush Settings 

Opzioni 

Weights Menu 

Modalità Oggetto 
Trace Image to Grease Pencil 

Animation & Rigging 
Introduzione 

Animation Editors 

Fotogrammi Chiave (keyframes) 
Introduzione 

Modifica 

Keying Sets 

Armature 
Introduzione 

Ossa 
Introduzione 

Bone Collections 

Structure 

Strumenti 
Barra degli strumenti 

Strumento Impostazioni 

Selezione 

Modifica 
Introduzione 

Trasforma 

Bone Roll 

Estrudi 

Duplica 

Fill Between Joints 

Split 

Separate Bones 

Subdivide 

Switch Direction 

Symmetrize 

Naming 

Parenting 

Proprietà 

Cancella 

Proprietà 
Trasforma 

Bendy Bones 

Relations 

Inverse Kinematics 

Deformazione 

Viewport Display 

Custom Properties 

Proprietà 
Introduzione 

Bone Collections 

Selection Sets 

Viewport Display 

Structure 

Skinning 
Introduzione 

Armature Deform Parent 

Posing 
Introduzione 

Selezione 

Modifica 
Introduzione 

Clear Transform 

Apply 

In-Betweens 

Propagate 

Copy/Paste Pose 

Pose Library 

Add IK to Bone 

Remove IK 

Flip Quats 

Mostra/Nascondi 

Strumento Impostazioni 

Bone Constraints 
Introduzione 

Inverse Kinematics 

Spline IK 

Reticolo 

Vincoli 
Introduzione 

Interfaccia 
Intestazione 

Comune 

Stack 

Tracciamento del Movimento 
Camera Solver Constraint 

Follow Track Constraint 

Object Solver Constraint 

Trasforma 
Copy Location Constraint 

Copy Rotation Constraint 

Copy Scale Constraint 

Copy Transforms Constraint 

Limit Distance Constraint 

Limit Location Constraint 

Limit Rotation Constraint 

Limit Scale Constraint 

Maintain Volume Constraint 

Transformation Constraint 

Transform Cache Constraint 

Tracciamento 
Clamp To Constraint 

Damped Track Constraint 

Inverse Kinematics Constraint 

Locked Track Constraint 

Spline IK Constraint 

Stretch To Constraint 

Track To Constraint 

Relazioni 
Action Constraint 

Armature Constraint 

Child Of Constraint 

Floor Constraint 

Follow Path Constraint 

Geometry Attribute Constraint 

Pivot Constraint 

Shrinkwrap Constraint 

Actions 

Guide (driver) 
Introduzione 

Uso 

Drivers Panel 

Workflow & Examples 

Risoluzione problemi 

Markers 

Chiavi Forma 
Introduzione 

Shape Keys Panel 

Flusso di Lavoro 

Percorsi di Movimento 

Fisica 
Introduzione 

Rigid Body 
Introduzione 

Rigid Body Properties 
Impostazioni 

Collisions 

Dynamics 

Rigid Body World 

Rigid Body Constraints 
Introduzione 

Tipi 
Fixed Constraint 

Point Constraint 

Hinge Constraint 

Slider Constraint 

Piston Constraint 

Generic Constraint 

Generic Spring Constraint 

Motor Constraint 

Tips 

Cloth 
Introduzione 

Impostazioni 
Physical Properties 

Cache 

Shape 

Collisions 

Property Weights 

Field Weights 

Esempi 

Soft Body 
Introduzione 

Impostazioni 
Oggetto 

Simulation 

Cache 

Goal 

Bordi 

Self Collision 

Solver 

Forces 
Exterior 

Interior 

Collision 

Esempi 

Fluid 
Introduzione 

Tipo 
Domain 
Impostazioni 

Gas Settings 
Adaptive Domain 

Noise 

Viewport Display 

Liquid Settings 
Diffusion 

Particles 

Mesh 

Guide 

Raccolte 

Cache 

Field Weights 

Flow 

Effector 

Materials 

Particle System 
Introduzione 

Particle System Panel 

Emitter 
Emission 

Cache 

Velocity 

Rotazione 

Fisica 
Introduzione 

Newtonian 

Keyed 

Boids 

Fluid 

Render 

Viewport Display 

Children 

Force Fields 

Vertex Groups 

Hair 
Introduzione 

Emission 

Hair Dynamics 

Render 

Shape 

Children 

Viewport Display 

Texture Influence 

Particle Edit Mode 

Dynamic Paint 
Introduzione 

Pennello 

Tela 

Forces 
Gravity 

Force Fields 
Introduzione 

Force Fields Types 
Boid 

Charge 

Curve Guide 

Trascina 

Fluid Flow 

Force 

Harmonic 

Lennard-Jones 

Magnetic 

Texture 

Turbulence 

Vortex 

Wind 

Collision 

Baking Physics Simulations 

Simulation Nodes 

Rendering 
Introduzione 

Render Engines 
EEVEE 
Render Settings 
Campionatura 

Percorsi Luce 

Raytracing 

Volumes 

Curve 

Depth of Field 

Sfocatura movimento 

Film 

Performance 

Grease Pencil 

Scene Settings 

World Settings 

Object Settings 
Object Properties 

Materials 

Light Settings 

Light Probes 
Sphere 

Plane 

Volume 

Limitations 
Limitations 

Supported Nodes 

Cycles 
Render Settings 
Campionatura 

Percorsi Luce 

Volumes 

Suddivisione 

Curve 

Simplify 

Sfocatura movimento 

Film 

Performance 

Grease Pencil 

World Settings 

Object Settings 
Oggetto 

Camere 

Material Settings 

Light Settings 

GPU Rendering 

Precalcolo del Render 

Optimizing Renders 
Ridurre il Rumore 

Nodi Shader 

Open Shading Language 

Custom Camera 

Workbench 
Performance 

Campionatura 

Illuminazione 

Object Color 

Opzioni 

Grease Pencil 

Viewport Display 

Camere 

Lights 
Light Objects 

Light Linking 

World Environment 

Materials 
Introduzione 

Components 
Superfici 

Volumes 

Displacement 

Assignment 

Anteprima 

Impostazioni 

Line Art 

Legacy Textures 
Introduzione 

Colors 

Legacy Texture Types 
Blend 

Clouds 

Distorted Noise 

Image or Movie 

Magic 

Marble 

Musgrave 

Noise 

Stucci 

Voronoi 

Wood 

Nodi Shader 
Introduzione 

Ingresso 
Costante 
Boolean Node 

Color Node 

Integer Node 

Menu Node 

Nodo Valore 

Vector Node 

Ambient Occlusion Node 

Attribute Node 

Bevel Node 

Camera Data Node 

Fresnel Node 

Geometry Node 

Curves Info Node 

Layer Weight Node 

Light Path Node 

Object Info Node 

Particle Info Node 

Point Info 

Raycast Node 

Tangent Node 

Texture Coordinate Node 

UV Map Node 

Color Attribute Node 

Volume Info Node 

Wireframe Node 

Output 
AOV Output Node 

Material Output Node 

Light Output Node 

World Output Node 

Shader 
Add Shader 

Sfondo 

Diffuso BSDF 

Emission 

Glass BSDF 

Glossy BSDF 

Hair BSDF 

Holdout 

Mix Shader 

Metallic BSDF 

Generico BSDF (Principled) 

Principled Hair BSDF 

Principled Volume 

Ray Portal BSDF 

Refraction BSDF 

Specular BSDF 

Subsurface Scattering 

Toon BSDF 

Translucent BSDF 

Transparent BSDF 

Sheen BSDF 

Volume Absorption 

Volume Scatter 

Volume Coefficients 

Displacement 
Bump Node 

Displacement Node 

Normal Map Node 

Vector Displacement Node 

Texture 
Brick Texture Node 

Checker Texture Node 

Environment Texture Node 

Gabor Texture Node 

Gradient Texture Node 

IES Texture Node 

Image Texture Node 

Magic Texture Node 

Noise Texture Node 

Sky Texture Node 

Voronoi Texture Node 

Wave Texture Node 

White Noise Texture Node 

Colore 
Blackbody Node 

Brightness/Contrast Node 

Color Ramp Node 

Gamma Node 

Hue/Saturation/Value Node 

Invert Color Node 

Light Falloff Node 

Mix Color Node 

RGB Curves Node 

Wavelength Node 

Combine Color Node 

Separate Color Node 

RGB to BW Node 

Shader To RGB Node 

Utilities 
Math Nodes 
Clamp Node 

Float Curve 

Map Range Node 

Math Node 

Mix Node 

Vector Nodes 
Combine XYZ Node 

Mix Vector Node 

Separate XYZ Node 

Mapping Node 

Normal Node 

Vector Curves Node 

Radial Tiling Node 

Vector Rotate Node 

Vector Transform Node 

Combine Cylindrical Node 

Combine Spherical Node 

Separate Cylindrical Node 

Separate Spherical Node 

Repeat Zone 

Implicit Conversion 

Closure 

Evaluate Closure 

Combine Bundle Node 

Separate Bundle Node 

Join Bundle Node 

Menu Switch Node 

Script Node 

Gruppo 

Color Management 
Color Spaces 

Displays and Views 

OpenColorIO 

Freestyle 
Introduzione 

Render Properties 

View Layer Properties 
Freestyle 

Line Set 

Line Style 
Strokes 

Colore 

Trasparenza 

Spessore 

Geometria 

Texture 

Line Style Modifiers 
Color Modifiers 
Along Stroke 

Crease Angle 

Curvature 3D 

Distance from Camera 

Distance from Object 

Materiale 

Noise 

Tangente 

Alpha Modifiers 
Along Stroke 

Crease Angle 

Curvature 3D 

Distance from Camera 

Distance from Object 

Materiale 

Noise 

Tangente 

Thickness Modifiers 
Along Stroke 

Calligraphy 

Crease Angle 

Curvature 3D 

Distance from Camera 

Distance from Object 

Materiale 

Noise 

Tangente 

Geometry Modifiers 
2D Offset 

2D Transform 

Backbone Stretcher 

Bézier Curve 

Blueprint 

Guiding Lines 

Perlin Noise 1D 

Perlin Noise 2D 

Polygonization 

Campionatura 

Simplification 

Sinus Displacement 

Spatial Noise 

Tip Remover 

Material Properties 

Python Scripting 

View Layers & Passes 
Introduzione 

Visualizza Livello 

Passes 

Filtra 

View Layer Override 

Render Output 
Introduzione 

Output Properties 
Formato 

Frame Range 

Stereoscopy 
Introduzione 

Uso 

Output 

Metadata 

Post Processing 

Audio Rendering 
Introduzione 

Speaker Objects 

Rendering Animations 

Animation Player 

Composizione 
Introduzione 

Compositing Workspace 

Sidebar 

Compositor System 

Image Kernels 

Limitations 

Compositing Nodes 
Nodi Ingresso 
Costante 
Boolean Node 

Color Node 

Integer Node 

Menu Node 

Normal Node 

Object Node 

Nodo Valore 

Vector Node 

Blank Image Node 

Nodo Immagine Bokeh 

Group Input Node 

Nodo Immagine 

Image Info Node 

Image Coordinates Node 

Nodo Maschera 

Nodo Filmato 

Sequencer Strip Info Node 

Scena 
Active Camera Node 

Camera Info Node 

Nodo Livelli Render 

Scene Time Node 

Time Curve Node 

Nodi Uscita 
Enable Output Node 

Group Output 

Viewer Node 

Nodo Uscita File 

Color Nodes 
Adjust 
Brightness/Contrast Node 

Color Balance Node 

Color Correction Node 

Exposure Node 

Gamma Node 

Hue Correct Node 

Hue/Saturation/Value Node 

RGB Curves Node 

Tone Map Node 

Alpha Convert Node 

Alpha Over Node 

Set Alpha Node 

Combine Color Node 

Separate Color Node 

Depth Combine Node 

Mix Color 

Blackbody Node 

Color Ramp Node 

Convert Colorspace Node
