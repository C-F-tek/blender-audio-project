# Blender Manual Chunk 13

- Source: `C:\Users\carmi\blender\manual\blender_manual_html\blender_manual_vexp_it.html\render\shader_nodes\shader\volume_scatter.html`
- Manual group: `blender_manual_html`
- Score: `110`
- Part: `1`

## Content

Volume Scatter - Blender 5.2 LTS Manual Contents Menu Expand Light mode Dark mode Auto light/dark, in light mode Auto light/dark, in dark mode Skip to content Blender 5.2 LTS Manual Blender 5.2 LTS Manual 
Iniziare 

A proposito di Blender 
La storia di Blender 

Informazioni sul software libero e sulla GPL 

La comunità di Blender 

Installare Blender 
Installazione su Linux 

Installazione su macOS 

Installare su Windows 

Installing from Steam 

Configurare Blender 
Introduzione 

Configurazione delle periferiche 

Defaults 

Sistema di Aiuto 

Sezioni 

Interfaccia Utente 
Sistema di Finestre 
Introduzione 

Schermata Iniziale 

Barra Superiore 

Spazi di lavoro 

Barra di stato 

Areas 

Regioni 

Schede & Pannelli 

Mappa dei tasti 
Mappa dei tasti predefinita 

Mappa dei tasti compatibile con l’industria 

UI Elements 
Pulsanti 

Input Fields 

Menus 

Contagocce 

Decoratori 

Menu Blocco dati 

List View 

Tree View 

Selettore Colore 

Widget Rampa Colore 

Tavolozza dei Colori 

Widget Curva 

Tools & Operators 
Sistema di Strumenti 

Operators 

Annulla & Ripristina 

Annotazioni 

Selezione 

Nodi 
Node Editors 

Parti dei Nodi 

Selezione 

Organizzazione dei Nodi 

Modifica 

Common Nodes 
Output 
Enable Output Node 

Utilities 
Bundle 
Combine Bundle Node 

Separate Bundle Node 

Get Bundle Item Node 

Store Bundle Item Node 

Join Bundle Node 

Closure 
Closure 

Evaluate Closure 

Implicit Conversion 

Layout Nodes 
Nodo Cornice 

Nodo Bivio 

Gruppi di Nodi 

Editor 
Vista 3D 
Introduzione 

Scena di Avvio 

Modalità Oggetto 

Navigazione 
Introduzione 

Navigazione 

Fly/Walk Navigation 

Align View 

Perspective/Orthographic 

Vista Locale. 

Vista Telecamera 

Viewpoint 

View Regions 

Viste Contestuali 

Cursore 3D 

Selecting Objects 

Controlli 
Transform Orientation 

Transform Pivot Point 
Centro Delimitato 

Cursore 3D 

Origini Individuali 

Punto Mediano 

Elemento Attivo 

Snapping 

Modifica Proporzionale 

Visualizzazione 
Object Type Visibility 

Viewport Gizmos 

Viewport Overlays 

Viewport Shading 

Barra degli strumenti 
Misura 

Add Cube 

Add Cone 

Add Cylinder 

Add UV Sphere 

Add Icosphere 

Sidebar 
Animazione 
Global Transform 

Vista Rendering 

Image Editor 
Introduzione 

Navigazione 

Sidebar 

Overlays 

Impostazioni Immagine 

Modifica 

Editor UV 
Introduzione 

Navigazione 

Overlays 

Sidebar 

Selecting UVs 

Controlli 
Snapping 

Compositor 

Nodi Texture 
Introduzione 

Texture Nodes Types 
Color Nodes 
Combine Color Node 

Invert Color Node 

Mix Node 

RGB Curves Node 

Hue/Saturation/Value Node 

Separate Color Node 

Converter Nodes 
Color Ramp Node 

Distance Node 

Math Node 

RGB to BW Node 

Value to Normal Node 

Distort Nodes 
At Node 

Rotate Node 

Scale Node 

Translate Node 

Nodi Ingresso 
Coordinates Node 

Nodo Immagine 

Nodo Texture 

Time Curve Node 

Nodi Uscita 
Output Node 

Viewer Node 

Pattern Nodes 
Checker Node 

Bricks Node 

Nodi Texture 
Blend Node 

Clouds Node 

Distorted Noise Node 

Magic Node 

Marble Node 

Musgrave Node 

Noise Node 

Stucci Node 

Voronoi Node 

Wood Node 

Gruppo 

Geometry Node Editor 

Editor Ombreggiatori 

Editor Sequenze Video (sequencer) 
Introduzione 

Sequencer 
Introduzione 

Channels 

Navigazione 

Barra degli strumenti 

Sidebar 
Cache 

Proxy 

Visualizzazione 

Anteprima 
Introduzione 

Intestazione 

Barra degli strumenti 

Sidebar 

Controlli 
Punto Pivot 

Preview Snapping 

Visualizzazione 
Modalità di visualizzazione 

Gizmo 

Overlays 

Sequencer & Preview 

Editor Filmato 
Introduzione 

Visualizzazione 
Viewport Gizmos 

Mask Display 

Clip Display 

Regione Barra Laterale 

Dope Sheet 
Introduzione 

Navigazione 

Visualizzazione 
Overlays 

Modifica 

Modalità 
Action Editor 

Shape Key Editor 

Grease Pencil 

Maschera 

Sidebar 

Timeline 

Editor Grafi 
Introduzione 

Channels 
Introduzione 

Modifica 

Curve-F 
Introduzione 

Modifica 

Proprietà 

F-Curve Modifiers 

Drivers Editor 

Nonlinear Animation 
Introduzione 

Tracce 

Strips 

Modifica 
Track 

Strip 

Sidebar 

Editor Testi 

Python Console 

Info Editor 

Struttura (outliner) 
Introduzione 

Interfaccia 

Selezione 

Modifica 

Uso 

Properties Editor 

File Browser 

Asset Browser 

Spreadsheet 

Preferenze 
Introduzione 

Interfaccia 

Viewport 

Lights 

Modifica 

Animazione 

Get Extensions 

Add-ons 

Themes 

Ingresso 

Navigazione 

Mappa dei tasti 

System 

Salva & Carica 

File Paths 

Developer Tools 

Experimental 

Scenes & Objects 
Scenes 
Introduzione 

Scene Properties 

Oggetti 
Introduzione 

Object Types 

Origine Oggetto 

Selezione 

Modifica 
Trasforma 
Introduzione 

Transform Control 
Numeric Input 

Axis Locking 

Precision 

Muovi 

Ruota 

Scala 

Move/Scale Texture Space 

Align to Transform Orientation 

Randomize 

Align Objects 

Mirror 

Cancella 

Apply 

Aggancio 

Duplica 

Duplicate Linked 

Join 

Asset 

Parenting Objects 

Modificatori 

Vincoli 

Track 

Relations 
Make Single User 

Link/Transfer Data 
Link Data 

Transfer Mesh Data 

Transfer Mesh Data Layout 

Ombreggiatura 

Rigid Body 

Convert 

Mostra/Nascondi 

Pulizia 

Cancella 

Object Properties 
Trasforma 

Relations 

Raccolte 
Introduzione 

Raccolte 

Instancing 
Vertices 

Facce 

Raccolta 

Visibility 

Viewport Display 

Line Art 

Strumenti 
Barra degli strumenti 

Strumento Impostazioni 

Scale Cage 

Raccolte 
Introduzione 

Raccolte 

Modellazione 
Introduzione 

Mesh 
Introduzione 

Structure 

Primitives 
Mesh Plane 

Strumenti 
Barra degli strumenti 

Strumento Impostazioni 

Extrude Region 

Extrude Manifold 

Extrude to Cursor 

Taglia Loop 

Poly Build 

Spin 

Selezione 
Introduzione 

Select Mirror 

Select Random 

Checker Deselect 

Select More/Less 

Select Similar 

Select All by Trait 

Seleziona collegato 

Select Loops 

Select Sharp Edges 

Side of Active 

By Attribute 

Modifica 
Introduzione 

Mesh Operators 
Transformation 
Move, Rotate, Scale 

To Sphere 

To Circle 

Shear 

Bend 

Push/Pull 

Warp 

Randomize 

Shrink/Fatten 

Skin Resize 

Move/Scale Texture Space 

Mirror 

Duplica 

Estrudi 

Merge 

Split 

Separate 

Bisect 

Knife Project 

Knife Topology Tool 

Convex Hull 

Symmetrize 

Snap to Symmetry 

Normali 

Ombreggiatura 

Weights 

Set Attribute 

Sort Elements 

Pulizia 

Deleting & Dissolving 

Vertex Operators 
Extrude Vertices 

Extrude to Cursor or Add 

Angolo 

New Edge/Face from Vertices 

Connect Vertex Path 

Connect Vertex Pairs 

Rip Vertices 

Rip Vertices and Fill 

Rip Vertices and Extend 

Slide Vertices 

Smooth Vertices 

Smooth Vertices (Laplacian) 

Vertex Crease 

Blend from Shape 

Propagate to Shapes 

Vertex Groups 

Hooks 

Make Vertex Parent 

Edge Operators 
Extrude Edges 

Angolo 

Bridge Edge Loops 

Screw 

Subdivide 

Subdivide Edge-Ring 

Un-Subdivide 

Rotate Edge 

Edge Slide 

Loop Cut and Slide 

Offset Edge Slide 

Edge Data 

Face Operators 
Extrude Faces 

Extrude Faces Along Normals 

Extrude Individual Faces 

Inset Faces 

Poke Faces 

Triangulate Faces 

Triangles to Quads 

Solidify Faces 

Wireframe 

Fill 

Grid Fill 

Beautify Faces 

Intersect (Knife) 

Intersect (Boolean) 

Weld Edges into Faces 

Shade Smooth & Flat 

Face Data 

UV Operators 

Proprietà 
Object Data 

Vertex Groups 
Introduzione 

Vertex Groups Panel 

Assigning a Vertex Group 

Vertex Weights 

Geometry Data 

UV 
UVs & Texture Space 

Unwrapping 
Introduzione 

Cucitura 

Strumenti 
Barra degli strumenti 

Rip 

Grab 

Relax 

Pinch 

Modifica 

Workflows 
Layout Workflow 

UDIMs 

Using UV Maps 

Analisi mesh 

Remeshing 

Curve 
Introduzione 

Structure 

Primitives 

Strumenti 
Barra degli strumenti 

Draw 

Curve Pen 

Selezione 

Modifica 
Transform Panel 

Curva 

Punti di controllo 

Segments 

Altri 

Proprietà 
Shape 

Geometria 

Path Animation 

Active Spline 

Curve Display 

Curves (New) 
Structure 

Primitives 

Strumenti 
Barra degli strumenti 

Draw 

Curve Pen 

Selezione 

Modifica 
Curve 

Punti di controllo 

Segments 

Proprietà 

Curve Display 

Superfici 
Introduzione 

Barra degli strumenti 

Structure 

Primitives 

Selezione 

Modifica 
Superficie 

Punti di controllo 

Segments 

Proprietà 
Shape 

Transform Panel 

Active Spline 

Metaball 
Introduzione 

Barra degli strumenti 

Structure 

Primitives 

Modifica 

Proprietà 

Testo 
Introduzione 

Selezione 

Modifica 

Proprietà 

Point Cloud 
Strumenti 

Selezione 

Modifica 

Proprietà 

Volumes 
Introduzione 

Proprietà 

Empties 

Modificatori 
Introduzione 

Common Modifier Options 

Modifica 
Data Transfer Modifier 

Mesh Cache Modifier 

Mesh Sequence Cache Modifier 

UV Project Modifier 

UV Warp Modifier 

Vertex Weight Edit Modifier 

Vertex Weight Mix Modifier 

Vertex Weight Proximity Modifier 

Generazione 
Array Modifier 

Array (Legacy) Modifier 

Bevel Modifier 

Boolean Modifier 

Build Modifier 

Curve to Tube Modifier 

Decimate Modifier 

Edge Split Modifier 

Mask Modifier 

Mesh to Volume Modifier 

Mirror Modifier 

Multiresolution Modifier 

Remesh Modifier 

Scatter on Surface Modifier 

Screw Modifier 

Skin Modifier 

Solidify Modifier 

Subdivision Surface Modifier 

Triangulate Modifier 

Volume to Mesh Modifier 

Weld Modifier 

Wireframe Modifier 

Deformazione 
Armature Modifier 

Cast Modifier 

Curve Modifier 

Displace Modifier 

Hook Modifier 

Laplacian Deform Modifier 

Lattice Modifier 

Mesh Deform Modifier 

Shrinkwrap Modifier 

Simple Deform Modifier 

Smooth Modifier 

Smooth Corrective Modifier 

Smooth Laplacian Modifier 

Surface Deform Modifier 

Volume Displace Modifier 

Warp Modifier 

Wave Modifier 

Normali 
Normal Edit Modifier 

Weighted Normal Modifier 

Smooth By Angle Modifier 

Fisica 
Cloth Modifier 

Collision Modifier 

Dynamic Paint Modifier 

Explode Modifier 

Fluid Modifier 

Ocean Modifier 

Particle Instance Modifier 

Particle System Modifier 

Soft Body Modifier 

Geometry Nodes Modifier 

Geometry Nodes 
Introduzione 

Inspection 

Attributes 

Campi 

Instances 

Baking 

Node-Based Tools 

Gizmo 

Performance 

Nodi Ingresso 
Costante 
Boolean Node 

Collection Node 

Color Node 

Font Node 

Nodo Immagine 

Integer Node 

Material Node 

Menu Node 

Object Node 

Rotation Node 

String Node 

Nodo Valore 

Vector Node 

Gizmo 
Dial Gizmo 

Linear Gizmo 

Transform Gizmo 

Importa 
CSV (.csv) 

Wavefront (.obj) 

Stanford PLY (.ply) 

STL (.stl) 

Text (.txt) 

OpenVDB (.vdb) 

Scena 
3D Cursor Node 

Active Camera Node 

Bone Info Node 

Camera Info Node 

Collection Info Node 

Image Info Node 

Is Viewport Node 

Mouse Position Node 

Object Info Node 

Scene Time Node 

Self Object Node 

Viewport Transform Node 

Nodi Uscita 
Enable Output Node 

Warning Node 

Viewer Node 

Attribute Nodes 
Attribute Statistic Node 

Domain Size Node 

Blur Attribute Node 

Capture Attribute Node 

Remove Named Attribute Node 

Rename Attribute Node
