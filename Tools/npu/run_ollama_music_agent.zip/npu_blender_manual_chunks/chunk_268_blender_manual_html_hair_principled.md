# Blender Manual Chunk 268

- Source: `C:\Users\carmi\blender\manual\blender_manual_html\blender_manual_vexp_it.html\render\shader_nodes\shader\hair_principled.html`
- Manual group: `blender_manual_html`
- Score: `104`
- Part: `4`

## Content

Convert to Display Node 

Invert Color Node 

RGB to BW Node 

Creative Nodes 
Kuwahara Node 

Pixelate Node 

Posterize 

Sepia Node 

Split Toning Node 

Tune Image Node 

Unsharp Mask Node 

Filter Nodes 
Blur Filter Nodes 
Bilateral Blur Node 

Blur Node 

Bokeh Blur Node 

Defocus Node 

Directional Blur Node 

Vector Blur Node 

Anti-Aliasing Node 

Convolve Node 

Denoise Node 

Despeckle Node 

Dilate/Erode Node 

Mask To SDF Node 

Inpaint Node 

Filter Node 

Glare Node 

Keying Nodes 
Channel Key Node 

Chroma Key Node 

Color Key Node 

Color Spill Node 

Difference Key Node 

Distance Key Node 

Keying Node 

Keying Screen Node 

Luminance Key Node 

Mask Nodes 
Cryptomatte Node 

Cryptomatte Node (Legacy) 

Box Mask Node 

Ellipse Mask Node 

Double Edge Mask Node 

ID Mask Node 

Tracking Nodes 
Plane Track Deform Node 

Stabilize 2D Node 

Nodo Posizione Traccia 

Nodi Texture 
Brick Texture Node 

Checker Texture Node 

Gabor Texture Node 

Gradient Texture Node 

Magic Texture Node 

Noise Texture Node 

Voronoi Texture Node 

Wave Texture Node 

White Noise Texture Node 

Transform Nodes 
Rotate Node 

Scale Node 

Transform Node 

Translate Node 

Corner Pin Node 

Crop Node 

Displace Node 

Flip Node 

Map UV Node 

Lens Distortion Node 

Movie Distortion Node 

Utilities Nodes 
Math Nodes 
Clamp Node 

Float Curve 

Map Range Node 

Math Node 

Mix Node 

Vector Nodes 
Combine XYZ Node 

Separate XYZ Node 

Mix Vector Node 

Radial Tiling Node 

Vector Curves Node 

Vector Math Node 

Vector Rotate Node 

Combine Cylindrical Node 

Combine Spherical Node 

Separate Cylindrical Node 

Separate Spherical Node 

Matrix Utility Nodes 
Combine Matrix Node 

Invert Matrix Node 

Matrix Determinant Node 

Multiply Matrices Node 

Project Point Node 

Separate Matrix Node 

Transform Direction Node 

Transform Point Node 

Transpose Matrix Node 

Nodo Livelli 

Normalize Node 

Implicit Conversion 

Split Node 

Switch Node 

Index Switch Node 

Menu Switch Node 

Switch View Node 

Relative To Pixel Node 

Retime Node 

Camera & Lens Effects Nodes 
Chromatic Aberration Node 

Sensor Noise Node 

Vignette Node 

Gruppo 

Layout Nodes 

Motion Tracking & Masking 
Movie Clip Data-Blocks 

Tracciamento del Movimento 
Introduzione 

Clip View 
Introduzione 

Tracking Marker 

Barra degli strumenti 
Track 

Solve 

Selezione 

Modifica 
Ritaglia 

Track 

Reconstruction 

Sidebar 
Track 
Track 

Objects Panel 

Plane Track 

Telecamera 

Marker 

2D Stabilization 
Introduzione 

2D Stabilization Panel 

Flusso di Lavoro 

Vista 

Graph View 

Dope Sheet View 

Mascheramento 
Introduzione 

S-Curves 

Selezione 

Modifica 

Sidebar 

Video Editing 
Sequencer Scene 

Setting Your Project 
Video Editing App Template 

Directory Structure 

Editing Your Project 
Montage 
Strips 
Introduzione 

Strip Properties 

Scene Strip 

Clip Strip 

Mask Strip 

Movie Strip 

Sound Strip 

Image/Sequence Strip 

Color Strip 

Text Strip 

Adjustment Layer Strip 

Effect Strips 
Multicam Selector Strip 

Speed Control Strip 

Glow Strip 

Gaussian Blur Strip 

Add Strip 

Subtract Strip 

Multiply Strip 

Alpha Over & Alpha Under Strips 

Color Mix Strip 

Transitions 
Sound Crossfade 

Cross Strip 

Gamma Cross Strip 

Wipe Strip 

Strip Modifiers 

Selezione 

Modifica 

Meta Strips 

Storyboarding 
Storyboarding App Template 

Assets, Files, & Data System 
Introduzione 

Blender File 
Opening & Saving 

Compatibilità 

Packed Data 

Blend-Files Previews 

Rinomina 

Blocchi-Dati 

Custom Properties 

File Paths 

Linked Libraries 
Link & Append 

Library Overrides 

Asset Libraries 
Introduzione 

Asset Catalogs 

Media Formats 
Supported Graphics Formats 

Supported Video & Audio Formats 

Importing & Exporting Files 
Alembic 

Motion Capture (BVH) 

Universal Scene Description 

Wavefront OBJ 

Stanford PLY 

STL 

FBX 

FBX (Legacy) 

Scalable Vector Graphics (SVG) 

Import/Export SVG as Grease Pencil 

Export Grease Pencil as PDF 

Add-ons 
Node Wrangler 

Rigify 
Introduzione 

Basic Usage 

Bone Positioning Guide 

Generated Rig Features 

Creating Meta-rigs 

Rig Types 
Basic 

Spines 

Limbs 

Facce 

Skin 

Faccia 

Feature Sets 

glTF 2.0 

Manage UI Translations 

VR Scene Inspection 

Avanzate 
Using Blender From The Command Line 
Launching from the Command Line 
Linux 

macOS 

Windows 

Arguments 

Extensions Command Line Arguments 

Rendering From The Command Line 

Scripting & Extending Blender 
Introduzione 

Scripting & Security 

Add-on Tutorial 

Creating Extensions 
Getting started 

Compatible licenses 

Supported tags 

Version Number Guidelines 

Add-ons 

Python Wheels 

Creating a Repository 
Static Repository 

Dynamic Repository 

Application Templates 

Keymap Customization 

Working Limits 

Operators 

Blender’s Directory Layout 

Deploying Blender in Production 

Appendices 
Rotation Modes 

Risoluzione problemi 
Startup 

Vista 3D 

Graphics Hardware 
Windows 
NVIDIA 

AMD 

Intel 

Other GPU 

Linux 
NVIDIA 

AMD 

Intel 

Other GPU 

macOS 
NVIDIA 

AMD 

Intel 

Other GPU 

Crashes 

Network 

Python Errors 

Recovering Data 

Reporting a Bug 

Glossary 

Manual Index 

Partecipa 

Contribute Documentation 
Online Editing 

Local Editing 
Installing Dependencies 
Linux 

macOS 

Windows 

Building the Manual 

Editing the Manual 

Pull Requests 

Iniziare 

Guidelines 
Writing Style Guide 

Markup Style Guide 
Icons 

Commit Guidelines 

Templates 

Icons 

Maintenance 

Documentation Todo List 

Documenting New Features and Changes 

Translate Blender 

Translate the User Manual 
Contribute 

Style Guide 

Adding a Language 

5.2 Versioni 
Caricamento... 

Versioni Precedenti 

it Lingue 
Caricamento... 

Note 

Non stai usando la versione più recente della documentazione. è l'ultima versione. 
Back to top Edit this page 
Principled Hair BSDF ¶ 

Cycles Only 

The Principled Hair BSDF is a physically-based,
easy-to-use shader for rendering hair and fur. 

Suggerimento 

Realistic hair should have a minimum of variance between each strand.
The shader allows for this by specifying two values, Random Color and Random Roughness , which remap the specified Melanin/Roughness values to
the range \(Color/Roughness \pm Randomization\%\) . 

Ingressi ¶ 

Comune ¶ 

Colore 

The RGB color of the strand. Only used in Direct coloring. 

Suggerimento 

The chosen color is converted to an absorption coefficient with
the following formula (section 4.2 of [CBTB16] ): 
\[\sigma_{a} = \frac{\ln(Color)}
{\left(5.969 - 0.215\beta_{N} + 2.532\beta_{N}^{2} -
10.73\beta_{N}^{3} + 5.574\beta_{N}^{4} + 0.245\beta_{N}^{5}\right)^{2}}\] 
where \(\beta_{N}\) is the radial roughness of the hair after applying randomization (if specified). 

Coloring hair using the Direct coloring parametrization. (The numbers on top are the RGB values.) ¶ 

Melanin 

Absolute quantity of pigment.
Range \([0, 1]\) equivalent to \([0\%, 100\%]\) . 

Suggerimento 

This is a linear mapping to the underlying exponential function: 
\[melanin\_qty = -\ln(\max(1.0 - Melanin, 0.0001))\] 
Melanin. ¶ 

Melanin Redness 

Ratio of pheomelanin to eumelanin.
Range \([0, 1]\) equivalent to \([0\%, 100\%]\) . 

Suggerimento 

The ratio formula is: \(eumelanin = Melanin×(1.0-MelaninRedness)\) , \(pheomelanin = Melanin×MelaninRedness\) . 

The resulting quantities are converted (after randomization, if specified)
to absorption concentration via the following formula
(section 6.1 of [EFHLA11] , adjusted for the range \([0, 1]\) ): 
\[\begin{split}\sigma_{a} =
eumelanin × \left[\begin{matrix} 0.506 \\ 0.841 \\ 1.653 \\ \end{matrix}\right] +
pheomelanin × \left[\begin{matrix} 0.343 \\ 0.733 \\ 1.924 \\ \end{matrix}\right]\end{split}\] 
Melanin Redness. ¶ 

Tint 

Color used for dyeing the hair after applying the melanin pigment.
It is not subject to randomization.
It can be disabled by setting the color to white. 

Suggerimento 

This is converted via the Color mapping above and added to
the absorption coefficient of the melanin concentration. 

Tint, using Melanin 0.1 and the corresponding RGB values. ¶ 

Absorption Coefficient 

Attenuation coefficient \(\sigma\) . 

IOR 

Index of refraction ( IOR ) defining how much the ray changes direction.
At 1.0 rays pass straight through like in a transparent material;
higher values give more refraction.
Default value is \(1.55\) . 

Scostamento 

Tilts the glint of the hair by increasing the angle of the scales of
the hair’s cuticle with respect to the hair shaft.
Human hair usually has low values. 

Random Color 

For each strand, vary the melanin concentration by \(RandomFactor\) .
Range \([0, 1]\) equivalent to \([0\%, 100\%]\) of
the initial melanin concentration. 

Suggerimento 

The melanin concentration is multiplied by \(randomFactor\) ,
where \(randomFactor = 1.0 + 2.0×(Random - 0.5) × RandomColor\) . 

Random Color. ¶ 

Random Roughness 

For each strand, vary both Roughness values by \(RandomFactor\) .
Range \([0, 1]\) equivalent to \([0\%, 100\%]\) of
the initial roughness values. 

Suggerimento 

The applied formula is the same one as for Random Color . 

Random Roughness. ¶ 

Casuale 

Random number source. If no node is connected here, it is automatically
instanced with the value obtained from Hair Info ‣ Random . 

Chiang Model ¶ 

The Chiang model is based on a Gaussian distribution with separate roughness
along and orthogonal to the hair. 

Roughness 

Specify how much the glints are smoothed in the direction of the hair shaft.
Too low values will smoothen the hair to the point of looking almost metallic,
making glints look like Fireflies ; while setting it too high will result in a Lambertian look. 

Roughness. ¶ 

Radial Roughness 

Specify how much the glints are smoothed in the direction of the hair normal.
Too low values will concentrate the glint;
while setting it too high will spread the light across the width of the strand. 

Suggerimento 

Mathematically, this parameter is mapped to the logistic distribution’s
scale factor \(s\) (section 4.1 of [CBTB16] ). 

Radial Roughness. ¶ 

Coat 

Simulate a shiny coat of fur, by reducing the Roughness to the given factor
only for the first light bounce (diffuse).
Range \([0, 1]\) equivalent to a reduction of \([0\%, 100\%]\) of the original Roughness. 

Coat. ¶ 

Huang Model ¶ 

The Huang model is based on microfacet based reflection and transmission,
and supports elliptically shaped hair. 

Aspect Ratio 

The ratio of the minor axis to the major axis of an elliptical cross-section.
Recommended values are 0.8~1 for Asian hair, 0.65~0.9 for Caucasian hair, 0.5~0.65 for
African hair. The major axis is aligned with the curve normal, which can be created
with geometry nodes, but is not supported in legacy particle hair. 

Roughness 

Microfacet roughness for reflection and transmission. 

Reflection 

Optional factor for modulating the first light bounce off the hair surface.
