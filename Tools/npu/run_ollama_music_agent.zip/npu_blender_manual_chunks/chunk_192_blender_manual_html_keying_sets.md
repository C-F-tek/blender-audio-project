# Blender Manual Chunk 192

- Source: `C:\Users\carmi\blender\manual\blender_manual_html\blender_manual_vexp_it.html\animation\keyframes\keying_sets.html`
- Manual group: `blender_manual_html`
- Score: `104`
- Part: `4`

## Content

Convert to Display Node 

Invert Color Node 

RGB to BW Node 

Creative Nodes 
Kuwahara Node 

Pixelate Node 

Posterize 

Sepia Node 

Split Toning Node 

Tune Image Node 

Unsharp Mask Node 

Filter Nodes 
Blur Filter Nodes 
Bilateral Blur Node 

Blur Node 

Bokeh Blur Node 

Defocus Node 

Directional Blur Node 

Vector Blur Node 

Anti-Aliasing Node 

Convolve Node 

Denoise Node 

Despeckle Node 

Dilate/Erode Node 

Mask To SDF Node 

Inpaint Node 

Filter Node 

Glare Node 

Keying Nodes 
Channel Key Node 

Chroma Key Node 

Color Key Node 

Color Spill Node 

Difference Key Node 

Distance Key Node 

Keying Node 

Keying Screen Node 

Luminance Key Node 

Mask Nodes 
Cryptomatte Node 

Cryptomatte Node (Legacy) 

Box Mask Node 

Ellipse Mask Node 

Double Edge Mask Node 

ID Mask Node 

Tracking Nodes 
Plane Track Deform Node 

Stabilize 2D Node 

Nodo Posizione Traccia 

Nodi Texture 
Brick Texture Node 

Checker Texture Node 

Gabor Texture Node 

Gradient Texture Node 

Magic Texture Node 

Noise Texture Node 

Voronoi Texture Node 

Wave Texture Node 

White Noise Texture Node 

Transform Nodes 
Rotate Node 

Scale Node 

Transform Node 

Translate Node 

Corner Pin Node 

Crop Node 

Displace Node 

Flip Node 

Map UV Node 

Lens Distortion Node 

Movie Distortion Node 

Utilities Nodes 
Math Nodes 
Clamp Node 

Float Curve 

Map Range Node 

Math Node 

Mix Node 

Vector Nodes 
Combine XYZ Node 

Separate XYZ Node 

Mix Vector Node 

Radial Tiling Node 

Vector Curves Node 

Vector Math Node 

Vector Rotate Node 

Combine Cylindrical Node 

Combine Spherical Node 

Separate Cylindrical Node 

Separate Spherical Node 

Matrix Utility Nodes 
Combine Matrix Node 

Invert Matrix Node 

Matrix Determinant Node 

Multiply Matrices Node 

Project Point Node 

Separate Matrix Node 

Transform Direction Node 

Transform Point Node 

Transpose Matrix Node 

Nodo Livelli 

Normalize Node 

Implicit Conversion 

Split Node 

Switch Node 

Index Switch Node 

Menu Switch Node 

Switch View Node 

Relative To Pixel Node 

Retime Node 

Camera & Lens Effects Nodes 
Chromatic Aberration Node 

Sensor Noise Node 

Vignette Node 

Gruppo 

Layout Nodes 

Motion Tracking & Masking 
Movie Clip Data-Blocks 

Tracciamento del Movimento 
Introduzione 

Clip View 
Introduzione 

Tracking Marker 

Barra degli strumenti 
Track 

Solve 

Selezione 

Modifica 
Ritaglia 

Track 

Reconstruction 

Sidebar 
Track 
Track 

Objects Panel 

Plane Track 

Telecamera 

Marker 

2D Stabilization 
Introduzione 

2D Stabilization Panel 

Flusso di Lavoro 

Vista 

Graph View 

Dope Sheet View 

Mascheramento 
Introduzione 

S-Curves 

Selezione 

Modifica 

Sidebar 

Video Editing 
Sequencer Scene 

Setting Your Project 
Video Editing App Template 

Directory Structure 

Editing Your Project 
Montage 
Strips 
Introduzione 

Strip Properties 

Scene Strip 

Clip Strip 

Mask Strip 

Movie Strip 

Sound Strip 

Image/Sequence Strip 

Color Strip 

Text Strip 

Adjustment Layer Strip 

Effect Strips 
Multicam Selector Strip 

Speed Control Strip 

Glow Strip 

Gaussian Blur Strip 

Add Strip 

Subtract Strip 

Multiply Strip 

Alpha Over & Alpha Under Strips 

Color Mix Strip 

Transitions 
Sound Crossfade 

Cross Strip 

Gamma Cross Strip 

Wipe Strip 

Strip Modifiers 

Selezione 

Modifica 

Meta Strips 

Storyboarding 
Storyboarding App Template 

Assets, Files, & Data System 
Introduzione 

Blender File 
Opening & Saving 

Compatibilità 

Packed Data 

Blend-Files Previews 

Rinomina 

Blocchi-Dati 

Custom Properties 

File Paths 

Linked Libraries 
Link & Append 

Library Overrides 

Asset Libraries 
Introduzione 

Asset Catalogs 

Media Formats 
Supported Graphics Formats 

Supported Video & Audio Formats 

Importing & Exporting Files 
Alembic 

Motion Capture (BVH) 

Universal Scene Description 

Wavefront OBJ 

Stanford PLY 

STL 

FBX 

FBX (Legacy) 

Scalable Vector Graphics (SVG) 

Import/Export SVG as Grease Pencil 

Export Grease Pencil as PDF 

Add-ons 
Node Wrangler 

Rigify 
Introduzione 

Basic Usage 

Bone Positioning Guide 

Generated Rig Features 

Creating Meta-rigs 

Rig Types 
Basic 

Spines 

Limbs 

Facce 

Skin 

Faccia 

Feature Sets 

glTF 2.0 

Manage UI Translations 

VR Scene Inspection 

Avanzate 
Using Blender From The Command Line 
Launching from the Command Line 
Linux 

macOS 

Windows 

Arguments 

Extensions Command Line Arguments 

Rendering From The Command Line 

Scripting & Extending Blender 
Introduzione 

Scripting & Security 

Add-on Tutorial 

Creating Extensions 
Getting started 

Compatible licenses 

Supported tags 

Version Number Guidelines 

Add-ons 

Python Wheels 

Creating a Repository 
Static Repository 

Dynamic Repository 

Application Templates 

Keymap Customization 

Working Limits 

Operators 

Blender’s Directory Layout 

Deploying Blender in Production 

Appendices 
Rotation Modes 

Risoluzione problemi 
Startup 

Vista 3D 

Graphics Hardware 
Windows 
NVIDIA 

AMD 

Intel 

Other GPU 

Linux 
NVIDIA 

AMD 

Intel 

Other GPU 

macOS 
NVIDIA 

AMD 

Intel 

Other GPU 

Crashes 

Network 

Python Errors 

Recovering Data 

Reporting a Bug 

Glossary 

Manual Index 

Partecipa 

Contribute Documentation 
Online Editing 

Local Editing 
Installing Dependencies 
Linux 

macOS 

Windows 

Building the Manual 

Editing the Manual 

Pull Requests 

Iniziare 

Guidelines 
Writing Style Guide 

Markup Style Guide 
Icons 

Commit Guidelines 

Templates 

Icons 

Maintenance 

Documentation Todo List 

Documenting New Features and Changes 

Translate Blender 

Translate the User Manual 
Contribute 

Style Guide 

Adding a Language 

5.2 Versioni 
Caricamento... 

Versioni Precedenti 

it Lingue 
Caricamento... 

Note 

Non stai usando la versione più recente della documentazione. è l'ultima versione. 
Back to top Edit this page 
Keying Sets ¶ 

The Active Keying Sets data ID in the Timeline. ¶ 

Keying Sets are a collection of animated properties that are used to animate
and keyframe multiple properties at the same time.
For example, pressing K in the 3D Viewport will bring up the available Keying Sets.
Blender will then add keyframes for whichever Keying Set is chosen.
There are some built-in Keying Sets and also custom Keying Sets called «Absolute Keying Sets». 

Keying Set Panel ¶ 

Riferimento 

Editor : 

Proprietà 

Pannello : 

Scene ‣ Keying Set 

This panel is used to add, select, manage «Absolute Keying Sets». 

The Keying Set panel. ¶ 

Active Keying Set 

A List View of Keying Sets in the active scene.
Selecting a keying set makes it active 

Add Empty Keying Set 

Adds an empty Keying Set. 

Remove Active Keying Set 

Removes the active keying set. 

Descrizione 

A short description of the Keying Set. 

Export to File 

Export Keying Set to a Python script 
File.py .
To re-add the Keying Set from the 
File.py , open then run the 
File.py from the Text Editor. 

Active Keying Set Panel ¶ 

Riferimento 

Editor : 

Proprietà 

Pannello : 

Scene ‣ Active Keying Set 

This panel is used to add properties to the active Keying Set. 

The Active Keying Set panel. ¶ 

Paths 

A collection of paths in a List View each with a Data Path to a property
to add to the active Keying Set. 

Add Empty Keying Set Path 

Adds an empty path. 

Remove Active Keying Set Path 

Removes the selected path. 

Target ID-Block 

Set the ID Type and the Object IDs data path for the property. 

Data Path 

Set the rest of the Data Path for the property. 

Array All Items 

Use All Items from the Data Path or select the array index for a specific property. 

F-Curve Grouping 

This controls what group to add the channels to. 

Keying Set Name, None, Named Group 

Keyframing Settings ¶ 

General Override 

These options control all properties in the Keying Set.
Note that the same settings in Preferences override these settings if enabled. 

Active Set Override 

These options control individual properties in the Keying Set. 

Common Settings 

Needed 

Only insert keyframes where they are needed in the relevant F-Curves. 

Visual 

Insert keyframes based on the visual transformation. 

Adding Properties to a Keying Set ¶ 

Riferimento 

Menù : 

Context menu ‣ Add All/Single to Keying Set 

Scorciatoia : 

K 

Some ways to add properties to Keying Sets. 

RMB the property in the User Interface , then select Add Single to Keying Set or Add All to Keying Set .
This will add the properties to the active Keying Set, or to a new Keying Set if none exist. 

Hover the mouse over the properties, then press K , to add Add All to Keying Set . 

Set Active Keying Set ¶ 

Riferimento 

Scorciatoia : 

Shift - K 

There are several ways to designate the active keying set: 

Press Shift - K in the 3D Viewport. 

Select a keying set in the Keying Set panel. 

Select a keying set in the Keying popover in the Timeline header, 

Whole Character Keying Set ¶ 

The built-in Whole Character Keying Set is made to keyframe all properties
that are likely to get animated in a character rig. 

This keying set ignores bones whose name starts with one of the following prefixes,
as it assumes these are technical bones that are not meant to be animated directly.
The built-in Rigify addon generates such bones, for example. 

COR (Corrective) 

DEF (Deformation) 

GEO (Geometry) 

MCH (Mechanism) 

ORG (Original from meta rig) 

VIS (Visualization) 

Next Armature Previous Editing Keyframes Copyright © : This page is licensed under a CC-BY-SA 4.0 Int. License Made with Furo Last updated on 2026-04-25 
Visualizza Fonte 

Visualizza Traduzione 

Segnala il problema in questa pagina 
On this page 
Keying Sets 
Keying Set Panel 
Active Keying Set Panel 

Keyframing Settings 

Adding Properties to a Keying Set 

Set Active Keying Set 

Whole Character Keying Set
