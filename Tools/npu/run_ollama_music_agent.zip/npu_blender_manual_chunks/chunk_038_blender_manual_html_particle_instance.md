# Blender Manual Chunk 38

- Source: `C:\Users\carmi\blender\manual\blender_manual_html\blender_manual_vexp_it.html\modeling\modifiers\physics\particle_instance.html`
- Manual group: `blender_manual_html`
- Score: `108`
- Part: `5`

## Content

and each of those vertex groups is assigned to a separate and independent particle system,
with each particle system being assigned to a different Particle Instance modifier.
In the case shown the Particle Instance modifiers are added to a sphere and a cube.
See example blend-file . 

Create Along Path example. ¶ 

In this example, a single Keyed particle travels through four points (green planes),
on an elliptical path. The Particle Instance modifier is added to a cylinder object
and then associated with that Keyed particle system. 

When the Create Along Paths is activated,
instead of the cylinder location just following the position of the particle,
the cylinder mesh is fitted to the shape of the path followed by the particle.
The mesh geometry of the object which is deformed
can have an impact on how well the deformation is carried out.
In the case of the cylinder, it has many loop cuts along its length so
that it can bend at those points to deform along the particle path. 

The Particle Instance modifier Create Along Paths option works for hair (strand) particles
as well as with keyed particles. In this case, the mesh of the modifier will follow
the length and profile of the hair strands paths. 

Nota 

Strands, when they are generated, instantly die when created, so for the Create Along Paths checkbox
to be of any use, you must also have the Dead checkbox enabled. 
Next Particle System Modifier Previous Ocean Modifier Copyright © : This page is licensed under a CC-BY-SA 4.0 Int. License Made with Furo Last updated on 2026-04-25 
Visualizza Fonte 

Visualizza Traduzione 

Segnala il problema in questa pagina 
On this page 
Particle Instance Modifier 
Opzioni 
Create Along Paths 

Livelli 

Esempi
